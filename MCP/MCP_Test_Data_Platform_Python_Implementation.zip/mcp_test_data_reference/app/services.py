"""Replace these demo services with real, secured enterprise integrations.

This file intentionally uses simple demo behavior so the MCP interface is
understandable. It is not a production database or privacy engine.
"""
from __future__ import annotations

import os
import re
import uuid
from datetime import datetime, timezone
from threading import Lock
from typing import Any


class PiiService:
    """Demo-only patterns. Production PII detection requires tested policies."""

    EMAIL_RE = re.compile(r"\b[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}\b")
    PHONE_RE = re.compile(r"\b(?:\+?1[-. ]?)?\(?\d{3}\)?[-. ]\d{3}[-. ]\d{4}\b")

    def detect(self, text: str) -> dict[str, Any]:
        entities = []
        for match in self.EMAIL_RE.finditer(text):
            entities.append({"type": "EMAIL", "start": match.start(), "end": match.end()})
        for match in self.PHONE_RE.finditer(text):
            entities.append({"type": "PHONE", "start": match.start(), "end": match.end()})
        entities.sort(key=lambda item: item["start"])
        return {"status": "SUCCESS", "entities": entities,
                "warning": "Demo patterns only; not comprehensive PII detection."}

    def redact(self, text: str, mode: str = "mask") -> dict[str, Any]:
        if mode not in {"mask", "remove"}:
            raise ValueError("mode must be 'mask' or 'remove'")
        replacement = "[REDACTED]" if mode == "mask" else ""
        cleaned = self.EMAIL_RE.sub(replacement, text)
        cleaned = self.PHONE_RE.sub(replacement, cleaned)
        return {"status": "SUCCESS", "text": cleaned,
                "warning": "Demo patterns only; verify output before use."}

    def substitute(self, text: str, policy_id: str) -> dict[str, Any]:
        if not policy_id.strip():
            raise ValueError("policy_id is required")
        # Demonstration only: use policy-managed, approved synthetic values in production.
        return {"status": "NOT_IMPLEMENTED",
                "message": "Connect your approved synthetic-value substitution library.",
                "policy_id": policy_id}


class SearchService:
    def search(self, fico_min: int, page_size: int = 20) -> dict[str, Any]:
        # Replace with a controlled Elasticsearch query and an availability filter.
        demo = [
            {"record_id": "A123", "fico": 735, "reservation_status": "AVAILABLE"},
            {"record_id": "A456", "fico": 710, "reservation_status": "AVAILABLE"},
            {"record_id": "A789", "fico": 690, "reservation_status": "RESERVED"},
        ]
        results = [x for x in demo if x["fico"] >= fico_min and
                   x["reservation_status"] == "AVAILABLE"][:page_size]
        return {"status": "SUCCESS", "results": results, "count": len(results),
                "warning": "Illustrative in-memory data only."}


class ReservationService:
    """In-memory demo only; replace with a transactional authoritative store."""
    def __init__(self) -> None:
        self._lock = Lock()
        self._reservations: dict[str, dict[str, Any]] = {}
        self._idempotency: dict[str, dict[str, Any]] = {}
        self._available = {"A123", "A456"}

    def reserve(self, record_id: str, idempotency_key: str) -> dict[str, Any]:
        with self._lock:
            if idempotency_key in self._idempotency:
                return self._idempotency[idempotency_key]
            if record_id not in self._available:
                return {"status": "CONFLICT", "record_id": record_id,
                        "message": "Record is not available in the demo store."}
            reservation_id = f"res-{uuid.uuid4().hex[:12]}"
            result = {"status": "SUCCESS", "reservation_id": reservation_id,
                      "record_id": record_id}
            self._available.remove(record_id)
            self._reservations[reservation_id] = result
            self._idempotency[idempotency_key] = result
            return result

    def release(self, reservation_id: str) -> dict[str, Any]:
        with self._lock:
            reservation = self._reservations.get(reservation_id)
            if not reservation:
                return {"status": "NOT_FOUND", "reservation_id": reservation_id}
            self._available.add(reservation["record_id"])
            del self._reservations[reservation_id]
            return {"status": "SUCCESS", "reservation_id": reservation_id}


class JobService:
    """Demo job adapter. Replace with existing trigger/status APIs and durable state."""
    def __init__(self) -> None:
        self._jobs: dict[str, dict[str, Any]] = {}
        self._lock = Lock()

    def submit_extraction(self, dataset_id: str, runtime: str, policy_id: str,
                          idempotency_key: str) -> dict[str, Any]:
        allowed = {"ON_PREM_SPARK", "AWS_GLUE", "GCP"}
        if runtime not in allowed:
            raise ValueError(f"runtime must be one of {sorted(allowed)}")
        with self._lock:
            for job in self._jobs.values():
                if job.get("idempotency_key") == idempotency_key:
                    return job
            job_id = f"job-{uuid.uuid4().hex[:12]}"
            job = {"job_id": job_id, "status": "SUBMITTED",
                   "dataset_id": dataset_id, "runtime": runtime,
                   "policy_id": policy_id, "idempotency_key": idempotency_key,
                   "created_at": datetime.now(timezone.utc).isoformat(),
                   "warning": "Demo only; no real script was triggered."}
            self._jobs[job_id] = job
            return job

    def get_status(self, job_id: str) -> dict[str, Any]:
        with self._lock:
            job = self._jobs.get(job_id)
            return dict(job) if job else {"status": "NOT_FOUND", "job_id": job_id}

    def start_loading(self, extraction_job_id: str, target_environment: str,
                      idempotency_key: str) -> dict[str, Any]:
        with self._lock:
            source = self._jobs.get(extraction_job_id)
            if not source:
                return {"status": "NOT_FOUND", "job_id": extraction_job_id}
            if source["status"] not in {"SUCCEEDED", "SUBMITTED", "RUNNING"}:
                return {"status": "REJECTED", "message": "Extraction is not in a loadable state."}
            load_id = f"load-{uuid.uuid4().hex[:12]}"
            return {"status": "SUBMITTED", "job_id": load_id,
                    "source_job_id": extraction_job_id,
                    "target_environment": target_environment,
                    "warning": "Demo only; no load job was triggered."}


class TransactionService:
    def post(self, account_id: str, amount: float, currency: str,
             idempotency_key: str) -> dict[str, Any]:
        # This is deliberately a stub. Never simulate a real financial posting.
        return {"status": "NOT_IMPLEMENTED",
                "message": "Connect an authorized transaction service before enabling.",
                "account_id": account_id, "currency": currency}


pii_service = PiiService()
search_service = SearchService()
reservation_service = ReservationService()
job_service = JobService()
transaction_service = TransactionService()
ENABLE_TRANSACTION_TOOL = os.getenv("ENABLE_TRANSACTION_TOOL", "false").lower() == "true"
