"""MCP tool interface for the test data platform.

Demo only: authentication/authorization middleware and real adapters are not
included. Keep the endpoint on a trusted network until these controls exist.
"""
from __future__ import annotations

from mcp.server.fastmcp import FastMCP
from app.services import (
    pii_service, search_service, reservation_service, job_service,
    transaction_service, ENABLE_TRANSACTION_TOOL,
)

mcp = FastMCP("Enterprise Test Data Platform")


@mcp.tool()
def detect_pii(text: str) -> dict:
    """Detect demo email/phone patterns in text. Not comprehensive PII detection."""
    if len(text) > 100_000:
        raise ValueError("text exceeds the 100000-character demo limit")
    return pii_service.detect(text)


@mcp.tool()
def redact_pii(text: str, mode: str = "mask") -> dict:
    """Redact demo email/phone patterns; mode is mask or remove."""
    if len(text) > 100_000:
        raise ValueError("text exceeds the 100000-character demo limit")
    return pii_service.redact(text, mode)


@mcp.tool()
def substitute_pii(text: str, policy_id: str) -> dict:
    """Invoke the approved substitution adapter (stub in this reference project)."""
    if len(text) > 100_000:
        raise ValueError("text exceeds the 100000-character demo limit")
    return pii_service.substitute(text, policy_id)


@mcp.tool()
def search_test_data(fico_min: int, page_size: int = 20) -> dict:
    """Search illustrative available test data; replace with Elasticsearch."""
    if not 300 <= fico_min <= 850:
        raise ValueError("fico_min must be between 300 and 850")
    if not 1 <= page_size <= 100:
        raise ValueError("page_size must be between 1 and 100")
    return search_service.search(fico_min, page_size)


@mcp.tool()
def reserve_test_data(record_id: str, idempotency_key: str) -> dict:
    """Reserve a demo record; production must use an authoritative transactional store."""
    if not record_id.strip() or not idempotency_key.strip():
        raise ValueError("record_id and idempotency_key are required")
    return reservation_service.reserve(record_id, idempotency_key)


@mcp.tool()
def release_reservation(reservation_id: str) -> dict:
    """Release a demo reservation."""
    return reservation_service.release(reservation_id)


@mcp.tool()
def start_data_extraction(dataset_id: str, runtime: str, policy_id: str,
                          idempotency_key: str) -> dict:
    """Submit a demo extraction request; no real script is triggered."""
    for name, value in {"dataset_id": dataset_id, "policy_id": policy_id,
                        "idempotency_key": idempotency_key}.items():
        if not value.strip():
            raise ValueError(f"{name} is required")
    return job_service.submit_extraction(dataset_id, runtime, policy_id, idempotency_key)


@mcp.tool()
def get_extraction_status(job_id: str) -> dict:
    """Retrieve status from the demo job store; connect the existing status APIs."""
    return job_service.get_status(job_id)


@mcp.tool()
def start_data_loading(extraction_job_id: str, target_environment: str,
                       idempotency_key: str) -> dict:
    """Submit a demo load request; no real load job is triggered."""
    if not target_environment.strip() or not idempotency_key.strip():
        raise ValueError("target_environment and idempotency_key are required")
    return job_service.start_loading(extraction_job_id, target_environment, idempotency_key)


if ENABLE_TRANSACTION_TOOL:
    @mcp.tool()
    def post_transaction(account_id: str, amount: float, currency: str,
                         idempotency_key: str) -> dict:
        """Stub only; connect a real authorized transaction service before enabling."""
        if amount <= 0:
            raise ValueError("amount must be positive")
        if not idempotency_key.strip():
            raise ValueError("idempotency_key is required")
        return transaction_service.post(account_id, amount, currency, idempotency_key)


if __name__ == "__main__":
    # Confirm the exact run/transport options for the pinned MCP SDK version.
    mcp.run(transport="streamable-http")
