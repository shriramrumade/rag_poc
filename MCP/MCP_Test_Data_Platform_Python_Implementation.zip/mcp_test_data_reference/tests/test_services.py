import unittest
from app.services import PiiService, SearchService, ReservationService, JobService


class ServiceTests(unittest.TestCase):
    def test_redact_email(self):
        result = PiiService().redact("email a@example.com")
        self.assertNotIn("a@example.com", result["text"])
        self.assertIn("[REDACTED]", result["text"])

    def test_search_filters_available(self):
        result = SearchService().search(700)
        self.assertTrue(all(r["fico"] >= 700 for r in result["results"]))
        self.assertTrue(all(r["reservation_status"] == "AVAILABLE" for r in result["results"]))

    def test_reservation_idempotency(self):
        service = ReservationService()
        first = service.reserve("A123", "request-1")
        second = service.reserve("A123", "request-1")
        self.assertEqual(first, second)

    def test_job_status(self):
        service = JobService()
        job = service.submit_extraction("customers", "ON_PREM_SPARK", "policy-a", "req-1")
        status = service.get_status(job["job_id"])
        self.assertEqual(status["job_id"], job["job_id"])


if __name__ == "__main__":
    unittest.main()
