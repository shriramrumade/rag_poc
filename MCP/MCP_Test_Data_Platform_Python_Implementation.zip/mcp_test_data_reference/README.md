# Test Data MCP Platform — Python Reference Implementation

This is a **reference starter project**, not production-ready software. It demonstrates a single MCP endpoint exposing business tools for:
- PII detection/redaction/substitution (stub adapter)
- Test-data search (stub adapter)
- Reservation (in-memory demo only; replace with an authoritative transactional store)
- Extraction submission and status (stub adapter for existing APIs)
- Transaction posting (stub adapter; disabled unless explicitly enabled)

## Architecture

Consumer agent → MCP client → MCP server (Streamable HTTP) → tool handler → business adapter → existing library/API/database.

The MCP server standardizes discovery and invocation. It does not itself perform Spark/Glue/GCP processing or provide LLM reasoning.

## Requirements

- Python 3.11+
- An MCP Python SDK version compatible with `mcp.server.fastmcp`
- For production, use your enterprise identity provider, TLS termination, secret management, durable job state, and authoritative services.

## Local setup

```bash
python -m venv .venv
source .venv/bin/activate        # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp .env.example .env
python -m app.server
```

The server is configured for Streamable HTTP by the pinned MCP SDK API. Confirm transport/configuration options against the SDK version you deploy.

## Example tools

- `detect_pii(text)`
- `redact_pii(text, mode)`
- `substitute_pii(text, policy_id)`
- `search_test_data(fico_min, page_size)`
- `reserve_test_data(record_id, idempotency_key)`
- `release_reservation(reservation_id)`
- `start_data_extraction(dataset_id, runtime, policy_id, idempotency_key)`
- `get_extraction_status(job_id)`
- `start_data_loading(extraction_job_id, target_environment, idempotency_key)`
- `post_transaction(account_id, amount, currency, idempotency_key)` — disabled by default

## Important security notes

1. Replace demo adapters with real integrations before production.
2. The included reservation adapter is in-memory and **not safe across multiple replicas**.
3. The sample does not implement enterprise authentication or authorization middleware. Do not expose it to untrusted networks.
4. Keep secrets out of source control; use your enterprise secret manager.
5. For PII, never log raw input or output. Confirm redaction quality with representative test data.
6. For transactions, use a dedicated authoritative service, idempotency, limits, audit trails, and required approvals. The sample transaction tool is disabled unless `ENABLE_TRANSACTION_TOOL=true`.
7. Extraction jobs should use durable job tracking and idempotent submission. A timeout after submission may leave the true outcome unknown; reconcile before retrying.
8. Validate the pinned SDK version, transport configuration, and protocol compatibility in CI.

## Project layout

```text
app/
  server.py          MCP tool definitions and routing
  services.py        Demo adapters; replace with real business integrations
tests/
  test_services.py   Basic unit tests for demo behavior
Dockerfile
requirements.txt
.env.example
```

## Integration points

Implement `PiiService`, `SearchService`, `ReservationService`, and `JobService` in `app/services.py` or replace them with dependency-injected clients for your actual services. Map runtime names to allow-listed APIs; do not let the LLM freely select arbitrary endpoints. Enforce consumer-level permissions in your identity/authorization layer.
