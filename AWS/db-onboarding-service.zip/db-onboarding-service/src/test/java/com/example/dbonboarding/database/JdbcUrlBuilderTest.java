package com.example.dbonboarding.database;

import static org.assertj.core.api.Assertions.assertThat;

import org.junit.jupiter.api.Test;

class JdbcUrlBuilderTest {

    @Test
    void buildsUrlsPerEngine() {
        assertThat(JdbcUrlBuilder.build("postgresql", "h", 5432, "orders", "require"))
                .isEqualTo("jdbc:postgresql://h:5432/orders?ssl=true&sslmode=require");
        assertThat(JdbcUrlBuilder.build("mysql", "h", 3306, "billing", "verify-full"))
                .isEqualTo("jdbc:mysql://h:3306/billing?sslMode=VERIFY_IDENTITY");
        assertThat(JdbcUrlBuilder.build("oracle", "h", 1521, "ORCL", "require"))
                .isEqualTo("jdbc:oracle:thin:@//h:1521/ORCL");
        assertThat(JdbcUrlBuilder.build("sqlserver", "h", 1433, "db", "verify-full"))
                .isEqualTo("jdbc:sqlserver://h:1433;databaseName=db;encrypt=true;trustServerCertificate=false");
    }
}
