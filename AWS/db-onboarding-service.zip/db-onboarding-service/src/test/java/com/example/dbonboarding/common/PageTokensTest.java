package com.example.dbonboarding.common;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import java.util.Map;
import org.junit.jupiter.api.Test;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

class PageTokensTest {

    @Test
    void roundTrips() {
        Map<String, AttributeValue> key = Map.of(
                "app_id", AttributeValue.builder().s("APP12345").build(),
                "created_at", AttributeValue.builder().s("2026-10-27T06:39:00Z").build(),
                "n", AttributeValue.builder().n("42").build());
        assertThat(PageTokens.decode(PageTokens.encode(key))).isEqualTo(key);
    }

    @Test
    void emptyKeyHasNoToken() {
        assertThat(PageTokens.encode(Map.of())).isNull();
        assertThat(PageTokens.decode(null)).isNull();
    }

    @Test
    void garbageTokenIsBadRequest() {
        assertThatThrownBy(() -> PageTokens.decode("not-a-token!"))
                .isInstanceOf(ApiException.class);
    }

    @Test
    void idsHaveExpectedShape() {
        assertThat(Ids.newId("dx")).matches("^dx-\\d{8}-[0-9a-f]{6}$");
        assertThat(Ids.now()).matches("^\\d{4}-\\d{2}-\\d{2}T\\d{2}:\\d{2}:\\d{2}Z$");
    }
}
