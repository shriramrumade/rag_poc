package com.example.dbonboarding.extraction;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.example.dbonboarding.common.ApiException;
import com.example.dbonboarding.extraction.ExtractionDtos.CreateDataExtractionRequest;
import com.example.dbonboarding.extraction.ExtractionDtos.FilterSpec;
import com.example.dbonboarding.extraction.ExtractionDtos.RelationshipSpec;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.junit.jupiter.api.Test;

class ExtractionValidatorTest {

    private static final Map<String, Set<String>> META = Map.of(
            "public.orders", Set.of("order_id", "customer_id", "amount", "updated_at"),
            "public.customers", Set.of("customer_id", "name", "email"));

    private static final List<RelationshipSpec> JOIN = List.of(
            new RelationshipSpec("public.orders.customer_id", "public.customers.customer_id", "INNER"));

    @Test
    void acceptsValidRequestWithoutQuery() {
        ExtractionValidator.validate(request(JOIN, List.of(
                new FilterSpec("public.orders.amount", "GT", List.of(0)),
                new FilterSpec("public.customers.email", "IS_NOT_NULL", List.of()))), META);
    }

    @Test
    void unknownTableAndColumn() {
        assertCode(() -> ExtractionValidator.validate(new CreateDataExtractionRequest("A", "d",
                List.of("public.missing"), null, null, null, null), META), "TABLE_NOT_FOUND");
        assertCode(() -> ExtractionValidator.validate(request(JOIN, List.of(
                new FilterSpec("public.orders.nope", "EQ", List.of(1)))), META), "COLUMN_NOT_FOUND");
    }

    @Test
    void filterOperatorsAndValueCounts() {
        assertCode(() -> ExtractionValidator.validate(request(JOIN, List.of(
                new FilterSpec("public.orders.amount", "BETWEEN", List.of(1)))), META), "INVALID_FILTER");
        assertCode(() -> ExtractionValidator.validate(request(JOIN, List.of(
                new FilterSpec("public.orders.amount", "SOUNDS_LIKE", List.of(1)))), META), "INVALID_FILTER");
    }

    @Test
    void tablesMustBeJoinedWhenNoQuery() {
        assertCode(() -> ExtractionValidator.validate(request(List.of(), List.of()), META), "INVALID_SCHEMA");
    }

    private static CreateDataExtractionRequest request(List<RelationshipSpec> rels, List<FilterSpec> filters) {
        return new CreateDataExtractionRequest("APP12345", "orders_db",
                List.of("public.orders", "public.customers"), rels, null, null, filters);
    }

    private static void assertCode(Runnable r, String code) {
        assertThatThrownBy(r::run).isInstanceOf(ApiException.class)
                .satisfies(e -> assertThat(((ApiException) e).code()).isEqualTo(code));
    }
}
