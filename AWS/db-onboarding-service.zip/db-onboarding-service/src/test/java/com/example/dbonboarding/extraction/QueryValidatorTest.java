package com.example.dbonboarding.extraction;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.example.dbonboarding.common.ApiException;
import java.util.Map;
import org.junit.jupiter.api.Test;

class QueryValidatorTest {

    private static final String SQL = "SELECT o.order_id, o.amount, c.email FROM public.orders o "
            + "INNER JOIN public.customers c ON o.customer_id = c.customer_id "
            + "WHERE o.updated_at BETWEEN :start_date AND :end_date";

    @Test
    void acceptsParameterizedSelect() {
        QueryValidator.validate(SQL, Map.of("start_date", "2026-07-01T00:00:00Z", "end_date", "2026-09-30T23:59:59Z"));
        QueryValidator.validate(SQL + ";", Map.of("start_date", "a", "end_date", "b"));
    }

    @Test
    void rejectsSecondStatement() {
        assertInvalid("SELECT 1; DROP TABLE public.orders", Map.of());
    }

    @Test
    void rejectsNonSelect() {
        assertInvalid("DELETE FROM public.orders", Map.of());
        assertInvalid("UPDATE public.orders SET amount = 0", Map.of());
    }

    @Test
    void rejectsCommentsAndSelectInto() {
        assertInvalid("SELECT * FROM public.orders -- trailing", Map.of());
        assertInvalid("SELECT * INTO backup FROM public.orders", Map.of());
    }

    @Test
    void parametersMustMatch() {
        assertInvalid(SQL, Map.of("start_date", "a"));
        assertInvalid(SQL, Map.of("start_date", "a", "end_date", "b", "extra", "c"));
        assertInvalid(SQL, Map.of("start_date", Map.of("x", 1), "end_date", "b"));
    }

    @Test
    void semicolonsAndColonsInsideLiteralsAreFine() {
        QueryValidator.validate("SELECT * FROM public.orders WHERE note = 'a;b :not_param' AND id = :id",
                Map.of("id", 5));
    }

    @Test
    void findsNamedParametersButNotCasts() {
        assertThat(QueryValidator.namedParameters("SELECT x::date FROM t WHERE a = :a AND b = :b_2"))
                .containsExactly("a", "b_2");
    }

    private static void assertInvalid(String sql, Map<String, Object> params) {
        assertThatThrownBy(() -> QueryValidator.validate(sql, params))
                .isInstanceOf(ApiException.class)
                .satisfies(e -> assertThat(((ApiException) e).code()).isEqualTo("INVALID_QUERY"));
    }
}
