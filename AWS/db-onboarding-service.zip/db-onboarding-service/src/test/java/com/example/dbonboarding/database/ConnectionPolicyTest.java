package com.example.dbonboarding.database;

import static org.assertj.core.api.Assertions.assertThat;
import static org.assertj.core.api.Assertions.assertThatThrownBy;

import com.example.dbonboarding.common.ApiException;
import com.example.dbonboarding.config.AppProperties;
import java.util.List;
import java.util.Map;
import org.junit.jupiter.api.Test;

class ConnectionPolicyTest {

    private final ConnectionPolicy policy = new ConnectionPolicy(new AppProperties.Policy(
            List.of(".rds.amazonaws.com", ".internal.example.com"),
            List.of("10.0.0.0/8"),
            Map.of("postgresql", List.of(5432), "mysql", List.of(3306)),
            List.of("us-west-2"),
            List.of("222233334444")));

    @Test
    void acceptsApprovedHostsAndNormalizesCase() {
        assertThat(policy.normalizeHost("Orders-DB.abc123.us-west-2.RDS.amazonaws.com"))
                .isEqualTo("orders-db.abc123.us-west-2.rds.amazonaws.com");
        assertThat(policy.normalizeHost("10.20.30.40")).isEqualTo("10.20.30.40");
    }

    @Test
    void rejectsHostsOutsideTheAllowlist() {
        assertCode(() -> policy.normalizeHost("evil.example.org"), "HOST_NOT_ALLOWED");
        assertCode(() -> policy.normalizeHost("192.168.1.10"), "HOST_NOT_ALLOWED");
        assertCode(() -> policy.normalizeHost("db.internal.example.com?socketFactory=x"), "HOST_NOT_ALLOWED");
        assertCode(() -> policy.normalizeHost("999.1.1.1"), "HOST_NOT_ALLOWED");
    }

    @Test
    void checksPortPerEngine() {
        policy.validatePort("postgresql", 5432);
        assertCode(() -> policy.validatePort("postgresql", 3306), "PORT_NOT_ALLOWED");
        assertCode(() -> policy.validatePort("oracle", 1521), "PORT_NOT_ALLOWED");
    }

    @Test
    void iamAuthNeedsRdsHostAndUser() {
        policy.validateAuth("postgresql", "a.b.us-west-2.rds.amazonaws.com", "iam", "glue_reader");
        assertCode(() -> policy.validateAuth("postgresql", "db.internal.example.com", "iam", "glue_reader"),
                "IAM_AUTH_NOT_SUPPORTED");
        assertCode(() -> policy.validateAuth("oracle", "a.rds.amazonaws.com", "iam", "glue_reader"),
                "IAM_AUTH_NOT_SUPPORTED");
        assertCode(() -> policy.validateAuth("postgresql", "a.rds.amazonaws.com", "iam", null), "INVALID_SCHEMA");
        policy.validateAuth("postgresql", "db.internal.example.com", "secret", null);
    }

    @Test
    void targetAccountMustBeOnboarded() {
        policy.validateTarget("222233334444", "us-west-2");
        assertCode(() -> policy.validateTarget("999999999999", "us-west-2"), "ACCOUNT_NOT_ONBOARDED");
        assertCode(() -> policy.validateTarget("222233334444", "eu-west-1"), "REGION_NOT_ALLOWED");
    }

    @Test
    void sslModeDefaultsToRequire() {
        assertThat(policy.normalizeSslMode(null)).isEqualTo("require");
        assertCode(() -> policy.normalizeSslMode("disable"), "INVALID_SCHEMA");
    }

    private static void assertCode(Runnable r, String code) {
        assertThatThrownBy(r::run).isInstanceOf(ApiException.class)
                .satisfies(e -> assertThat(((ApiException) e).code()).isEqualTo(code));
    }
}
