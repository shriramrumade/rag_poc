package com.example.dbonboarding.metadata;

import com.example.dbonboarding.common.ApiException;
import com.fasterxml.jackson.databind.JsonNode;
import java.util.Set;

/** Allowed values for the column governance fields (is_sensitive, pii_type, classification, pii_rule). */
public final class GovernanceRules {

    public static final Set<String> PII_TYPES = Set.of(
            "EMAIL", "PERSON_NAME", "PHONE", "SSN", "ADDRESS", "DOB", "CREDIT_CARD", "IP_ADDRESS");
    public static final Set<String> CLASSIFICATIONS = Set.of("PUBLIC", "INTERNAL", "CONFIDENTIAL", "RESTRICTED");
    public static final Set<String> PII_ACTIONS = Set.of("NONE", "MASK", "HASH", "REDACT", "TOKENIZE", "DROP");

    /** Column fields a user may edit. Everything else comes from the source database. */
    public static final Set<String> EDITABLE_COLUMN_FIELDS = Set.of(
            "name", "is_sensitive", "pii_type", "classification", "pii_rule");
    public static final Set<String> READ_ONLY_COLUMN_FIELDS = Set.of("type", "nullable", "position", "detection");

    private GovernanceRules() {
    }

    public static void validate(String field, String key, JsonNode value) {
        switch (key) {
            case "is_sensitive" -> {
                if (!value.isBoolean()) {
                    throw ApiException.badRequest("INVALID_SCHEMA", "is_sensitive must be true or false", field);
                }
            }
            case "pii_type" -> {
                if (!value.isNull() && !PII_TYPES.contains(value.asText())) {
                    throw ApiException.badRequest("INVALID_SCHEMA", "pii_type must be one of " + PII_TYPES + " or null", field);
                }
            }
            case "classification" -> {
                if (!CLASSIFICATIONS.contains(value.asText())) {
                    throw ApiException.badRequest("INVALID_SCHEMA", "classification must be one of " + CLASSIFICATIONS, field);
                }
            }
            case "pii_rule" -> {
                if (value.isNull()) {
                    return;
                }
                if (!value.isObject() || !value.path("rule_id").isTextual()
                        || !PII_ACTIONS.contains(value.path("action").asText())) {
                    throw ApiException.badRequest("INVALID_SCHEMA",
                            "pii_rule needs a rule_id and an action in " + PII_ACTIONS, field);
                }
            }
            default -> { }
        }
    }
}
