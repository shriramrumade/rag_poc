package com.example.dbonboarding.load;

import com.example.dbonboarding.glue.GlueTarget;
import software.amazon.awssdk.enhanced.dynamodb.extensions.annotations.DynamoDbVersionAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbIgnore;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondaryPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondarySortKey;

/**
 * Table {@code data_loads}: one item per data load. Same index layout as extraction requests.
 */
@DynamoDbBean
public class DataLoadRecord {

    public static final String APP_INDEX = "app-index";
    public static final String ACTIVE_INDEX = "active-index";

    private String loadId;
    private String appId;
    private String dbId;
    private String requestId;
    private String retryOf;
    private String active;
    private String status;
    private String targetType;
    private String targetId;
    private String targetSchema;
    private String targetTable;
    private String loadMode;
    private String mergeKeysJson;
    private Boolean createTableIfMissing;
    private String sourcePath;
    private String sourceFormat;
    private String resultPath;
    private String glueJobRunId;
    private String targetAccountId;
    private String region;
    private String submittedBy;
    private String submittedAt;
    private String startedAt;
    private String completedAt;
    private String stopRequestedBy;
    private String stopRequestedAt;
    private String stopReason;
    private String progressJson;
    private String resultJson;
    private String errorJson;
    private Long version;

    @DynamoDbIgnore
    public GlueTarget glueTarget() {
        return new GlueTarget(targetAccountId, region);
    }

    @DynamoDbPartitionKey
    @DynamoDbAttribute("load_id")
    public String getLoadId() {
        return loadId;
    }

    public void setLoadId(String loadId) {
        this.loadId = loadId;
    }

    @DynamoDbSecondaryPartitionKey(indexNames = APP_INDEX)
    @DynamoDbAttribute("app_id")
    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    @DynamoDbAttribute("db_id")
    public String getDbId() {
        return dbId;
    }

    public void setDbId(String dbId) {
        this.dbId = dbId;
    }

    @DynamoDbAttribute("request_id")
    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    @DynamoDbAttribute("retry_of")
    public String getRetryOf() {
        return retryOf;
    }

    public void setRetryOf(String retryOf) {
        this.retryOf = retryOf;
    }

    @DynamoDbSecondaryPartitionKey(indexNames = ACTIVE_INDEX)
    @DynamoDbAttribute("active")
    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    @DynamoDbAttribute("status")
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @DynamoDbAttribute("target_type")
    public String getTargetType() {
        return targetType;
    }

    public void setTargetType(String targetType) {
        this.targetType = targetType;
    }

    @DynamoDbAttribute("target_id")
    public String getTargetId() {
        return targetId;
    }

    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }

    @DynamoDbAttribute("target_schema")
    public String getTargetSchema() {
        return targetSchema;
    }

    public void setTargetSchema(String targetSchema) {
        this.targetSchema = targetSchema;
    }

    @DynamoDbAttribute("target_table")
    public String getTargetTable() {
        return targetTable;
    }

    public void setTargetTable(String targetTable) {
        this.targetTable = targetTable;
    }

    @DynamoDbAttribute("load_mode")
    public String getLoadMode() {
        return loadMode;
    }

    public void setLoadMode(String loadMode) {
        this.loadMode = loadMode;
    }

    @DynamoDbAttribute("merge_keys_json")
    public String getMergeKeysJson() {
        return mergeKeysJson;
    }

    public void setMergeKeysJson(String mergeKeysJson) {
        this.mergeKeysJson = mergeKeysJson;
    }

    @DynamoDbAttribute("create_table_if_missing")
    public Boolean getCreateTableIfMissing() {
        return createTableIfMissing;
    }

    public void setCreateTableIfMissing(Boolean createTableIfMissing) {
        this.createTableIfMissing = createTableIfMissing;
    }

    @DynamoDbAttribute("source_path")
    public String getSourcePath() {
        return sourcePath;
    }

    public void setSourcePath(String sourcePath) {
        this.sourcePath = sourcePath;
    }

    @DynamoDbAttribute("source_format")
    public String getSourceFormat() {
        return sourceFormat;
    }

    public void setSourceFormat(String sourceFormat) {
        this.sourceFormat = sourceFormat;
    }

    @DynamoDbAttribute("result_path")
    public String getResultPath() {
        return resultPath;
    }

    public void setResultPath(String resultPath) {
        this.resultPath = resultPath;
    }

    @DynamoDbAttribute("glue_job_run_id")
    public String getGlueJobRunId() {
        return glueJobRunId;
    }

    public void setGlueJobRunId(String glueJobRunId) {
        this.glueJobRunId = glueJobRunId;
    }

    @DynamoDbAttribute("target_account_id")
    public String getTargetAccountId() {
        return targetAccountId;
    }

    public void setTargetAccountId(String targetAccountId) {
        this.targetAccountId = targetAccountId;
    }

    @DynamoDbAttribute("region")
    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    @DynamoDbAttribute("submitted_by")
    public String getSubmittedBy() {
        return submittedBy;
    }

    public void setSubmittedBy(String submittedBy) {
        this.submittedBy = submittedBy;
    }

    @DynamoDbSecondarySortKey(indexNames = {APP_INDEX, ACTIVE_INDEX})
    @DynamoDbAttribute("submitted_at")
    public String getSubmittedAt() {
        return submittedAt;
    }

    public void setSubmittedAt(String submittedAt) {
        this.submittedAt = submittedAt;
    }

    @DynamoDbAttribute("started_at")
    public String getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(String startedAt) {
        this.startedAt = startedAt;
    }

    @DynamoDbAttribute("completed_at")
    public String getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(String completedAt) {
        this.completedAt = completedAt;
    }

    @DynamoDbAttribute("stop_requested_by")
    public String getStopRequestedBy() {
        return stopRequestedBy;
    }

    public void setStopRequestedBy(String stopRequestedBy) {
        this.stopRequestedBy = stopRequestedBy;
    }

    @DynamoDbAttribute("stop_requested_at")
    public String getStopRequestedAt() {
        return stopRequestedAt;
    }

    public void setStopRequestedAt(String stopRequestedAt) {
        this.stopRequestedAt = stopRequestedAt;
    }

    @DynamoDbAttribute("stop_reason")
    public String getStopReason() {
        return stopReason;
    }

    public void setStopReason(String stopReason) {
        this.stopReason = stopReason;
    }

    @DynamoDbAttribute("progress_json")
    public String getProgressJson() {
        return progressJson;
    }

    public void setProgressJson(String progressJson) {
        this.progressJson = progressJson;
    }

    @DynamoDbAttribute("result_json")
    public String getResultJson() {
        return resultJson;
    }

    public void setResultJson(String resultJson) {
        this.resultJson = resultJson;
    }

    @DynamoDbAttribute("error_json")
    public String getErrorJson() {
        return errorJson;
    }

    public void setErrorJson(String errorJson) {
        this.errorJson = errorJson;
    }

    @DynamoDbVersionAttribute
    @DynamoDbAttribute("version")
    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }
}
