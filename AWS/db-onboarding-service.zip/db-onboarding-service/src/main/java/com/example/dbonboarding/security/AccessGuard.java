package com.example.dbonboarding.security;

import com.example.dbonboarding.common.ApiException;
import com.example.dbonboarding.config.AppProperties;
import java.util.List;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.server.resource.authentication.JwtAuthenticationToken;
import org.springframework.stereotype.Component;

/**
 * App-level authorization from the user's token groups.
 * <ul>
 *   <li>{@code adminGroup} may act on every app.</li>
 *   <li>{@code appGroupPrefix + app_id} (e.g. app:APP12345) may act on that app.</li>
 *   <li>Registering, changing or deleting databases also needs {@code onboarderGroup}.</li>
 * </ul>
 */
@Component
public class AccessGuard {

    private final AppProperties.Security cfg;

    public AccessGuard(AppProperties props) {
        this.cfg = props.security();
    }

    /** Fails with 403 unless the caller may act on this app. */
    public void requireApp(String appId) {
        List<String> groups = groups();
        if (groups.contains(cfg.adminGroup())) {
            return;
        }
        if (appId == null || !groups.contains(cfg.appGroupPrefix() + appId)) {
            throw ApiException.forbidden("user lacks rights for app_id '" + appId + "'");
        }
    }

    /** Fails with 403 unless the caller may onboard databases for this app. */
    public void requireOnboarder(String appId) {
        requireApp(appId);
        List<String> groups = groups();
        if (!groups.contains(cfg.adminGroup()) && !groups.contains(cfg.onboarderGroup())) {
            throw ApiException.forbidden("user is not in the '" + cfg.onboarderGroup() + "' group");
        }
    }

    /** The caller's identity as recorded in created_by / submitted_by. */
    public String userId() {
        Jwt jwt = jwt();
        String user = jwt.getClaimAsString(cfg.userClaim());
        return user != null ? user : jwt.getSubject();
    }

    private List<String> groups() {
        List<String> groups = jwt().getClaimAsStringList(cfg.groupsClaim());
        return groups == null ? List.of() : groups;
    }

    private Jwt jwt() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth instanceof JwtAuthenticationToken token) {
            return token.getToken();
        }
        throw new ApiException(org.springframework.http.HttpStatus.UNAUTHORIZED,
                "UNAUTHENTICATED", "token missing, expired or invalid", null);
    }
}
