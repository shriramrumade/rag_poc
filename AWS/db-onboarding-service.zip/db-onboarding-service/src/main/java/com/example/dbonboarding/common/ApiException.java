package com.example.dbonboarding.common;

import org.springframework.http.HttpStatus;

/**
 * An error returned to the caller in the standard {"error": {code, message, field}} shape.
 */
public class ApiException extends RuntimeException {

    private final HttpStatus status;
    private final String code;
    private final String field;

    public ApiException(HttpStatus status, String code, String message, String field) {
        super(message);
        this.status = status;
        this.code = code;
        this.field = field;
    }

    public HttpStatus status() {
        return status;
    }

    public String code() {
        return code;
    }

    public String field() {
        return field;
    }

    public static ApiException badRequest(String code, String message, String field) {
        return new ApiException(HttpStatus.BAD_REQUEST, code, message, field);
    }

    public static ApiException notFound(String code, String message, String field) {
        return new ApiException(HttpStatus.NOT_FOUND, code, message, field);
    }

    public static ApiException conflict(String code, String message, String field) {
        return new ApiException(HttpStatus.CONFLICT, code, message, field);
    }

    public static ApiException unprocessable(String code, String message, String field) {
        return new ApiException(HttpStatus.UNPROCESSABLE_ENTITY, code, message, field);
    }

    public static ApiException forbidden(String message) {
        return new ApiException(HttpStatus.FORBIDDEN, "NOT_AUTHORIZED", message, null);
    }

    public static ApiException versionMismatch(String message) {
        return new ApiException(HttpStatus.PRECONDITION_FAILED, "VERSION_MISMATCH", message, "version");
    }

    public static ApiException rateLimited(String message) {
        return new ApiException(HttpStatus.TOO_MANY_REQUESTS, "RATE_LIMITED", message, null);
    }
}
