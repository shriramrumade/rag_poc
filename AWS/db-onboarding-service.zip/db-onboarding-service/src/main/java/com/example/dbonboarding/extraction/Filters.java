package com.example.dbonboarding.extraction;

import com.example.dbonboarding.common.ApiException;
import com.example.dbonboarding.common.RunStatus;
import java.util.ArrayList;
import java.util.List;
import software.amazon.awssdk.enhanced.dynamodb.Expression;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

/** Builds the optional db_id / status filter used by the list endpoints. */
public final class Filters {

    private Filters() {
    }

    /** @return null when neither filter is given */
    public static Expression dbAndStatus(String dbId, List<String> statuses) {
        List<String> parts = new ArrayList<>();
        Expression.Builder b = Expression.builder();
        if (dbId != null && !dbId.isBlank()) {
            parts.add("#db = :db");
            b.putExpressionName("#db", "db_id");
            b.putExpressionValue(":db", AttributeValue.builder().s(dbId).build());
        }
        if (statuses != null && !statuses.isEmpty()) {
            List<String> refs = new ArrayList<>();
            for (int i = 0; i < statuses.size(); i++) {
                String s = statuses.get(i).trim().toUpperCase(java.util.Locale.ROOT);
                if (!RunStatus.ALL.contains(s)) {
                    throw ApiException.badRequest("INVALID_SCHEMA", "unknown status '" + s + "'", "status");
                }
                refs.add(":s" + i);
                b.putExpressionValue(":s" + i, AttributeValue.builder().s(s).build());
            }
            parts.add("#st IN (" + String.join(", ", refs) + ")");
            b.putExpressionName("#st", "status");
        }
        if (parts.isEmpty()) {
            return null;
        }
        return b.expression(String.join(" AND ", parts)).build();
    }
}
