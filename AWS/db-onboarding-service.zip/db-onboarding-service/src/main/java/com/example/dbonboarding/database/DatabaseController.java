package com.example.dbonboarding.database;

import com.example.dbonboarding.common.ListResponse;
import com.example.dbonboarding.common.Versions;
import com.example.dbonboarding.database.DatabaseDtos.CreateDatabaseRequest;
import com.example.dbonboarding.database.DatabaseDtos.DatabaseResponse;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.validation.Valid;
import java.net.URI;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** APIs 1 to 5: /v1/databases */
@RestController
@RequestMapping("/v1/databases")
public class DatabaseController {

    private final DatabaseService service;

    public DatabaseController(DatabaseService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<DatabaseResponse> create(
            @Valid @RequestBody CreateDatabaseRequest body,
            @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey) {
        DatabaseRecord rec = service.create(body, idempotencyKey);
        return ResponseEntity.created(URI.create("/v1/databases/" + rec.getDbId()))
                .eTag(Versions.etag(rec.getVersion()))
                .body(DatabaseResponse.from(rec));
    }

    @GetMapping("/{dbId}")
    public ResponseEntity<DatabaseResponse> get(@PathVariable String dbId) {
        DatabaseRecord rec = service.get(dbId);
        return ResponseEntity.ok().eTag(Versions.etag(rec.getVersion())).body(DatabaseResponse.from(rec));
    }

    @GetMapping
    public ListResponse<DatabaseResponse> list(
            @RequestParam("app_id") String appId,
            @RequestParam(value = "limit", defaultValue = "20") int limit,
            @RequestParam(value = "next_token", required = false) String nextToken) {
        return service.list(appId, limit, nextToken);
    }

    @PatchMapping("/{dbId}")
    public ResponseEntity<DatabaseResponse> update(
            @PathVariable String dbId,
            @RequestHeader("If-Match") String ifMatch,
            @RequestBody ObjectNode body) {
        DatabaseRecord rec = service.update(dbId, Versions.parseIfMatch(ifMatch), body);
        return ResponseEntity.ok().eTag(Versions.etag(rec.getVersion())).body(DatabaseResponse.from(rec));
    }

    @DeleteMapping("/{dbId}")
    public ResponseEntity<Void> delete(@PathVariable String dbId, @RequestHeader("If-Match") String ifMatch) {
        service.delete(dbId, Versions.parseIfMatch(ifMatch));
        return ResponseEntity.noContent().build();
    }
}
