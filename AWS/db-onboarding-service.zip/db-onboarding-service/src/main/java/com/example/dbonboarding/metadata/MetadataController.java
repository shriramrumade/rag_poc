package com.example.dbonboarding.metadata;

import com.example.dbonboarding.common.JsonAttr;
import com.example.dbonboarding.common.Versions;
import com.example.dbonboarding.metadata.MetadataDtos.FetchMetadataResponse;
import com.example.dbonboarding.metadata.MetadataDtos.MetadataExtractionResponse;
import com.example.dbonboarding.metadata.MetadataDtos.StartMetadataExtractionRequest;
import com.fasterxml.jackson.databind.node.ObjectNode;
import jakarta.validation.Valid;
import java.net.URI;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** APIs 6 to 9: metadata extraction runs and stored metadata. */
@RestController
public class MetadataController {

    private final MetadataExtractionService extractions;
    private final MetadataService metadata;
    private final JsonAttr json;

    public MetadataController(MetadataExtractionService extractions, MetadataService metadata, JsonAttr json) {
        this.extractions = extractions;
        this.metadata = metadata;
        this.json = json;
    }

    // 6
    @PostMapping("/v1/metadata-extractions")
    public ResponseEntity<MetadataExtractionResponse> start(
            @Valid @RequestBody StartMetadataExtractionRequest body,
            @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey) {
        MetadataExtractionRecord rec = extractions.start(body, idempotencyKey);
        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .location(URI.create("/v1/metadata-extractions/" + rec.getExtractionId()))
                .body(MetadataExtractionResponse.from(rec, json));
    }

    // 7
    @GetMapping("/v1/metadata-extractions/{extractionId}")
    public MetadataExtractionResponse status(@PathVariable String extractionId) {
        return MetadataExtractionResponse.from(extractions.get(extractionId), json);
    }

    // 8
    @GetMapping("/v1/metadata")
    public FetchMetadataResponse fetch(
            @RequestParam("app_id") String appId,
            @RequestParam("db_id") String dbId,
            @RequestParam(value = "limit", defaultValue = "50") int limit,
            @RequestParam(value = "next_token", required = false) String nextToken) {
        return metadata.fetch(appId, dbId, limit, nextToken);
    }

    // 9
    @PatchMapping("/v1/metadata/tables/{tableKey}")
    public ResponseEntity<ObjectNode> updateTable(
            @PathVariable String tableKey,
            @RequestParam("app_id") String appId,
            @RequestParam("db_id") String dbId,
            @RequestHeader("If-Match") String ifMatch,
            @RequestBody ObjectNode body) {
        ObjectNode out = metadata.updateTable(appId, dbId, tableKey, Versions.parseIfMatch(ifMatch), body);
        return ResponseEntity.ok().eTag(Versions.etag(out.path("version").asLong())).body(out);
    }
}
