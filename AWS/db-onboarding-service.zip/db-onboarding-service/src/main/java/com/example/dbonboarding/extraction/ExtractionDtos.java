package com.example.dbonboarding.extraction;

import com.example.dbonboarding.common.JsonAttr;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.util.List;
import java.util.Map;

/** Request and response bodies for /v1/data-extractions. */
public final class ExtractionDtos {

    public static final String TABLE_REF = "^[A-Za-z0-9_]+\\.[A-Za-z0-9_]+$";
    public static final String COLUMN_REF = "^[A-Za-z0-9_]+\\.[A-Za-z0-9_]+\\.[A-Za-z0-9_]+$";

    private ExtractionDtos() {
    }

    public record CreateDataExtractionRequest(
            @NotBlank String appId,
            @NotBlank String dbId,
            @NotEmpty @Size(max = 50) List<@Pattern(regexp = TABLE_REF) String> tables,
            @Size(max = 50) List<@Valid RelationshipSpec> relationships,
            @Size(max = 20000) String query,
            @Size(max = 100) Map<String, Object> parameters,
            @Size(max = 100) List<@Valid FilterSpec> filters) {
    }

    public record RelationshipSpec(
            @NotBlank @Pattern(regexp = COLUMN_REF) String from,
            @NotBlank @Pattern(regexp = COLUMN_REF) String to,
            String joinType) {
    }

    public record FilterSpec(
            @NotBlank @Pattern(regexp = COLUMN_REF) String column,
            @NotBlank String operator,
            @Size(max = 1000) List<Object> values) {
    }

    public record ExecuteDataExtractionRequest(
            @NotBlank String appId,
            @NotBlank String dbId,
            @Valid OutputSpec output,
            Boolean applyPiiRules) {
    }

    public record OutputSpec(String format, String targetS3Path) {
    }

    public record StopRequest(@Size(max = 500) String reason) {
    }

    public record DataExtractionResponse(
            String requestId,
            String appId,
            String dbId,
            String status,
            String retryOf,
            JsonNode tables,
            JsonNode relationships,
            String query,
            JsonNode parameters,
            JsonNode filters,
            String glueJobName,
            String glueJobRunId,
            JsonNode progress,
            String submittedBy,
            String submittedAt,
            String executedBy,
            String executedAt,
            String startedAt,
            String completedAt,
            String stopRequestedBy,
            String stopRequestedAt,
            JsonNode output,
            JsonNode error) {

        public static DataExtractionResponse from(ExtractionRequestRecord r, String jobName, JsonAttr json) {
            return new DataExtractionResponse(r.getRequestId(), r.getAppId(), r.getDbId(), r.getStatus(),
                    r.getRetryOf(), json.read(r.getTablesJson()), json.read(r.getRelationshipsJson()), r.getQuery(),
                    json.read(r.getParametersJson()), json.read(r.getFiltersJson()),
                    r.getGlueJobRunId() == null ? null : jobName, r.getGlueJobRunId(),
                    json.read(r.getProgressJson()), r.getSubmittedBy(), r.getSubmittedAt(), r.getExecutedBy(),
                    r.getExecutedAt(), r.getStartedAt(), r.getCompletedAt(), r.getStopRequestedBy(),
                    r.getStopRequestedAt(), json.read(r.getOutputJson()), json.read(r.getErrorJson()));
        }

        /** List items carry the summary only. */
        public static DataExtractionResponse summary(ExtractionRequestRecord r, JsonAttr json) {
            return new DataExtractionResponse(r.getRequestId(), null, r.getDbId(), r.getStatus(), r.getRetryOf(),
                    null, null, null, null, null, null, null, json.read(r.getProgressJson()), r.getSubmittedBy(),
                    r.getSubmittedAt(), null, null, null, r.getCompletedAt(), null, null, null, null);
        }
    }
}
