package com.example.dbonboarding.metadata;

import software.amazon.awssdk.enhanced.dynamodb.extensions.annotations.DynamoDbVersionAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbIgnore;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSortKey;

/**
 * Table {@code table_metadata}. Partition {@code app_db} = "APP12345#orders_db".
 * Sort key {@code table_key} is "schema.table" for a table, or one of the special keys
 * {@link #SUMMARY} and {@link #RELATIONSHIPS} that hold database-level data.
 */
@DynamoDbBean
public class TableMetadataRecord {

    public static final String SUMMARY = "#SUMMARY";
    public static final String RELATIONSHIPS = "#RELATIONSHIPS";

    private String appDb;
    private String tableKey;
    private String schemaName;
    private String tableName;
    private String description;
    private Long rowCountEstimate;
    private String primaryKeyJson;
    private String columnsJson;
    private String payloadJson;
    private String updatedBy;
    private String updatedAt;
    private Long version;

    public static String appDb(String appId, String dbId) {
        return appId + "#" + dbId;
    }

    @DynamoDbIgnore
    public boolean isSpecial() {
        return tableKey != null && tableKey.startsWith("#");
    }

    @DynamoDbPartitionKey
    @DynamoDbAttribute("app_db")
    public String getAppDb() {
        return appDb;
    }

    public void setAppDb(String appDb) {
        this.appDb = appDb;
    }

    @DynamoDbSortKey
    @DynamoDbAttribute("table_key")
    public String getTableKey() {
        return tableKey;
    }

    public void setTableKey(String tableKey) {
        this.tableKey = tableKey;
    }

    @DynamoDbAttribute("schema_name")
    public String getSchemaName() {
        return schemaName;
    }

    public void setSchemaName(String schemaName) {
        this.schemaName = schemaName;
    }

    @DynamoDbAttribute("table_name")
    public String getTableName() {
        return tableName;
    }

    public void setTableName(String tableName) {
        this.tableName = tableName;
    }

    @DynamoDbAttribute("description")
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    @DynamoDbAttribute("row_count_estimate")
    public Long getRowCountEstimate() {
        return rowCountEstimate;
    }

    public void setRowCountEstimate(Long rowCountEstimate) {
        this.rowCountEstimate = rowCountEstimate;
    }

    @DynamoDbAttribute("primary_key_json")
    public String getPrimaryKeyJson() {
        return primaryKeyJson;
    }

    public void setPrimaryKeyJson(String primaryKeyJson) {
        this.primaryKeyJson = primaryKeyJson;
    }

    @DynamoDbAttribute("columns_json")
    public String getColumnsJson() {
        return columnsJson;
    }

    public void setColumnsJson(String columnsJson) {
        this.columnsJson = columnsJson;
    }

    @DynamoDbAttribute("payload_json")
    public String getPayloadJson() {
        return payloadJson;
    }

    public void setPayloadJson(String payloadJson) {
        this.payloadJson = payloadJson;
    }

    @DynamoDbAttribute("updated_by")
    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @DynamoDbAttribute("updated_at")
    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }

    @DynamoDbVersionAttribute
    @DynamoDbAttribute("version")
    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }
}
