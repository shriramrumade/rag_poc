package com.example.dbonboarding.config;

import java.util.List;
import java.util.Map;
import org.springframework.boot.context.properties.ConfigurationProperties;

/**
 * All service settings, bound from the {@code app.*} keys in application.yml.
 */
@ConfigurationProperties(prefix = "app")
public record AppProperties(
        Aws aws,
        Tables tables,
        Security security,
        Policy policy,
        Glue glue,
        Storage storage,
        Sync sync) {

    /** AWS settings for Account A (where this service runs). */
    public record Aws(
            String region,
            String defaultTargetAccountId,
            String defaultTargetRegion,
            String dynamodbEndpoint) {
    }

    /** DynamoDB table names in Account A. */
    public record Tables(
            String databases,
            String metadataExtractions,
            String tableMetadata,
            String extractionRequests,
            String dataLoads,
            String targets,
            String idempotency,
            String audit) {
    }

    /** Token validation and authorization rules. */
    public record Security(
            String issuerUri,
            String audience,
            String userClaim,
            String groupsClaim,
            String appGroupPrefix,
            String adminGroup,
            String onboarderGroup) {
    }

    /** Validation rules for submitted connection details. */
    public record Policy(
            List<String> allowedHostSuffixes,
            List<String> allowedCidrs,
            Map<String, List<Integer>> allowedPorts,
            List<String> allowedRegions,
            List<String> onboardedAccounts) {
    }

    /** Glue jobs and roles in the target account (Account B). */
    public record Glue(
            String invokerRoleName,
            String crawlerRoleName,
            String externalId,
            String metadataJob,
            String extractJob,
            String loadJob,
            String workerType,
            int metadataWorkers,
            int extractWorkers,
            int loadWorkers,
            int timeoutMinutes,
            int maxInlineSpecBytes,
            int piiSampleRows,
            Map<String, Network> networks) {
    }

    /**
     * VPC placement for Glue connections in one target account (keyed by account ID): a private
     * subnet that can reach the databases and a security group with a self-referencing rule.
     */
    public record Network(String subnetId, List<String> securityGroupIds, String availabilityZone) {
    }

    /**
     * S3 layout in the target account. {@code bucketTemplate} may use {account_id} and {region}.
     */
    public record Storage(
            String bucketTemplate,
            String metadataPrefix,
            String extractsPrefix,
            String loadResultsPrefix,
            String tempPrefix) {
    }

    /** Background sync of Glue run states into DynamoDB. */
    public record Sync(boolean enabled, long intervalMs) {
    }
}
