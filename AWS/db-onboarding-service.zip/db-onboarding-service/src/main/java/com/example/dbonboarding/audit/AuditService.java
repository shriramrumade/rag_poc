package com.example.dbonboarding.audit;

import com.example.dbonboarding.common.CorrelationIdFilter;
import com.example.dbonboarding.common.Ids;
import java.util.UUID;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;

/** Writes an audit trail of every change. A failed audit write is logged, not fatal. */
@Service
public class AuditService {

    private static final Logger log = LoggerFactory.getLogger(AuditService.class);

    private final DynamoDbTable<AuditRecord> table;

    public AuditService(DynamoDbTable<AuditRecord> table) {
        this.table = table;
    }

    public void record(String entity, String action, String userId, String reason, String detail) {
        String now = Ids.now();
        AuditRecord rec = new AuditRecord();
        rec.setEntity(entity);
        rec.setEventKey(now + "#" + UUID.randomUUID().toString().substring(0, 8));
        rec.setAction(action);
        rec.setUserId(userId);
        rec.setReason(reason);
        rec.setDetail(detail);
        rec.setCorrelationId(CorrelationIdFilter.current());
        rec.setAt(now);
        try {
            table.putItem(rec);
        } catch (RuntimeException e) {
            log.warn("audit write failed for {} {}: {}", entity, action, e.getMessage());
        }
        log.info("audit entity={} action={} user={} reason={}", entity, action, userId, reason);
    }
}
