package com.example.dbonboarding.database;

import com.example.dbonboarding.glue.GlueTarget;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbIgnore;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondaryPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondarySortKey;
import software.amazon.awssdk.enhanced.dynamodb.extensions.annotations.DynamoDbVersionAttribute;

/** Table {@code db_registry}: one item per registered database. */
@DynamoDbBean
public class DatabaseRecord {

    public static final String APP_INDEX = "app_id-index";
    public static final String STATUS_REGISTERED = "REGISTERED";
    public static final String STATUS_DELETED = "DELETED";

    private String dbId;
    private String appId;
    private String engine;
    private String host;
    private Integer port;
    private String database;
    private String sslMode;
    private String authType;
    private String dbUser;
    private String secretName;
    private String jdbcUrl;
    private String glueConnection;
    private String targetAccountId;
    private String region;
    private String status;
    private Long version;
    private String createdBy;
    private String createdAt;
    private String updatedBy;
    private String updatedAt;

    @DynamoDbIgnore
    public GlueTarget glueTarget() {
        return new GlueTarget(targetAccountId, region);
    }

    @DynamoDbIgnore
    public boolean isDeleted() {
        return STATUS_DELETED.equals(status);
    }

    @DynamoDbPartitionKey
    @DynamoDbAttribute("db_id")
    public String getDbId() {
        return dbId;
    }

    public void setDbId(String dbId) {
        this.dbId = dbId;
    }

    @DynamoDbSecondaryPartitionKey(indexNames = APP_INDEX)
    @DynamoDbAttribute("app_id")
    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    @DynamoDbAttribute("engine")
    public String getEngine() {
        return engine;
    }

    public void setEngine(String engine) {
        this.engine = engine;
    }

    @DynamoDbAttribute("host")
    public String getHost() {
        return host;
    }

    public void setHost(String host) {
        this.host = host;
    }

    @DynamoDbAttribute("port")
    public Integer getPort() {
        return port;
    }

    public void setPort(Integer port) {
        this.port = port;
    }

    @DynamoDbAttribute("database")
    public String getDatabase() {
        return database;
    }

    public void setDatabase(String database) {
        this.database = database;
    }

    @DynamoDbAttribute("ssl_mode")
    public String getSslMode() {
        return sslMode;
    }

    public void setSslMode(String sslMode) {
        this.sslMode = sslMode;
    }

    @DynamoDbAttribute("auth_type")
    public String getAuthType() {
        return authType;
    }

    public void setAuthType(String authType) {
        this.authType = authType;
    }

    @DynamoDbAttribute("db_user")
    public String getDbUser() {
        return dbUser;
    }

    public void setDbUser(String dbUser) {
        this.dbUser = dbUser;
    }

    @DynamoDbAttribute("secret_name")
    public String getSecretName() {
        return secretName;
    }

    public void setSecretName(String secretName) {
        this.secretName = secretName;
    }

    @DynamoDbAttribute("jdbc_url")
    public String getJdbcUrl() {
        return jdbcUrl;
    }

    public void setJdbcUrl(String jdbcUrl) {
        this.jdbcUrl = jdbcUrl;
    }

    @DynamoDbAttribute("glue_connection")
    public String getGlueConnection() {
        return glueConnection;
    }

    public void setGlueConnection(String glueConnection) {
        this.glueConnection = glueConnection;
    }

    @DynamoDbAttribute("target_account_id")
    public String getTargetAccountId() {
        return targetAccountId;
    }

    public void setTargetAccountId(String targetAccountId) {
        this.targetAccountId = targetAccountId;
    }

    @DynamoDbAttribute("region")
    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    @DynamoDbAttribute("status")
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @DynamoDbVersionAttribute
    @DynamoDbAttribute("version")
    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }

    @DynamoDbAttribute("created_by")
    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    @DynamoDbSecondarySortKey(indexNames = APP_INDEX)
    @DynamoDbAttribute("created_at")
    public String getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(String createdAt) {
        this.createdAt = createdAt;
    }

    @DynamoDbAttribute("updated_by")
    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    @DynamoDbAttribute("updated_at")
    public String getUpdatedAt() {
        return updatedAt;
    }

    public void setUpdatedAt(String updatedAt) {
        this.updatedAt = updatedAt;
    }
}
