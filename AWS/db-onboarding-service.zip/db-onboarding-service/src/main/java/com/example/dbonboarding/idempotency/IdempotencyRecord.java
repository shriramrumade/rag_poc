package com.example.dbonboarding.idempotency;

import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;

/** Maps (operation, user, Idempotency-Key) to the resource it created. Expires via DynamoDB TTL. */
@DynamoDbBean
public class IdempotencyRecord {

    private String idemKey;
    private String requestHash;
    private String resourceId;
    private Long expiresAt;

    @DynamoDbPartitionKey
    @DynamoDbAttribute("idem_key")
    public String getIdemKey() {
        return idemKey;
    }

    public void setIdemKey(String idemKey) {
        this.idemKey = idemKey;
    }

    @DynamoDbAttribute("request_hash")
    public String getRequestHash() {
        return requestHash;
    }

    public void setRequestHash(String requestHash) {
        this.requestHash = requestHash;
    }

    @DynamoDbAttribute("resource_id")
    public String getResourceId() {
        return resourceId;
    }

    public void setResourceId(String resourceId) {
        this.resourceId = resourceId;
    }

    @DynamoDbAttribute("expires_at")
    public Long getExpiresAt() {
        return expiresAt;
    }

    public void setExpiresAt(Long expiresAt) {
        this.expiresAt = expiresAt;
    }
}
