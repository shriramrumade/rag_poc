package com.example.dbonboarding.load;

import com.example.dbonboarding.common.JsonAttr;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.util.List;

/** Request and response bodies for /v1/data-loads. */
public final class LoadDtos {

    private static final String IDENT = "^[A-Za-z0-9_]{1,128}$";

    private LoadDtos() {
    }

    public record CreateDataLoadRequest(
            @NotBlank String appId,
            @NotBlank String dbId,
            @NotBlank String requestId,
            @NotNull @Valid TargetSpec target,
            @NotBlank String loadMode,
            @Size(max = 20) List<@Pattern(regexp = IDENT) String> mergeKeys,
            Boolean createTableIfMissing) {
    }

    public record TargetSpec(
            @NotBlank String type,
            @NotBlank @Pattern(regexp = "^[A-Za-z0-9_-]{1,64}$") String targetId,
            @NotBlank @Pattern(regexp = IDENT) String schema,
            @NotBlank @Pattern(regexp = IDENT) String table) {
    }

    public record TargetView(String type, String targetId, String schema, String table) {
    }

    public record DataLoadResponse(
            String loadId,
            String appId,
            String dbId,
            String requestId,
            String retryOf,
            TargetView target,
            String loadMode,
            JsonNode mergeKeys,
            String status,
            String glueJobRunId,
            JsonNode progress,
            String submittedBy,
            String submittedAt,
            String startedAt,
            String completedAt,
            String stopRequestedBy,
            String stopRequestedAt,
            JsonNode result,
            JsonNode error) {

        public static DataLoadResponse from(DataLoadRecord r, JsonAttr json) {
            return new DataLoadResponse(r.getLoadId(), r.getAppId(), r.getDbId(), r.getRequestId(), r.getRetryOf(),
                    new TargetView(r.getTargetType(), r.getTargetId(), r.getTargetSchema(), r.getTargetTable()),
                    r.getLoadMode(), json.read(r.getMergeKeysJson()), r.getStatus(), r.getGlueJobRunId(),
                    json.read(r.getProgressJson()), r.getSubmittedBy(), r.getSubmittedAt(), r.getStartedAt(),
                    r.getCompletedAt(), r.getStopRequestedBy(), r.getStopRequestedAt(),
                    json.read(r.getResultJson()), json.read(r.getErrorJson()));
        }

        public static DataLoadResponse summary(DataLoadRecord r, JsonAttr json) {
            return new DataLoadResponse(r.getLoadId(), null, r.getDbId(), r.getRequestId(), r.getRetryOf(),
                    new TargetView(r.getTargetType(), r.getTargetId(), r.getTargetSchema(), r.getTargetTable()),
                    null, null, r.getStatus(), null, json.read(r.getProgressJson()), r.getSubmittedBy(),
                    r.getSubmittedAt(), null, r.getCompletedAt(), null, null, null, null);
        }
    }
}
