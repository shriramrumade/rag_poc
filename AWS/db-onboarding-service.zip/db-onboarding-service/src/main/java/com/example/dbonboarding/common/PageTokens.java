package com.example.dbonboarding.common;

import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import java.nio.charset.StandardCharsets;
import java.util.Base64;
import java.util.LinkedHashMap;
import java.util.Map;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

/**
 * Encodes a DynamoDB LastEvaluatedKey as an opaque next_token and back. Only string and number
 * key attributes are supported, which covers every table key in this service.
 */
public final class PageTokens {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private PageTokens() {
    }

    public static String encode(Map<String, AttributeValue> key) {
        if (key == null || key.isEmpty()) {
            return null;
        }
        Map<String, String[]> simple = new LinkedHashMap<>();
        key.forEach((name, value) -> {
            if (value.s() != null) {
                simple.put(name, new String[] {"S", value.s()});
            } else if (value.n() != null) {
                simple.put(name, new String[] {"N", value.n()});
            }
        });
        try {
            byte[] json = MAPPER.writeValueAsBytes(simple);
            return Base64.getUrlEncoder().withoutPadding().encodeToString(json);
        } catch (Exception e) {
            throw new IllegalStateException("could not encode page token", e);
        }
    }

    public static Map<String, AttributeValue> decode(String token) {
        if (token == null || token.isBlank()) {
            return null;
        }
        try {
            byte[] json = Base64.getUrlDecoder().decode(token);
            Map<String, String[]> simple = MAPPER.readValue(
                    new String(json, StandardCharsets.UTF_8), new TypeReference<Map<String, String[]>>() { });
            Map<String, AttributeValue> key = new LinkedHashMap<>();
            simple.forEach((name, tv) -> key.put(name, "N".equals(tv[0])
                    ? AttributeValue.builder().n(tv[1]).build()
                    : AttributeValue.builder().s(tv[1]).build()));
            return key;
        } catch (Exception e) {
            throw ApiException.badRequest("INVALID_SCHEMA", "next_token is invalid", "next_token");
        }
    }
}
