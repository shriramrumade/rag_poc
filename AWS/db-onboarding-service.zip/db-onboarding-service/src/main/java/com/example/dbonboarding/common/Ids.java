package com.example.dbonboarding.common;

import java.security.SecureRandom;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.HexFormat;

/** IDs and timestamps in the formats the API uses. */
public final class Ids {

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final DateTimeFormatter DAY = DateTimeFormatter.ofPattern("yyyyMMdd").withZone(ZoneOffset.UTC);

    private Ids() {
    }

    /** e.g. dx-20261027-7f3a9c */
    public static String newId(String prefix) {
        byte[] b = new byte[3];
        RANDOM.nextBytes(b);
        return prefix + "-" + DAY.format(Instant.now()) + "-" + HexFormat.of().formatHex(b);
    }

    /** UTC timestamp to the second, e.g. 2026-10-27T06:39:00Z */
    public static String now() {
        return Instant.now().truncatedTo(ChronoUnit.SECONDS).toString();
    }
}
