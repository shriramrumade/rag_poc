package com.example.dbonboarding.config;

import com.example.dbonboarding.audit.AuditRecord;
import com.example.dbonboarding.database.DatabaseRecord;
import com.example.dbonboarding.extraction.ExtractionRequestRecord;
import com.example.dbonboarding.idempotency.IdempotencyRecord;
import com.example.dbonboarding.load.DataLoadRecord;
import com.example.dbonboarding.load.TargetRecord;
import com.example.dbonboarding.metadata.MetadataExtractionRecord;
import com.example.dbonboarding.metadata.TableMetadataRecord;
import java.net.URI;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbEnhancedClient;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.TableSchema;
import software.amazon.awssdk.enhanced.dynamodb.extensions.VersionedRecordExtension;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.dynamodb.DynamoDbClient;
import software.amazon.awssdk.services.dynamodb.DynamoDbClientBuilder;
import software.amazon.awssdk.services.sts.StsClient;

/**
 * AWS clients for Account A. Credentials come from the default provider chain, which picks up
 * EKS Pod Identity (or IRSA) automatically when the pod runs in EKS.
 */
@Configuration
public class AwsConfig {

    @Bean
    public DynamoDbClient dynamoDbClient(AppProperties props) {
        DynamoDbClientBuilder builder = DynamoDbClient.builder()
                .region(Region.of(props.aws().region()));
        String endpoint = props.aws().dynamodbEndpoint();
        if (endpoint != null && !endpoint.isBlank()) {
            builder.endpointOverride(URI.create(endpoint));
        }
        return builder.build();
    }

    @Bean
    public DynamoDbEnhancedClient dynamoDbEnhancedClient(DynamoDbClient client) {
        return DynamoDbEnhancedClient.builder()
                .dynamoDbClient(client)
                .extensions(VersionedRecordExtension.builder().build())
                .build();
    }

    @Bean
    public StsClient stsClient(AppProperties props) {
        return StsClient.builder().region(Region.of(props.aws().region())).build();
    }

    @Bean
    public DynamoDbTable<DatabaseRecord> databaseTable(DynamoDbEnhancedClient c, AppProperties p) {
        return c.table(p.tables().databases(), TableSchema.fromBean(DatabaseRecord.class));
    }

    @Bean
    public DynamoDbTable<MetadataExtractionRecord> metadataExtractionTable(DynamoDbEnhancedClient c, AppProperties p) {
        return c.table(p.tables().metadataExtractions(), TableSchema.fromBean(MetadataExtractionRecord.class));
    }

    @Bean
    public DynamoDbTable<TableMetadataRecord> tableMetadataTable(DynamoDbEnhancedClient c, AppProperties p) {
        return c.table(p.tables().tableMetadata(), TableSchema.fromBean(TableMetadataRecord.class));
    }

    @Bean
    public DynamoDbTable<ExtractionRequestRecord> extractionRequestTable(DynamoDbEnhancedClient c, AppProperties p) {
        return c.table(p.tables().extractionRequests(), TableSchema.fromBean(ExtractionRequestRecord.class));
    }

    @Bean
    public DynamoDbTable<DataLoadRecord> dataLoadTable(DynamoDbEnhancedClient c, AppProperties p) {
        return c.table(p.tables().dataLoads(), TableSchema.fromBean(DataLoadRecord.class));
    }

    @Bean
    public DynamoDbTable<TargetRecord> targetTable(DynamoDbEnhancedClient c, AppProperties p) {
        return c.table(p.tables().targets(), TableSchema.fromBean(TargetRecord.class));
    }

    @Bean
    public DynamoDbTable<IdempotencyRecord> idempotencyTable(DynamoDbEnhancedClient c, AppProperties p) {
        return c.table(p.tables().idempotency(), TableSchema.fromBean(IdempotencyRecord.class));
    }

    @Bean
    public DynamoDbTable<AuditRecord> auditTable(DynamoDbEnhancedClient c, AppProperties p) {
        return c.table(p.tables().audit(), TableSchema.fromBean(AuditRecord.class));
    }
}
