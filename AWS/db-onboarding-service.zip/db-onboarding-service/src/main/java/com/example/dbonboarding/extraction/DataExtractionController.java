package com.example.dbonboarding.extraction;

import com.example.dbonboarding.common.JsonAttr;
import com.example.dbonboarding.common.ListResponse;
import com.example.dbonboarding.extraction.ExtractionDtos.CreateDataExtractionRequest;
import com.example.dbonboarding.extraction.ExtractionDtos.DataExtractionResponse;
import com.example.dbonboarding.extraction.ExtractionDtos.ExecuteDataExtractionRequest;
import com.example.dbonboarding.extraction.ExtractionDtos.StopRequest;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** APIs 10 to 14 and 20: /v1/data-extractions */
@RestController
@RequestMapping("/v1/data-extractions")
public class DataExtractionController {

    private final DataExtractionService service;
    private final JsonAttr json;

    public DataExtractionController(DataExtractionService service, JsonAttr json) {
        this.service = service;
        this.json = json;
    }

    // 10
    @PostMapping
    public ResponseEntity<DataExtractionResponse> create(
            @Valid @RequestBody CreateDataExtractionRequest body,
            @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey) {
        ExtractionRequestRecord rec = service.create(body, idempotencyKey);
        return ResponseEntity.created(URI.create("/v1/data-extractions/" + rec.getRequestId()))
                .body(response(rec));
    }

    // 11
    @GetMapping("/{requestId}")
    public DataExtractionResponse status(@PathVariable String requestId) {
        return response(service.get(requestId));
    }

    // 12
    @PostMapping("/{requestId}/stop")
    public ResponseEntity<DataExtractionResponse> stop(
            @PathVariable String requestId,
            @Valid @RequestBody(required = false) StopRequest body) {
        ExtractionRequestRecord rec = service.stop(requestId, body == null ? null : body.reason());
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(response(rec));
    }

    // 13
    @PostMapping("/{requestId}/retry")
    public ResponseEntity<DataExtractionResponse> retry(
            @PathVariable String requestId,
            @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey) {
        ExtractionRequestRecord rec = service.retry(requestId, idempotencyKey);
        return ResponseEntity.created(URI.create("/v1/data-extractions/" + rec.getRequestId()))
                .body(response(rec));
    }

    // 14
    @GetMapping
    public ListResponse<DataExtractionResponse> list(
            @RequestParam("app_id") String appId,
            @RequestParam(value = "db_id", required = false) String dbId,
            @RequestParam(value = "status", required = false) List<String> status,
            @RequestParam(value = "limit", defaultValue = "20") int limit,
            @RequestParam(value = "next_token", required = false) String nextToken) {
        return service.list(appId, dbId, status, limit, nextToken);
    }

    // 20
    @PostMapping("/{requestId}/execute")
    public ResponseEntity<DataExtractionResponse> execute(
            @PathVariable String requestId,
            @Valid @RequestBody ExecuteDataExtractionRequest body) {
        ExtractionRequestRecord rec = service.execute(requestId, body);
        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .location(URI.create("/v1/data-extractions/" + rec.getRequestId()))
                .body(response(rec));
    }

    private DataExtractionResponse response(ExtractionRequestRecord rec) {
        return DataExtractionResponse.from(rec, service.jobName(), json);
    }
}
