package com.example.dbonboarding.load;

import com.example.dbonboarding.audit.AuditService;
import com.example.dbonboarding.common.ApiException;
import com.example.dbonboarding.common.CorrelationIdFilter;
import com.example.dbonboarding.common.Ids;
import com.example.dbonboarding.common.JsonAttr;
import com.example.dbonboarding.common.ListResponse;
import com.example.dbonboarding.common.PageTokens;
import com.example.dbonboarding.common.RunStatus;
import com.example.dbonboarding.config.AppProperties;
import com.example.dbonboarding.database.DatabaseService;
import com.example.dbonboarding.extraction.DataExtractionService;
import com.example.dbonboarding.extraction.ExtractionRequestRecord;
import com.example.dbonboarding.extraction.Filters;
import com.example.dbonboarding.glue.GlueGateway;
import com.example.dbonboarding.glue.GlueGateway.JobStatus;
import com.example.dbonboarding.glue.GlueTarget;
import com.example.dbonboarding.idempotency.IdempotencyService;
import com.example.dbonboarding.load.LoadDtos.CreateDataLoadRequest;
import com.example.dbonboarding.load.LoadDtos.DataLoadResponse;
import com.example.dbonboarding.security.AccessGuard;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Expression;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

/**
 * Data loads: APIs 15 to 19. A load starts its Glue job as soon as it is created; it runs in the
 * account that holds the extraction output, and the target must be registered in that account.
 */
@Service
public class DataLoadService {

    private static final Logger log = LoggerFactory.getLogger(DataLoadService.class);
    private static final Set<String> TARGET_TYPES = Set.of("REDSHIFT", "S3_ICEBERG", "RDS");
    private static final Set<String> LOAD_MODES = Set.of("APPEND", "OVERWRITE", "UPSERT");

    private final DynamoDbTable<DataLoadRecord> table;
    private final DynamoDbTable<TargetRecord> targets;
    private final DataExtractionService extractions;
    private final DatabaseService databases;
    private final GlueGateway glue;
    private final AccessGuard guard;
    private final IdempotencyService idempotency;
    private final AuditService audit;
    private final AppProperties props;
    private final JsonAttr json;

    public DataLoadService(DynamoDbTable<DataLoadRecord> table, DynamoDbTable<TargetRecord> targets,
                           DataExtractionService extractions, DatabaseService databases, GlueGateway glue,
                           AccessGuard guard, IdempotencyService idempotency, AuditService audit,
                           AppProperties props, JsonAttr json) {
        this.table = table;
        this.targets = targets;
        this.extractions = extractions;
        this.databases = databases;
        this.glue = glue;
        this.guard = guard;
        this.idempotency = idempotency;
        this.audit = audit;
        this.props = props;
        this.json = json;
    }

    // 15. Create (and start)
    public DataLoadRecord create(CreateDataLoadRequest req, String idempotencyKey) {
        guard.requireApp(req.appId());
        String user = guard.userId();
        Optional<String> prior = idempotency.lookup("create-load", user, idempotencyKey, req);
        if (prior.isPresent()) {
            return load(prior.get());
        }
        databases.requireActive(req.appId(), req.dbId());

        ExtractionRequestRecord ex = extractions.find(req.requestId());
        if (ex == null || !ex.getAppId().equals(req.appId()) || !ex.getDbId().equals(req.dbId())) {
            throw ApiException.notFound("REQUEST_NOT_FOUND",
                    "request '" + req.requestId() + "' does not exist under " + req.appId() + "/" + req.dbId(),
                    "request_id");
        }
        if (!RunStatus.SUCCEEDED.equals(ex.getStatus())) {
            throw ApiException.conflict("EXTRACTION_NOT_COMPLETE", "request '" + req.requestId() + "' is "
                    + ex.getStatus() + "; only SUCCEEDED extractions can be loaded", "request_id");
        }

        String type = req.target().type().toUpperCase(Locale.ROOT);
        if (!TARGET_TYPES.contains(type)) {
            throw ApiException.badRequest("INVALID_SCHEMA", "target.type must be one of " + TARGET_TYPES, "target.type");
        }
        String mode = req.loadMode().toUpperCase(Locale.ROOT);
        if (!LOAD_MODES.contains(mode)) {
            throw ApiException.badRequest("INVALID_SCHEMA", "load_mode must be one of " + LOAD_MODES, "load_mode");
        }
        List<String> mergeKeys = req.mergeKeys() == null ? List.of() : req.mergeKeys();
        if ("UPSERT".equals(mode) && mergeKeys.isEmpty()) {
            throw ApiException.badRequest("INVALID_SCHEMA", "merge_keys is required for UPSERT", "merge_keys");
        }

        TargetRecord target = targets.getItem(Key.builder().partitionValue(req.target().targetId()).build());
        if (target == null || !"ACTIVE".equals(target.getStatus())) {
            throw ApiException.notFound("TARGET_NOT_FOUND",
                    "target '" + req.target().targetId() + "' is not registered", "target.target_id");
        }
        if (target.getAllowedAppIds() == null || !target.getAllowedAppIds().contains(req.appId())) {
            throw ApiException.forbidden("app '" + req.appId() + "' may not load into target '" + target.getTargetId() + "'");
        }
        if (!type.equals(target.getType())) {
            throw ApiException.unprocessable("TARGET_TYPE_MISMATCH",
                    "target '" + target.getTargetId() + "' is of type " + target.getType(), "target.type");
        }
        if (!target.getAccountId().equals(ex.getTargetAccountId()) || !target.getRegion().equals(ex.getRegion())) {
            throw ApiException.unprocessable("TARGET_ACCOUNT_MISMATCH",
                    "target must be registered in the account and region holding the extraction output",
                    "target.target_id");
        }

        GlueTarget glueTarget = new GlueTarget(target.getAccountId(), target.getRegion());
        String loadId = Ids.newId("dl");
        DataLoadRecord rec = new DataLoadRecord();
        rec.setLoadId(loadId);
        rec.setAppId(req.appId());
        rec.setDbId(req.dbId());
        rec.setRequestId(req.requestId());
        rec.setStatus(RunStatus.SUBMITTED);
        rec.setTargetType(type);
        rec.setTargetId(target.getTargetId());
        rec.setTargetSchema(req.target().schema());
        rec.setTargetTable(req.target().table());
        rec.setLoadMode(mode);
        rec.setMergeKeysJson(json.write(mergeKeys));
        rec.setCreateTableIfMissing(Boolean.TRUE.equals(req.createTableIfMissing()));
        JsonNode output = json.read(ex.getOutputJson());
        rec.setSourcePath(output != null ? output.path("s3_path").asText(ex.getOutputPath()) : ex.getOutputPath());
        rec.setSourceFormat(ex.getOutputFormat());
        rec.setResultPath("s3://" + glue.bucket(glueTarget) + "/" + props.storage().loadResultsPrefix()
                + "/" + req.appId() + "/" + loadId + "/_result.json");
        rec.setTargetAccountId(target.getAccountId());
        rec.setRegion(target.getRegion());
        rec.setSubmittedBy(user);
        rec.setSubmittedAt(Ids.now());
        rec = table.updateItem(rec);
        idempotency.remember("create-load", user, idempotencyKey, req, loadId);
        audit.record(entity(rec), "CREATE", user, null, null);
        return start(rec, target);
    }

    // 16. Status
    public DataLoadRecord get(String loadId) {
        DataLoadRecord rec = load(loadId);
        guard.requireApp(rec.getAppId());
        return rec;
    }

    // 17. Stop
    public DataLoadRecord stop(String loadId, String reason) {
        DataLoadRecord rec = get(loadId);
        String user = guard.userId();
        String now = Ids.now();
        switch (rec.getStatus()) {
            case RunStatus.SUBMITTED -> {
                rec.setStatus(RunStatus.STOPPED);
                rec.setCompletedAt(now);
            }
            case RunStatus.RUNNING -> {
                glue.stopJob(rec.glueTarget(), props.glue().loadJob(), rec.getGlueJobRunId());
                rec.setStatus(RunStatus.STOPPING);
            }
            default -> throw ApiException.conflict("NOT_STOPPABLE", "load is already " + rec.getStatus(), "status");
        }
        rec.setStopRequestedBy(user);
        rec.setStopRequestedAt(now);
        rec.setStopReason(reason);
        rec = table.updateItem(rec);
        audit.record(entity(rec), "STOP", user, reason, null);
        return rec;
    }

    // 18. Retry
    public DataLoadRecord retry(String loadId, String idempotencyKey) {
        DataLoadRecord old = get(loadId);
        String user = guard.userId();
        Optional<String> prior = idempotency.lookup("retry-load", user, idempotencyKey, loadId);
        if (prior.isPresent()) {
            return load(prior.get());
        }
        if (!RunStatus.FAILED.equals(old.getStatus()) && !RunStatus.STOPPED.equals(old.getStatus())) {
            throw ApiException.conflict("NOT_RETRYABLE", "only FAILED or STOPPED loads can be retried", "status");
        }
        TargetRecord target = targets.getItem(Key.builder().partitionValue(old.getTargetId()).build());
        if (target == null || !"ACTIVE".equals(target.getStatus())) {
            throw ApiException.notFound("TARGET_NOT_FOUND", "target '" + old.getTargetId() + "' is not registered",
                    "target.target_id");
        }
        String newId = Ids.newId("dl");
        DataLoadRecord rec = new DataLoadRecord();
        rec.setLoadId(newId);
        rec.setAppId(old.getAppId());
        rec.setDbId(old.getDbId());
        rec.setRequestId(old.getRequestId());
        rec.setRetryOf(old.getLoadId());
        rec.setStatus(RunStatus.SUBMITTED);
        rec.setTargetType(old.getTargetType());
        rec.setTargetId(old.getTargetId());
        rec.setTargetSchema(old.getTargetSchema());
        rec.setTargetTable(old.getTargetTable());
        rec.setLoadMode(old.getLoadMode());
        rec.setMergeKeysJson(old.getMergeKeysJson());
        rec.setCreateTableIfMissing(old.getCreateTableIfMissing());
        rec.setSourcePath(old.getSourcePath());
        rec.setSourceFormat(old.getSourceFormat());
        rec.setResultPath(old.getResultPath().replace(old.getLoadId(), newId));
        rec.setTargetAccountId(old.getTargetAccountId());
        rec.setRegion(old.getRegion());
        rec.setSubmittedBy(user);
        rec.setSubmittedAt(Ids.now());
        rec = table.updateItem(rec);
        idempotency.remember("retry-load", user, idempotencyKey, loadId, newId);
        audit.record(entity(rec), "RETRY", user, null, "retry_of=" + old.getLoadId());
        return start(rec, target);
    }

    // 19. List
    public ListResponse<DataLoadResponse> list(String appId, String dbId, List<String> statuses,
                                               int limit, String nextToken) {
        guard.requireApp(appId);
        QueryEnhancedRequest.Builder q = QueryEnhancedRequest.builder()
                .queryConditional(QueryConditional.keyEqualTo(Key.builder().partitionValue(appId).build()))
                .scanIndexForward(false)
                .limit(Math.max(1, Math.min(limit, 100)));
        Expression filter = Filters.dbAndStatus(dbId, statuses);
        if (filter != null) {
            q.filterExpression(filter);
        }
        Map<String, AttributeValue> start = PageTokens.decode(nextToken);
        if (start != null) {
            q.exclusiveStartKey(start);
        }
        Page<DataLoadRecord> page = table.index(DataLoadRecord.APP_INDEX).query(q.build()).iterator().next();
        return ListResponse.of(appId, dbId,
                page.items().stream().map(r -> DataLoadResponse.summary(r, json)).toList(),
                PageTokens.encode(page.lastEvaluatedKey()));
    }

    /** Called by the status sync for each active load. */
    public void sync(DataLoadRecord rec) {
        GlueTarget target = rec.glueTarget();
        JobStatus job = glue.getJobRun(target, props.glue().loadJob(), rec.getGlueJobRunId());
        if (!job.finished()) {
            glue.readText(target, rec.getResultPath().replace("_result.json", "_progress.json")).ifPresent(p -> {
                if (!p.equals(rec.getProgressJson())) {
                    rec.setProgressJson(p);
                    table.updateItem(rec);
                }
            });
            return;
        }
        rec.setActive(null);
        rec.setCompletedAt(Ids.now());
        switch (job.state()) {
            case "SUCCEEDED" -> {
                rec.setStatus(RunStatus.SUCCEEDED);
                rec.setProgressJson(null);
                rec.setResultJson(glue.readText(target, rec.getResultPath()).orElse(null));
            }
            case "STOPPED" -> rec.setStatus(RunStatus.STOPPED);
            default -> {
                ObjectNode err = json.mapper().createObjectNode();
                err.put("code", "GLUE_JOB_FAILED");
                err.put("message", job.state() + ": " + job.errorMessage());
                rec.setStatus(RunStatus.FAILED);
                rec.setErrorJson(json.write(err));
            }
        }
        table.updateItem(rec);
        log.info("data load {} finished: {}", rec.getLoadId(), rec.getStatus());
    }

    private DataLoadRecord start(DataLoadRecord rec, TargetRecord target) {
        JsonNode mergeKeys = json.read(rec.getMergeKeysJson());
        StringBuilder keys = new StringBuilder();
        if (mergeKeys != null) {
            mergeKeys.forEach(k -> keys.append(keys.isEmpty() ? "" : ",").append(k.asText()));
        }
        Map<String, String> args = new LinkedHashMap<>();
        args.put("--load_id", rec.getLoadId());
        args.put("--request_id", rec.getRequestId());
        args.put("--app_id", rec.getAppId());
        args.put("--source_path", rec.getSourcePath());
        args.put("--source_format", rec.getSourceFormat());
        args.put("--target_type", rec.getTargetType());
        args.put("--target_connection", target.getGlueConnection());
        args.put("--target_secret_name", target.getSecretName());
        args.put("--target_schema", rec.getTargetSchema());
        args.put("--target_table", rec.getTargetTable());
        args.put("--load_mode", rec.getLoadMode());
        args.put("--merge_keys", keys.toString());
        args.put("--create_table_if_missing", String.valueOf(Boolean.TRUE.equals(rec.getCreateTableIfMissing())));
        args.put("--result_path", rec.getResultPath());
        args.put("--TempDir", "s3://" + glue.bucket(rec.glueTarget()) + "/" + props.storage().tempPrefix() + "/");
        args.put("--correlation_id", CorrelationIdFilter.current());
        try {
            String runId = glue.startJob(rec.glueTarget(), props.glue().loadJob(), args, props.glue().loadWorkers());
            rec.setGlueJobRunId(runId);
            rec.setStatus(RunStatus.RUNNING);
            rec.setActive(RunStatus.ACTIVE);
            rec.setStartedAt(Ids.now());
            return table.updateItem(rec);
        } catch (RuntimeException e) {
            ObjectNode err = json.mapper().createObjectNode();
            err.put("code", "GLUE_START_FAILED");
            err.put("message", e.getMessage());
            rec.setStatus(RunStatus.FAILED);
            rec.setCompletedAt(Ids.now());
            rec.setErrorJson(json.write(err));
            table.updateItem(rec);
            throw e;
        }
    }

    private DataLoadRecord load(String loadId) {
        DataLoadRecord rec = table.getItem(Key.builder().partitionValue(loadId).build());
        if (rec == null) {
            throw ApiException.notFound("LOAD_NOT_FOUND", "load '" + loadId + "' does not exist", "load_id");
        }
        return rec;
    }

    private static String entity(DataLoadRecord rec) {
        return "data_load#" + rec.getAppId() + "#" + rec.getLoadId();
    }
}
