package com.example.dbonboarding.database;

import com.example.dbonboarding.audit.AuditService;
import com.example.dbonboarding.common.ApiException;
import com.example.dbonboarding.common.Ids;
import com.example.dbonboarding.common.ListResponse;
import com.example.dbonboarding.common.PageTokens;
import com.example.dbonboarding.common.Versions;
import com.example.dbonboarding.config.AppProperties;
import com.example.dbonboarding.database.DatabaseDtos.CreateDatabaseRequest;
import com.example.dbonboarding.database.DatabaseDtos.DatabaseResponse;
import com.example.dbonboarding.idempotency.IdempotencyService;
import com.example.dbonboarding.security.AccessGuard;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.Iterator;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Expression;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;
import software.amazon.awssdk.services.dynamodb.model.ConditionalCheckFailedException;

/** Create, fetch, list, update and soft-delete database registrations (APIs 1 to 5). */
@Service
public class DatabaseService {

    private static final Set<String> EDITABLE = Set.of("engine", "host", "port", "database", "auth_type", "db_user", "ssl_mode");
    private static final Set<String> READ_ONLY = Set.of("app_id", "db_id", "status", "version", "created_by",
            "created_at", "updated_by", "updated_at", "target_account_id", "region", "secret_name", "jdbc_url");

    private final DynamoDbTable<DatabaseRecord> table;
    private final ConnectionPolicy policy;
    private final AccessGuard guard;
    private final IdempotencyService idempotency;
    private final AuditService audit;
    private final AppProperties props;

    public DatabaseService(DynamoDbTable<DatabaseRecord> table, ConnectionPolicy policy, AccessGuard guard,
                           IdempotencyService idempotency, AuditService audit, AppProperties props) {
        this.table = table;
        this.policy = policy;
        this.guard = guard;
        this.idempotency = idempotency;
        this.audit = audit;
        this.props = props;
    }

    // 1. Create
    public DatabaseRecord create(CreateDatabaseRequest req, String idempotencyKey) {
        guard.requireOnboarder(req.appId());
        String user = guard.userId();
        Optional<String> prior = idempotency.lookup("create-database", user, idempotencyKey, req);
        if (prior.isPresent()) {
            return load(prior.get());
        }

        policy.validateEngine(req.engine());
        String host = policy.normalizeHost(req.host());
        policy.validatePort(req.engine(), req.port());
        policy.validateAuth(req.engine(), host, req.authType(), req.dbUser());
        String sslMode = policy.normalizeSslMode(req.sslMode());
        String account = req.targetAccountId() != null ? req.targetAccountId() : props.aws().defaultTargetAccountId();
        String region = req.region() != null ? req.region() : props.aws().defaultTargetRegion();
        policy.validateTarget(account, region);

        String now = Ids.now();
        DatabaseRecord rec = new DatabaseRecord();
        rec.setDbId(req.dbId());
        rec.setAppId(req.appId());
        rec.setEngine(req.engine());
        rec.setHost(host);
        rec.setPort(req.port());
        rec.setDatabase(req.database());
        rec.setSslMode(sslMode);
        rec.setAuthType(req.authType());
        rec.setTargetAccountId(account);
        rec.setRegion(region);
        applyDerived(rec, req.dbUser());
        rec.setStatus(DatabaseRecord.STATUS_REGISTERED);
        rec.setCreatedBy(user);
        rec.setCreatedAt(now);
        rec.setUpdatedAt(now);
        try {
            // The version extension adds attribute_not_exists(version), so db_id stays unique.
            rec = table.updateItem(rec);
        } catch (ConditionalCheckFailedException e) {
            throw ApiException.conflict("DB_ID_EXISTS", "db_id '" + req.dbId() + "' is already registered", "db_id");
        }
        idempotency.remember("create-database", user, idempotencyKey, req, rec.getDbId());
        audit.record(entity(rec), "CREATE", user, null, rec.getJdbcUrl());
        return rec;
    }

    // 2. Fetch
    public DatabaseRecord get(String dbId) {
        DatabaseRecord rec = load(dbId);
        guard.requireApp(rec.getAppId());
        return rec;
    }

    // 3. List by app ID
    public ListResponse<DatabaseResponse> list(String appId, int limit, String nextToken) {
        guard.requireApp(appId);
        QueryEnhancedRequest.Builder q = QueryEnhancedRequest.builder()
                .queryConditional(QueryConditional.keyEqualTo(Key.builder().partitionValue(appId).build()))
                .scanIndexForward(false)
                .limit(clamp(limit))
                .filterExpression(Expression.builder()
                        .expression("#st <> :deleted")
                        .putExpressionName("#st", "status")
                        .putExpressionValue(":deleted", AttributeValue.builder().s(DatabaseRecord.STATUS_DELETED).build())
                        .build());
        Map<String, AttributeValue> start = PageTokens.decode(nextToken);
        if (start != null) {
            q.exclusiveStartKey(start);
        }
        Page<DatabaseRecord> page = table.index(DatabaseRecord.APP_INDEX).query(q.build()).iterator().next();
        return ListResponse.of(appId, null,
                page.items().stream().map(DatabaseResponse::from).toList(),
                PageTokens.encode(page.lastEvaluatedKey()));
    }

    // 4. Update
    public DatabaseRecord update(String dbId, long ifMatch, ObjectNode body) {
        DatabaseRecord rec = load(dbId);
        guard.requireOnboarder(rec.getAppId());
        Versions.requireMatch(rec.getVersion(), ifMatch, dbId);

        String dbUser = rec.getDbUser();
        Iterator<Map.Entry<String, JsonNode>> fields = body.fields();
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> f = fields.next();
            String name = f.getKey();
            JsonNode v = f.getValue();
            if (READ_ONLY.contains(name)) {
                throw ApiException.badRequest("FIELD_NOT_EDITABLE", name + " cannot be changed", name);
            }
            if (!EDITABLE.contains(name)) {
                throw ApiException.badRequest("INVALID_SCHEMA", "unknown field " + name, name);
            }
            switch (name) {
                case "engine" -> rec.setEngine(v.asText());
                case "host" -> rec.setHost(v.asText());
                case "port" -> {
                    if (!v.canConvertToInt()) {
                        throw ApiException.badRequest("INVALID_SCHEMA", "port must be an integer", "port");
                    }
                    rec.setPort(v.asInt());
                }
                case "database" -> {
                    if (!v.asText().matches("^[A-Za-z0-9_.]{1,64}$")) {
                        throw ApiException.badRequest("INVALID_SCHEMA", "database is invalid", "database");
                    }
                    rec.setDatabase(v.asText());
                }
                case "auth_type" -> rec.setAuthType(v.asText());
                case "db_user" -> dbUser = v.isNull() ? null : v.asText();
                case "ssl_mode" -> rec.setSslMode(v.asText());
                default -> { }
            }
        }
        policy.validateEngine(rec.getEngine());
        rec.setHost(policy.normalizeHost(rec.getHost()));
        policy.validatePort(rec.getEngine(), rec.getPort());
        policy.validateAuth(rec.getEngine(), rec.getHost(), rec.getAuthType(), dbUser);
        rec.setSslMode(policy.normalizeSslMode(rec.getSslMode()));
        applyDerived(rec, dbUser);

        String user = guard.userId();
        rec.setUpdatedBy(user);
        rec.setUpdatedAt(Ids.now());
        rec = table.updateItem(rec); // version extension: condition version = old, then +1
        audit.record(entity(rec), "UPDATE", user, null, body.toString());
        return rec;
    }

    // 5. Delete (soft)
    public void delete(String dbId, long ifMatch) {
        DatabaseRecord rec = load(dbId);
        guard.requireOnboarder(rec.getAppId());
        Versions.requireMatch(rec.getVersion(), ifMatch, dbId);
        String user = guard.userId();
        rec.setStatus(DatabaseRecord.STATUS_DELETED);
        rec.setUpdatedBy(user);
        rec.setUpdatedAt(Ids.now());
        table.updateItem(rec);
        audit.record(entity(rec), "DELETE", user, null, null);
    }

    /**
     * For the other APIs: the active registration of db_id under app_id, or 404. Callers have
     * already checked the user's rights on app_id.
     */
    public DatabaseRecord requireActive(String appId, String dbId) {
        DatabaseRecord rec = table.getItem(Key.builder().partitionValue(dbId).build());
        if (rec == null || rec.isDeleted() || !rec.getAppId().equals(appId)) {
            throw ApiException.notFound("DB_NOT_FOUND",
                    "db_id '" + dbId + "' is not registered under app_id '" + appId + "'", "db_id");
        }
        return rec;
    }

    private DatabaseRecord load(String dbId) {
        DatabaseRecord rec = table.getItem(Key.builder().partitionValue(dbId).build());
        if (rec == null || rec.isDeleted()) {
            throw ApiException.notFound("DB_NOT_FOUND", "db_id '" + dbId + "' is not registered", "db_id");
        }
        return rec;
    }

    /** Values the server derives: JDBC URL, secret name by convention, Glue connection name. */
    private void applyDerived(DatabaseRecord rec, String dbUser) {
        rec.setJdbcUrl(JdbcUrlBuilder.build(rec.getEngine(), rec.getHost(), rec.getPort(), rec.getDatabase(), rec.getSslMode()));
        rec.setGlueConnection("conn-" + rec.getDbId());
        if ("secret".equals(rec.getAuthType())) {
            rec.setSecretName("glue-db/" + rec.getDbId());
            rec.setDbUser(null);
        } else {
            rec.setSecretName(null);
            rec.setDbUser(dbUser);
        }
    }

    private static String entity(DatabaseRecord rec) {
        return "database#" + rec.getAppId() + "#" + rec.getDbId();
    }

    static int clamp(int limit) {
        return Math.max(1, Math.min(limit, 100));
    }
}
