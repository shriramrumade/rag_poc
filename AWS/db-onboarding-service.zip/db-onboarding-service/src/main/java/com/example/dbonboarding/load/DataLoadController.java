package com.example.dbonboarding.load;

import com.example.dbonboarding.common.JsonAttr;
import com.example.dbonboarding.common.ListResponse;
import com.example.dbonboarding.extraction.ExtractionDtos.StopRequest;
import com.example.dbonboarding.load.LoadDtos.CreateDataLoadRequest;
import com.example.dbonboarding.load.LoadDtos.DataLoadResponse;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestHeader;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** APIs 15 to 19: /v1/data-loads */
@RestController
@RequestMapping("/v1/data-loads")
public class DataLoadController {

    private final DataLoadService service;
    private final JsonAttr json;

    public DataLoadController(DataLoadService service, JsonAttr json) {
        this.service = service;
        this.json = json;
    }

    // 15
    @PostMapping
    public ResponseEntity<DataLoadResponse> create(
            @Valid @RequestBody CreateDataLoadRequest body,
            @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey) {
        DataLoadRecord rec = service.create(body, idempotencyKey);
        return ResponseEntity.status(HttpStatus.ACCEPTED)
                .location(URI.create("/v1/data-loads/" + rec.getLoadId()))
                .body(DataLoadResponse.from(rec, json));
    }

    // 16
    @GetMapping("/{loadId}")
    public DataLoadResponse status(@PathVariable String loadId) {
        return DataLoadResponse.from(service.get(loadId), json);
    }

    // 17
    @PostMapping("/{loadId}/stop")
    public ResponseEntity<DataLoadResponse> stop(
            @PathVariable String loadId,
            @Valid @RequestBody(required = false) StopRequest body) {
        DataLoadRecord rec = service.stop(loadId, body == null ? null : body.reason());
        return ResponseEntity.status(HttpStatus.ACCEPTED).body(DataLoadResponse.from(rec, json));
    }

    // 18
    @PostMapping("/{loadId}/retry")
    public ResponseEntity<DataLoadResponse> retry(
            @PathVariable String loadId,
            @RequestHeader(value = "Idempotency-Key", required = false) String idempotencyKey) {
        DataLoadRecord rec = service.retry(loadId, idempotencyKey);
        return ResponseEntity.created(URI.create("/v1/data-loads/" + rec.getLoadId()))
                .body(DataLoadResponse.from(rec, json));
    }

    // 19
    @GetMapping
    public ListResponse<DataLoadResponse> list(
            @RequestParam("app_id") String appId,
            @RequestParam(value = "db_id", required = false) String dbId,
            @RequestParam(value = "status", required = false) List<String> status,
            @RequestParam(value = "limit", defaultValue = "20") int limit,
            @RequestParam(value = "next_token", required = false) String nextToken) {
        return service.list(appId, dbId, status, limit, nextToken);
    }
}
