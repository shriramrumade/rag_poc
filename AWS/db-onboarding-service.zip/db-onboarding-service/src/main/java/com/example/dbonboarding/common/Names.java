package com.example.dbonboarding.common;

/** Converts Java field names to the snake_case names used on the wire. */
public final class Names {

    private Names() {
    }

    public static String snake(String camel) {
        if (camel == null) {
            return null;
        }
        StringBuilder sb = new StringBuilder();
        for (char c : camel.toCharArray()) {
            if (Character.isUpperCase(c)) {
                sb.append('_').append(Character.toLowerCase(c));
            } else {
                sb.append(c);
            }
        }
        return sb.toString();
    }
}
