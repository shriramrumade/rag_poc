package com.example.dbonboarding.load;

import java.util.Set;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;

/**
 * Table {@code load_targets}: registry of load destinations, maintained by the platform team.
 * A target names a Glue connection and secret in the account where the load job runs, so load
 * requests never carry target credentials.
 */
@DynamoDbBean
public class TargetRecord {

    private String targetId;
    private String type;
    private String accountId;
    private String region;
    private String glueConnection;
    private String secretName;
    private Set<String> allowedAppIds;
    private String status;

    @DynamoDbPartitionKey
    @DynamoDbAttribute("target_id")
    public String getTargetId() {
        return targetId;
    }

    public void setTargetId(String targetId) {
        this.targetId = targetId;
    }

    @DynamoDbAttribute("type")
    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    @DynamoDbAttribute("account_id")
    public String getAccountId() {
        return accountId;
    }

    public void setAccountId(String accountId) {
        this.accountId = accountId;
    }

    @DynamoDbAttribute("region")
    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    @DynamoDbAttribute("glue_connection")
    public String getGlueConnection() {
        return glueConnection;
    }

    public void setGlueConnection(String glueConnection) {
        this.glueConnection = glueConnection;
    }

    @DynamoDbAttribute("secret_name")
    public String getSecretName() {
        return secretName;
    }

    public void setSecretName(String secretName) {
        this.secretName = secretName;
    }

    @DynamoDbAttribute("allowed_app_ids")
    public Set<String> getAllowedAppIds() {
        return allowedAppIds;
    }

    public void setAllowedAppIds(Set<String> allowedAppIds) {
        this.allowedAppIds = allowedAppIds;
    }

    @DynamoDbAttribute("status")
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }
}
