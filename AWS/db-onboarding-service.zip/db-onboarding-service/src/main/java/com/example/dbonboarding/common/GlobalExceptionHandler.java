package com.example.dbonboarding.common;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.http.converter.HttpMessageNotReadableException;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.validation.FieldError;
import org.springframework.web.HttpRequestMethodNotSupportedException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.servlet.resource.NoResourceFoundException;
import software.amazon.awssdk.services.dynamodb.model.ConditionalCheckFailedException;

/**
 * Maps every failure to the standard error body and HTTP status from the API spec.
 */
@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger log = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    @ExceptionHandler(ApiException.class)
    public ResponseEntity<ErrorResponse> handleApi(ApiException ex) {
        if (ex.status().is5xxServerError()) {
            log.error("api error {}: {}", ex.code(), ex.getMessage(), ex);
        }
        return ResponseEntity.status(ex.status()).body(ErrorResponse.of(ex.code(), ex.getMessage(), ex.field()));
    }

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ErrorResponse> handleValidation(MethodArgumentNotValidException ex) {
        FieldError fe = ex.getBindingResult().getFieldError();
        String field = fe == null ? null : Names.snake(fe.getField());
        String message = fe == null ? "request body is invalid" : field + " " + fe.getDefaultMessage();
        return ResponseEntity.badRequest().body(ErrorResponse.of("INVALID_SCHEMA", message, field));
    }

    @ExceptionHandler(HttpMessageNotReadableException.class)
    public ResponseEntity<ErrorResponse> handleUnreadable(HttpMessageNotReadableException ex) {
        return ResponseEntity.badRequest().body(ErrorResponse.of("INVALID_SCHEMA", "request body is malformed", null));
    }

    @ExceptionHandler(MissingServletRequestParameterException.class)
    public ResponseEntity<ErrorResponse> handleMissingParam(MissingServletRequestParameterException ex) {
        if ("app_id".equals(ex.getParameterName())) {
            return ResponseEntity.badRequest().body(ErrorResponse.of(
                    "APP_ID_REQUIRED", "query parameter 'app_id' is required", "app_id"));
        }
        return ResponseEntity.badRequest().body(ErrorResponse.of("INVALID_SCHEMA",
                "query parameter '" + ex.getParameterName() + "' is required", ex.getParameterName()));
    }

    @ExceptionHandler(MissingRequestHeaderException.class)
    public ResponseEntity<ErrorResponse> handleMissingHeader(MissingRequestHeaderException ex) {
        if ("If-Match".equalsIgnoreCase(ex.getHeaderName())) {
            return ResponseEntity.status(HttpStatus.PRECONDITION_REQUIRED).body(ErrorResponse.of(
                    "IF_MATCH_REQUIRED", "If-Match header with the current version is required", "If-Match"));
        }
        return ResponseEntity.badRequest().body(ErrorResponse.of("INVALID_SCHEMA",
                "header '" + ex.getHeaderName() + "' is required", ex.getHeaderName()));
    }

    @ExceptionHandler(ConditionalCheckFailedException.class)
    public ResponseEntity<ErrorResponse> handleConditional(ConditionalCheckFailedException ex) {
        return ResponseEntity.status(HttpStatus.PRECONDITION_FAILED).body(ErrorResponse.of(
                "VERSION_MISMATCH", "the record was changed by someone else; fetch it again and retry", "version"));
    }

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ErrorResponse> handleDenied(AccessDeniedException ex) {
        return ResponseEntity.status(HttpStatus.FORBIDDEN).body(ErrorResponse.of("NOT_AUTHORIZED", "access denied", null));
    }

    @ExceptionHandler(NoResourceFoundException.class)
    public ResponseEntity<ErrorResponse> handleNotFound(NoResourceFoundException ex) {
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(ErrorResponse.of("NOT_FOUND", "no such endpoint", null));
    }

    @ExceptionHandler(HttpRequestMethodNotSupportedException.class)
    public ResponseEntity<ErrorResponse> handleMethod(HttpRequestMethodNotSupportedException ex) {
        return ResponseEntity.status(HttpStatus.METHOD_NOT_ALLOWED)
                .body(ErrorResponse.of("METHOD_NOT_ALLOWED", ex.getMessage(), null));
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ErrorResponse> handleOther(Exception ex) {
        log.error("unexpected error", ex);
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(ErrorResponse.of(
                "INTERNAL_ERROR", "unexpected failure; quote the correlation ID", null));
    }
}
