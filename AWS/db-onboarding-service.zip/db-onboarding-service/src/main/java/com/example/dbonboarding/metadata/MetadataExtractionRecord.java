package com.example.dbonboarding.metadata;

import com.example.dbonboarding.glue.GlueTarget;
import software.amazon.awssdk.enhanced.dynamodb.extensions.annotations.DynamoDbVersionAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbIgnore;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondaryPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondarySortKey;

/**
 * Table {@code metadata_extractions}: one item per metadata extraction run.
 * <ul>
 *   <li>{@code app_db-index} (app_db, submitted_at) finds runs for a database.</li>
 *   <li>{@code active-index} (active, submitted_at) is sparse: only running items carry
 *       {@code active}, so the status sync reads just those.</li>
 * </ul>
 */
@DynamoDbBean
public class MetadataExtractionRecord {

    public static final String APP_DB_INDEX = "app_db-index";
    public static final String ACTIVE_INDEX = "active-index";

    private String extractionId;
    private String appId;
    private String dbId;
    private String appDb;
    private String active;
    private String status;
    private String catalogDatabase;
    private String crawlerName;
    private String crawlerStartedAt;
    private String jobRunId;
    private String outputPath;
    private String targetAccountId;
    private String region;
    private String submittedBy;
    private String submittedAt;
    private String startedAt;
    private String completedAt;
    private String resultJson;
    private String errorJson;
    private Long version;

    @DynamoDbIgnore
    public GlueTarget glueTarget() {
        return new GlueTarget(targetAccountId, region);
    }

    @DynamoDbPartitionKey
    @DynamoDbAttribute("extraction_id")
    public String getExtractionId() {
        return extractionId;
    }

    public void setExtractionId(String extractionId) {
        this.extractionId = extractionId;
    }

    @DynamoDbAttribute("app_id")
    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    @DynamoDbAttribute("db_id")
    public String getDbId() {
        return dbId;
    }

    public void setDbId(String dbId) {
        this.dbId = dbId;
    }

    @DynamoDbSecondaryPartitionKey(indexNames = APP_DB_INDEX)
    @DynamoDbAttribute("app_db")
    public String getAppDb() {
        return appDb;
    }

    public void setAppDb(String appDb) {
        this.appDb = appDb;
    }

    @DynamoDbSecondaryPartitionKey(indexNames = ACTIVE_INDEX)
    @DynamoDbAttribute("active")
    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    @DynamoDbAttribute("status")
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @DynamoDbAttribute("catalog_database")
    public String getCatalogDatabase() {
        return catalogDatabase;
    }

    public void setCatalogDatabase(String catalogDatabase) {
        this.catalogDatabase = catalogDatabase;
    }

    @DynamoDbAttribute("crawler_name")
    public String getCrawlerName() {
        return crawlerName;
    }

    public void setCrawlerName(String crawlerName) {
        this.crawlerName = crawlerName;
    }

    @DynamoDbAttribute("crawler_started_at")
    public String getCrawlerStartedAt() {
        return crawlerStartedAt;
    }

    public void setCrawlerStartedAt(String crawlerStartedAt) {
        this.crawlerStartedAt = crawlerStartedAt;
    }

    @DynamoDbAttribute("job_run_id")
    public String getJobRunId() {
        return jobRunId;
    }

    public void setJobRunId(String jobRunId) {
        this.jobRunId = jobRunId;
    }

    @DynamoDbAttribute("output_path")
    public String getOutputPath() {
        return outputPath;
    }

    public void setOutputPath(String outputPath) {
        this.outputPath = outputPath;
    }

    @DynamoDbAttribute("target_account_id")
    public String getTargetAccountId() {
        return targetAccountId;
    }

    public void setTargetAccountId(String targetAccountId) {
        this.targetAccountId = targetAccountId;
    }

    @DynamoDbAttribute("region")
    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    @DynamoDbAttribute("submitted_by")
    public String getSubmittedBy() {
        return submittedBy;
    }

    public void setSubmittedBy(String submittedBy) {
        this.submittedBy = submittedBy;
    }

    @DynamoDbSecondarySortKey(indexNames = {APP_DB_INDEX, ACTIVE_INDEX})
    @DynamoDbAttribute("submitted_at")
    public String getSubmittedAt() {
        return submittedAt;
    }

    public void setSubmittedAt(String submittedAt) {
        this.submittedAt = submittedAt;
    }

    @DynamoDbAttribute("started_at")
    public String getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(String startedAt) {
        this.startedAt = startedAt;
    }

    @DynamoDbAttribute("completed_at")
    public String getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(String completedAt) {
        this.completedAt = completedAt;
    }

    @DynamoDbAttribute("result_json")
    public String getResultJson() {
        return resultJson;
    }

    public void setResultJson(String resultJson) {
        this.resultJson = resultJson;
    }

    @DynamoDbAttribute("error_json")
    public String getErrorJson() {
        return errorJson;
    }

    public void setErrorJson(String errorJson) {
        this.errorJson = errorJson;
    }

    @DynamoDbVersionAttribute
    @DynamoDbAttribute("version")
    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }
}
