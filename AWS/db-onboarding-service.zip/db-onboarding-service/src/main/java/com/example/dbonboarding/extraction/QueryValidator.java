package com.example.dbonboarding.extraction;

import com.example.dbonboarding.common.ApiException;
import java.util.LinkedHashSet;
import java.util.Locale;
import java.util.Map;
import java.util.Set;
import net.sf.jsqlparser.JSQLParserException;
import net.sf.jsqlparser.parser.CCJSqlParserUtil;
import net.sf.jsqlparser.statement.Statement;
import net.sf.jsqlparser.statement.select.Select;

/**
 * Accepts only a single read-only SELECT whose values all come through :named parameters.
 * The Glue job binds parameters through the JDBC driver; nothing is concatenated into the SQL.
 */
public final class QueryValidator {

    private QueryValidator() {
    }

    public static void validate(String sql, Map<String, Object> parameters) {
        if (sql == null || sql.isBlank()) {
            if (parameters != null && !parameters.isEmpty()) {
                throw invalid("parameters given without a query", "parameters");
            }
            return;
        }
        String text = sql.trim();
        if (text.endsWith(";")) {
            text = text.substring(0, text.length() - 1).trim();
        }
        String code = stripLiterals(text);
        if (code.contains(";")) {
            throw invalid("only a single SELECT statement is allowed", "query");
        }
        if (code.contains("--") || code.contains("/*")) {
            throw invalid("comments are not allowed in the query", "query");
        }
        String upper = " " + code.toUpperCase(Locale.ROOT).replaceAll("\\s+", " ") + " ";
        for (String banned : new String[] {" INTO ", " FOR UPDATE ", " FOR SHARE ", " LOCK "}) {
            if (upper.contains(banned)) {
                throw invalid("the query must be a plain read-only SELECT", "query");
            }
        }

        Statement statement;
        try {
            statement = CCJSqlParserUtil.parse(text);
        } catch (JSQLParserException e) {
            throw invalid("query could not be parsed as SQL", "query");
        }
        if (!(statement instanceof Select)) {
            throw invalid("only a single SELECT statement is allowed", "query");
        }

        Set<String> used = namedParameters(code);
        Map<String, Object> given = parameters == null ? Map.of() : parameters;
        for (String name : used) {
            if (!given.containsKey(name)) {
                throw invalid("parameter :" + name + " has no value", "parameters." + name);
            }
        }
        for (Map.Entry<String, Object> p : given.entrySet()) {
            if (!used.contains(p.getKey())) {
                throw invalid("parameter '" + p.getKey() + "' is not used in the query", "parameters." + p.getKey());
            }
            Object v = p.getValue();
            if (v != null && !(v instanceof String) && !(v instanceof Number) && !(v instanceof Boolean)) {
                throw invalid("parameter '" + p.getKey() + "' must be a string, number or boolean",
                        "parameters." + p.getKey());
            }
        }
    }

    /** :name references outside literals; ignores PostgreSQL casts such as ::date. */
    static Set<String> namedParameters(String code) {
        Set<String> names = new LinkedHashSet<>();
        int i = 0;
        while (i < code.length()) {
            char c = code.charAt(i);
            if (c == ':' && i + 1 < code.length() && code.charAt(i + 1) == ':') {
                i += 2;
                continue;
            }
            if (c == ':' && i + 1 < code.length() && isNameStart(code.charAt(i + 1))) {
                int j = i + 1;
                while (j < code.length() && isNamePart(code.charAt(j))) {
                    j++;
                }
                names.add(code.substring(i + 1, j));
                i = j;
                continue;
            }
            i++;
        }
        return names;
    }

    /** Replaces the contents of quoted strings and identifiers so scans only see SQL code. */
    static String stripLiterals(String sql) {
        StringBuilder out = new StringBuilder(sql.length());
        char quote = 0;
        for (int i = 0; i < sql.length(); i++) {
            char c = sql.charAt(i);
            if (quote == 0) {
                if (c == '\'' || c == '"') {
                    quote = c;
                }
                out.append(c);
            } else if (c == quote) {
                if (i + 1 < sql.length() && sql.charAt(i + 1) == quote) {
                    out.append("__");
                    i++;
                } else {
                    quote = 0;
                    out.append(c);
                }
            } else {
                out.append('_');
            }
        }
        if (quote != 0) {
            throw invalid("query has an unterminated quote", "query");
        }
        return out.toString();
    }

    private static boolean isNameStart(char c) {
        return Character.isLetter(c) || c == '_';
    }

    private static boolean isNamePart(char c) {
        return Character.isLetterOrDigit(c) || c == '_';
    }

    private static ApiException invalid(String message, String field) {
        return ApiException.unprocessable("INVALID_QUERY", message, field);
    }
}
