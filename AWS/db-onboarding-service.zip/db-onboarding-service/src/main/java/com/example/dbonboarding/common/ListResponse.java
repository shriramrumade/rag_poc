package com.example.dbonboarding.common;

import java.util.List;

/** Shape shared by every list endpoint. */
public record ListResponse<T>(String appId, String dbId, int count, List<T> items, String nextToken) {

    public static <T> ListResponse<T> of(String appId, String dbId, List<T> items, String nextToken) {
        return new ListResponse<>(appId, dbId, items.size(), items, nextToken);
    }
}
