package com.example.dbonboarding.common;

import java.util.Set;

/** Status values shared by metadata extractions, data extractions and data loads. */
public final class RunStatus {

    public static final String SUBMITTED = "SUBMITTED";
    public static final String RUNNING = "RUNNING";
    public static final String STOPPING = "STOPPING";
    public static final String STOPPED = "STOPPED";
    public static final String SUCCEEDED = "SUCCEEDED";
    public static final String FAILED = "FAILED";

    public static final Set<String> ALL = Set.of(SUBMITTED, RUNNING, STOPPING, STOPPED, SUCCEEDED, FAILED);

    /** Value of the sparse {@code active} attribute while Glue is working on the item. */
    public static final String ACTIVE = "1";

    private RunStatus() {
    }
}
