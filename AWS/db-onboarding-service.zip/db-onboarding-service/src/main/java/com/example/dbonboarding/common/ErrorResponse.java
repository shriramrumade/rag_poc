package com.example.dbonboarding.common;

import com.fasterxml.jackson.annotation.JsonInclude;

/**
 * Error body used by every endpoint: {"error": {"code", "message", "field"}}.
 */
public record ErrorResponse(Error error) {

    @JsonInclude(JsonInclude.Include.ALWAYS)
    public record Error(String code, String message, String field) {
    }

    public static ErrorResponse of(String code, String message, String field) {
        return new ErrorResponse(new Error(code, message, field));
    }
}
