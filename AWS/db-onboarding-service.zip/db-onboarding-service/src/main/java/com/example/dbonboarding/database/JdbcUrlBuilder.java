package com.example.dbonboarding.database;

/**
 * Builds the JDBC URL from validated parts. SSL is always on; only the verification level varies.
 */
public final class JdbcUrlBuilder {

    private JdbcUrlBuilder() {
    }

    public static String build(String engine, String host, int port, String database, String sslMode) {
        return switch (engine) {
            case "postgresql" -> "jdbc:postgresql://" + host + ":" + port + "/" + database
                    + "?ssl=true&sslmode=" + sslMode;
            case "mysql" -> "jdbc:mysql://" + host + ":" + port + "/" + database
                    + "?sslMode=" + switch (sslMode) {
                        case "verify-ca" -> "VERIFY_CA";
                        case "verify-full" -> "VERIFY_IDENTITY";
                        default -> "REQUIRED";
                    };
            case "mariadb" -> "jdbc:mariadb://" + host + ":" + port + "/" + database
                    + "?sslMode=" + switch (sslMode) {
                        case "verify-ca" -> "verify-ca";
                        case "verify-full" -> "verify-full";
                        default -> "trust";
                    };
            case "oracle" -> "jdbc:oracle:thin:@//" + host + ":" + port + "/" + database;
            case "sqlserver" -> "jdbc:sqlserver://" + host + ":" + port + ";databaseName=" + database
                    + ";encrypt=true;trustServerCertificate=" + ("require".equals(sslMode) ? "true" : "false");
            default -> throw new IllegalArgumentException("unsupported engine " + engine);
        };
    }
}
