package com.example.dbonboarding.extraction;

import com.example.dbonboarding.common.ApiException;
import com.example.dbonboarding.extraction.ExtractionDtos.CreateDataExtractionRequest;
import com.example.dbonboarding.extraction.ExtractionDtos.FilterSpec;
import com.example.dbonboarding.extraction.ExtractionDtos.RelationshipSpec;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Set;

/**
 * Checks an extraction request against the database's stored metadata: tables and columns must
 * exist, filters must be well formed, and the optional query must be a parameterized SELECT.
 */
public final class ExtractionValidator {

    public static final Set<String> JOIN_TYPES = Set.of("INNER", "LEFT", "RIGHT", "FULL");
    public static final Set<String> OPERATORS = Set.of(
            "EQ", "NE", "GT", "GTE", "LT", "LTE", "IN", "NOT_IN", "BETWEEN", "LIKE", "IS_NULL", "IS_NOT_NULL");

    private ExtractionValidator() {
    }

    /**
     * @param columnsByTable "schema.table" to its column names, for every table in the database
     */
    public static void validate(CreateDataExtractionRequest req, Map<String, Set<String>> columnsByTable) {
        List<String> tables = req.tables();
        for (int i = 0; i < tables.size(); i++) {
            if (!columnsByTable.containsKey(tables.get(i))) {
                throw ApiException.notFound("TABLE_NOT_FOUND",
                        "table '" + tables.get(i) + "' is not in the extracted metadata", "tables[" + i + "]");
            }
        }

        List<RelationshipSpec> rels = req.relationships() == null ? List.of() : req.relationships();
        for (int i = 0; i < rels.size(); i++) {
            RelationshipSpec r = rels.get(i);
            requireColumn(r.from(), tables, columnsByTable, "relationships[" + i + "].from");
            requireColumn(r.to(), tables, columnsByTable, "relationships[" + i + "].to");
            if (r.joinType() != null && !JOIN_TYPES.contains(r.joinType().toUpperCase(Locale.ROOT))) {
                throw ApiException.badRequest("INVALID_SCHEMA",
                        "join_type must be one of " + JOIN_TYPES, "relationships[" + i + "].join_type");
            }
        }

        List<FilterSpec> filters = req.filters() == null ? List.of() : req.filters();
        for (int i = 0; i < filters.size(); i++) {
            FilterSpec f = filters.get(i);
            String field = "filters[" + i + "]";
            requireColumn(f.column(), tables, columnsByTable, field + ".column");
            validateFilter(f, field);
        }

        if (req.query() == null || req.query().isBlank()) {
            if (tables.size() > 1 && rels.size() < tables.size() - 1) {
                throw ApiException.badRequest("INVALID_SCHEMA",
                        "without a query, every table must be joined: give at least "
                                + (tables.size() - 1) + " relationships", "relationships");
            }
        }
        QueryValidator.validate(req.query(), req.parameters());
    }

    static void validateFilter(FilterSpec f, String field) {
        String op = f.operator().toUpperCase(Locale.ROOT);
        if (!OPERATORS.contains(op)) {
            throw ApiException.unprocessable("INVALID_FILTER",
                    "operator '" + f.operator() + "' is not one of " + OPERATORS, field + ".operator");
        }
        int n = f.values() == null ? 0 : f.values().size();
        boolean ok = switch (op) {
            case "IS_NULL", "IS_NOT_NULL" -> n == 0;
            case "BETWEEN" -> n == 2;
            case "IN", "NOT_IN" -> n >= 1;
            default -> n == 1;
        };
        if (!ok) {
            throw ApiException.unprocessable("INVALID_FILTER",
                    "operator '" + op + "' got " + n + " values", field + ".values");
        }
        if (f.values() != null) {
            for (Object v : f.values()) {
                if (v != null && !(v instanceof String) && !(v instanceof Number) && !(v instanceof Boolean)) {
                    throw ApiException.unprocessable("INVALID_FILTER",
                            "filter values must be strings, numbers or booleans", field + ".values");
                }
            }
        }
    }

    private static void requireColumn(String ref, List<String> tables, Map<String, Set<String>> columnsByTable,
                                      String field) {
        int dot = ref.lastIndexOf('.');
        String table = ref.substring(0, dot);
        String column = ref.substring(dot + 1);
        if (!tables.contains(table)) {
            throw ApiException.badRequest("INVALID_SCHEMA",
                    "table '" + table + "' is not in the request's tables list", field);
        }
        Set<String> cols = columnsByTable.get(table);
        if (cols == null || !cols.contains(column)) {
            throw ApiException.unprocessable("COLUMN_NOT_FOUND",
                    "column '" + column + "' does not exist in " + table, field);
        }
    }
}
