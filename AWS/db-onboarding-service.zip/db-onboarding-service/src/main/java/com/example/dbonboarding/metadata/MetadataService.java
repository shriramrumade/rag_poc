package com.example.dbonboarding.metadata;

import com.example.dbonboarding.audit.AuditService;
import com.example.dbonboarding.common.ApiException;
import com.example.dbonboarding.common.Ids;
import com.example.dbonboarding.common.JsonAttr;
import com.example.dbonboarding.common.PageTokens;
import com.example.dbonboarding.common.Versions;
import com.example.dbonboarding.database.DatabaseService;
import com.example.dbonboarding.metadata.MetadataDtos.FetchMetadataResponse;
import com.example.dbonboarding.security.AccessGuard;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Set;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

/**
 * Stored metadata: fetch (API 8), update one table (API 9), and ingest of extraction output.
 */
@Service
public class MetadataService {

    /** Every table key sorts after this value; the special "#..." keys sort before it. */
    private static final String FIRST_TABLE_KEY = "#~";

    private final DynamoDbTable<TableMetadataRecord> table;
    private final DatabaseService databases;
    private final AccessGuard guard;
    private final AuditService audit;
    private final JsonAttr json;

    public MetadataService(DynamoDbTable<TableMetadataRecord> table, DatabaseService databases,
                           AccessGuard guard, AuditService audit, JsonAttr json) {
        this.table = table;
        this.databases = databases;
        this.guard = guard;
        this.audit = audit;
        this.json = json;
    }

    // 8. Fetch metadata
    public FetchMetadataResponse fetch(String appId, String dbId, int limit, String nextToken) {
        guard.requireApp(appId);
        databases.requireActive(appId, dbId);
        String appDb = TableMetadataRecord.appDb(appId, dbId);
        TableMetadataRecord summary = table.getItem(key(appDb, TableMetadataRecord.SUMMARY));
        if (summary == null) {
            throw ApiException.notFound("METADATA_NOT_FOUND",
                    "no completed metadata extraction for '" + dbId + "'", "db_id");
        }
        QueryEnhancedRequest.Builder q = QueryEnhancedRequest.builder()
                .queryConditional(QueryConditional.sortGreaterThan(key(appDb, FIRST_TABLE_KEY)))
                .limit(Math.max(1, Math.min(limit, 200)));
        Map<String, AttributeValue> start = PageTokens.decode(nextToken);
        if (start != null) {
            q.exclusiveStartKey(start);
        }
        Page<TableMetadataRecord> page = table.query(q.build()).iterator().next();
        List<JsonNode> tables = page.items().stream().map(this::tableNode).map(n -> (JsonNode) n).toList();

        JsonNode s = json.read(summary.getPayloadJson());
        JsonNode relationships = null;
        if (nextToken == null) {
            TableMetadataRecord rel = table.getItem(key(appDb, TableMetadataRecord.RELATIONSHIPS));
            relationships = rel == null ? json.mapper().createArrayNode() : json.read(rel.getPayloadJson());
        }
        return new FetchMetadataResponse(appId, dbId,
                s.path("catalog_database").asText(null),
                s.path("last_extraction_id").asText(null),
                s.path("extracted_at").asText(null),
                s.path("table_count").asInt(),
                tables, relationships, PageTokens.encode(page.lastEvaluatedKey()));
    }

    // 9. Update table metadata
    public ObjectNode updateTable(String appId, String dbId, String tableKey, long ifMatch, ObjectNode body) {
        guard.requireApp(appId);
        databases.requireActive(appId, dbId);
        if (tableKey.startsWith("#")) {
            throw ApiException.notFound("TABLE_NOT_FOUND", "table '" + tableKey + "' not found", "table");
        }
        TableMetadataRecord rec = table.getItem(key(TableMetadataRecord.appDb(appId, dbId), tableKey));
        if (rec == null) {
            throw ApiException.notFound("TABLE_NOT_FOUND",
                    "table '" + tableKey + "' is not in the extracted metadata", "table");
        }
        Versions.requireMatch(rec.getVersion(), ifMatch, tableKey);

        String reason = null;
        ArrayNode columns = (ArrayNode) json.read(rec.getColumnsJson());
        Iterator<Map.Entry<String, JsonNode>> fields = body.fields();
        while (fields.hasNext()) {
            Map.Entry<String, JsonNode> f = fields.next();
            switch (f.getKey()) {
                case "description" -> rec.setDescription(f.getValue().isNull() ? null : f.getValue().asText());
                case "change_reason" -> reason = f.getValue().asText();
                case "columns" -> applyColumnEdits(tableKey, columns, f.getValue());
                case "schema", "table", "version", "row_count_estimate", "primary_key" ->
                        throw ApiException.badRequest("FIELD_NOT_EDITABLE", f.getKey() + " cannot be changed", f.getKey());
                default -> throw ApiException.badRequest("INVALID_SCHEMA", "unknown field " + f.getKey(), f.getKey());
            }
        }
        String user = guard.userId();
        rec.setColumnsJson(json.write(columns));
        rec.setUpdatedBy(user);
        rec.setUpdatedAt(Ids.now());
        rec = table.updateItem(rec);
        audit.record("table_metadata#" + appId + "#" + dbId + "#" + tableKey, "UPDATE", user, reason, body.toString());

        ObjectNode out = json.mapper().createObjectNode();
        out.put("app_id", appId);
        out.put("db_id", dbId);
        out.setAll(tableNode(rec));
        out.put("updated_by", rec.getUpdatedBy());
        out.put("updated_at", rec.getUpdatedAt());
        return out;
    }

    private void applyColumnEdits(String tableKey, ArrayNode columns, JsonNode edits) {
        if (!edits.isArray()) {
            throw ApiException.badRequest("INVALID_SCHEMA", "columns must be an array", "columns");
        }
        Map<String, ObjectNode> byName = new LinkedHashMap<>();
        columns.forEach(c -> byName.put(c.path("name").asText(), (ObjectNode) c));
        for (int i = 0; i < edits.size(); i++) {
            JsonNode edit = edits.get(i);
            String prefix = "columns[" + i + "]";
            String name = edit.path("name").asText(null);
            ObjectNode target = name == null ? null : byName.get(name);
            if (target == null) {
                throw ApiException.unprocessable("COLUMN_NOT_FOUND",
                        "column '" + name + "' does not exist in " + tableKey, prefix + ".name");
            }
            Iterator<Map.Entry<String, JsonNode>> it = edit.fields();
            while (it.hasNext()) {
                Map.Entry<String, JsonNode> f = it.next();
                String k = f.getKey();
                if ("name".equals(k)) {
                    continue;
                }
                if (GovernanceRules.READ_ONLY_COLUMN_FIELDS.contains(k)) {
                    throw ApiException.badRequest("FIELD_NOT_EDITABLE", k + " cannot be changed", prefix + "." + k);
                }
                if (!GovernanceRules.EDITABLE_COLUMN_FIELDS.contains(k)) {
                    throw ApiException.badRequest("INVALID_SCHEMA", "unknown field " + k, prefix + "." + k);
                }
                GovernanceRules.validate(prefix + "." + k, k, f.getValue());
                target.set(k, f.getValue());
            }
            ObjectNode detection = json.mapper().createObjectNode();
            detection.put("method", "MANUAL");
            detection.putNull("confidence");
            target.set("detection", detection);
        }
    }

    /**
     * Stores the output of a metadata extraction run (metadata.json written by the Glue job).
     * Columns a person tagged by hand (detection.method MANUAL) keep their tags.
     *
     * @return counts for the run's result
     */
    public ObjectNode ingest(String appId, String dbId, String extractionId, String catalogDatabase, JsonNode metadata) {
        String appDb = TableMetadataRecord.appDb(appId, dbId);
        Map<String, TableMetadataRecord> existing = loadTables(appId, dbId);
        Set<String> seen = new HashSet<>();
        int added = 0;
        int updated = 0;
        String now = Ids.now();

        for (JsonNode t : metadata.path("tables")) {
            String schema = t.path("schema").asText();
            String name = t.path("table").asText();
            String tableKey = schema + "." + name;
            seen.add(tableKey);
            TableMetadataRecord rec = existing.get(tableKey);
            ArrayNode columns = t.path("columns").isArray()
                    ? ((ArrayNode) t.path("columns")).deepCopy() : json.mapper().createArrayNode();
            if (rec == null) {
                rec = new TableMetadataRecord();
                rec.setAppDb(appDb);
                rec.setTableKey(tableKey);
                added++;
            } else {
                keepManualTags(columns, (ArrayNode) json.read(rec.getColumnsJson()));
                updated++;
            }
            rec.setSchemaName(schema);
            rec.setTableName(name);
            rec.setRowCountEstimate(t.path("row_count_estimate").isNumber() ? t.path("row_count_estimate").asLong() : null);
            rec.setPrimaryKeyJson(json.write(t.path("primary_key").isArray() ? t.path("primary_key") : json.mapper().createArrayNode()));
            rec.setColumnsJson(json.write(columns));
            rec.setUpdatedBy("metadata-extraction:" + extractionId);
            rec.setUpdatedAt(now);
            table.updateItem(rec);
        }

        int removed = 0;
        for (String tableKey : existing.keySet()) {
            if (!seen.contains(tableKey)) {
                table.deleteItem(key(appDb, tableKey));
                removed++;
            }
        }

        JsonNode relationships = metadata.path("relationships").isArray()
                ? metadata.path("relationships") : json.mapper().createArrayNode();
        putSpecial(appDb, TableMetadataRecord.RELATIONSHIPS, relationships, now);

        ObjectNode summary = json.mapper().createObjectNode();
        summary.put("catalog_database", catalogDatabase);
        summary.put("last_extraction_id", extractionId);
        summary.put("extracted_at", now);
        summary.put("table_count", seen.size());
        putSpecial(appDb, TableMetadataRecord.SUMMARY, summary, now);

        ObjectNode result = json.mapper().createObjectNode();
        result.put("tables_found", seen.size());
        result.put("tables_added", added);
        result.put("tables_updated", updated);
        result.put("tables_removed", removed);
        result.put("relationships_found", relationships.size());
        result.put("catalog_database", catalogDatabase);
        return result;
    }

    /** All table records for a database, keyed by "schema.table". */
    public Map<String, TableMetadataRecord> loadTables(String appId, String dbId) {
        String appDb = TableMetadataRecord.appDb(appId, dbId);
        Map<String, TableMetadataRecord> out = new LinkedHashMap<>();
        table.query(QueryEnhancedRequest.builder()
                        .queryConditional(QueryConditional.sortGreaterThan(key(appDb, FIRST_TABLE_KEY)))
                        .build())
                .items()
                .forEach(r -> out.put(r.getTableKey(), r));
        return out;
    }

    /** Column objects of a stored table. */
    public List<JsonNode> columns(TableMetadataRecord rec) {
        List<JsonNode> out = new ArrayList<>();
        JsonNode cols = json.read(rec.getColumnsJson());
        if (cols != null) {
            cols.forEach(out::add);
        }
        return out;
    }

    public ObjectNode tableNode(TableMetadataRecord r) {
        ObjectNode n = json.mapper().createObjectNode();
        n.put("schema", r.getSchemaName());
        n.put("table", r.getTableName());
        if (r.getDescription() != null) {
            n.put("description", r.getDescription());
        }
        n.put("version", r.getVersion());
        if (r.getRowCountEstimate() != null) {
            n.put("row_count_estimate", r.getRowCountEstimate());
        }
        n.set("primary_key", json.read(r.getPrimaryKeyJson()));
        n.set("columns", json.read(r.getColumnsJson()));
        return n;
    }

    private void keepManualTags(ArrayNode fresh, ArrayNode old) {
        if (old == null) {
            return;
        }
        Map<String, JsonNode> oldByName = new LinkedHashMap<>();
        old.forEach(c -> oldByName.put(c.path("name").asText(), c));
        for (JsonNode c : fresh) {
            JsonNode prev = oldByName.get(c.path("name").asText());
            if (prev != null && "MANUAL".equals(prev.path("detection").path("method").asText())) {
                ObjectNode col = (ObjectNode) c;
                for (String k : List.of("is_sensitive", "pii_type", "classification", "pii_rule", "detection")) {
                    if (prev.has(k)) {
                        col.set(k, prev.get(k));
                    }
                }
            }
        }
    }

    private void putSpecial(String appDb, String tableKey, JsonNode payload, String now) {
        TableMetadataRecord rec = table.getItem(key(appDb, tableKey));
        if (rec == null) {
            rec = new TableMetadataRecord();
            rec.setAppDb(appDb);
            rec.setTableKey(tableKey);
        }
        rec.setPayloadJson(json.write(payload));
        rec.setUpdatedAt(now);
        table.updateItem(rec);
    }

    private static Key key(String appDb, String tableKey) {
        return Key.builder().partitionValue(appDb).sortValue(tableKey).build();
    }
}
