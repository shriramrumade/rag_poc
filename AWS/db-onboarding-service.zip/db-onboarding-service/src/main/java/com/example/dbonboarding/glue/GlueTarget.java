package com.example.dbonboarding.glue;

/** The account and region where a database's Glue jobs run (Account B). */
public record GlueTarget(String accountId, String region) {
}
