package com.example.dbonboarding.database;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;

/** Request and response bodies for /v1/databases. */
public final class DatabaseDtos {

    private DatabaseDtos() {
    }

    public record CreateDatabaseRequest(
            @NotBlank @Pattern(regexp = "^[A-Za-z0-9_-]{1,64}$") String appId,
            @NotBlank @Pattern(regexp = "^[a-z0-9_]{3,64}$") String dbId,
            @NotBlank String engine,
            @NotBlank String host,
            @NotNull Integer port,
            @NotBlank @Pattern(regexp = "^[A-Za-z0-9_.]{1,64}$") String database,
            @NotBlank String authType,
            String dbUser,
            String sslMode,
            @Pattern(regexp = "^\\d{12}$") String targetAccountId,
            String region) {
    }

    public record DatabaseResponse(
            String appId,
            String dbId,
            String engine,
            String host,
            Integer port,
            String database,
            String sslMode,
            String authType,
            String dbUser,
            String targetAccountId,
            String region,
            String status,
            Long version,
            String createdBy,
            String createdAt,
            String updatedBy,
            String updatedAt) {

        public static DatabaseResponse from(DatabaseRecord r) {
            return new DatabaseResponse(r.getAppId(), r.getDbId(), r.getEngine(), r.getHost(), r.getPort(),
                    r.getDatabase(), r.getSslMode(), r.getAuthType(), r.getDbUser(), r.getTargetAccountId(),
                    r.getRegion(), r.getStatus(), r.getVersion(), r.getCreatedBy(), r.getCreatedAt(),
                    r.getUpdatedBy(), r.getUpdatedAt());
        }
    }
}
