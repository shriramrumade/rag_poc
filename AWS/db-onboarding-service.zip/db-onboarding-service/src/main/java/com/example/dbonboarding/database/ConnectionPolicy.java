package com.example.dbonboarding.database;

import com.example.dbonboarding.common.ApiException;
import com.example.dbonboarding.config.AppProperties;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.regex.Pattern;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

/**
 * Server-side rules for connection details. Users never submit a raw JDBC URL: hosts must be in
 * approved domains or CIDRs and ports must match the engine, so Glue can't be pointed at
 * arbitrary hosts or given driver options.
 */
@Component
public class ConnectionPolicy {

    public static final Set<String> ENGINES = Set.of("postgresql", "mysql", "mariadb", "oracle", "sqlserver");
    public static final Set<String> IAM_ENGINES = Set.of("postgresql", "mysql", "mariadb");
    public static final Set<String> SSL_MODES = Set.of("require", "verify-ca", "verify-full");
    public static final Set<String> AUTH_TYPES = Set.of("secret", "iam");

    private static final Pattern IPV4 = Pattern.compile("^(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})\\.(\\d{1,3})$");
    private static final Pattern HOSTNAME = Pattern.compile(
            "^[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?(\\.[a-z0-9]([a-z0-9-]{0,61}[a-z0-9])?)+$");
    private static final Pattern DB_USER = Pattern.compile("^[A-Za-z0-9_]{1,63}$");

    private final AppProperties.Policy policy;

    @Autowired
    public ConnectionPolicy(AppProperties props) {
        this(props.policy());
    }

    ConnectionPolicy(AppProperties.Policy policy) {
        this.policy = policy;
    }

    public void validateEngine(String engine) {
        if (engine == null || !ENGINES.contains(engine)) {
            throw ApiException.badRequest("INVALID_SCHEMA", "engine must be one of " + ENGINES, "engine");
        }
    }

    public String normalizeSslMode(String sslMode) {
        if (sslMode == null || sslMode.isBlank()) {
            return "require";
        }
        if (!SSL_MODES.contains(sslMode)) {
            throw ApiException.badRequest("INVALID_SCHEMA", "ssl_mode must be one of " + SSL_MODES, "ssl_mode");
        }
        return sslMode;
    }

    public String normalizeHost(String host) {
        String h = host == null ? "" : host.trim().toLowerCase(Locale.ROOT);
        var ip = IPV4.matcher(h);
        if (ip.matches()) {
            if (!ipAllowed(h)) {
                throw ApiException.unprocessable("HOST_NOT_ALLOWED", "host IP is outside the approved CIDRs", "host");
            }
            return h;
        }
        if (!HOSTNAME.matcher(h).matches()) {
            throw ApiException.unprocessable("HOST_NOT_ALLOWED", "host is not a valid DNS name", "host");
        }
        List<String> suffixes = policy.allowedHostSuffixes() == null ? List.of() : policy.allowedHostSuffixes();
        boolean ok = suffixes.stream().anyMatch(s -> h.endsWith(s.toLowerCase(Locale.ROOT)));
        if (!ok) {
            throw ApiException.unprocessable("HOST_NOT_ALLOWED", "host must end with an approved domain suffix", "host");
        }
        return h;
    }

    public void validatePort(String engine, Integer port) {
        List<Integer> allowed = policy.allowedPorts() == null ? null : policy.allowedPorts().get(engine);
        if (port == null || allowed == null || !allowed.contains(port)) {
            throw ApiException.unprocessable("PORT_NOT_ALLOWED",
                    "port " + port + " is not allowed for engine " + engine, "port");
        }
    }

    public void validateAuth(String engine, String host, String authType, String dbUser) {
        if (authType == null || !AUTH_TYPES.contains(authType)) {
            throw ApiException.badRequest("INVALID_SCHEMA", "auth_type must be 'secret' or 'iam'", "auth_type");
        }
        if ("iam".equals(authType)) {
            if (!IAM_ENGINES.contains(engine) || !host.endsWith(".rds.amazonaws.com")) {
                throw ApiException.unprocessable("IAM_AUTH_NOT_SUPPORTED",
                        "auth_type 'iam' needs an RDS or Aurora PostgreSQL, MySQL or MariaDB host", "auth_type");
            }
            if (dbUser == null || !DB_USER.matcher(dbUser).matches()) {
                throw ApiException.badRequest("INVALID_SCHEMA",
                        "db_user is required for auth_type 'iam' (letters, digits, underscore)", "db_user");
            }
        }
    }

    public void validateTarget(String accountId, String region) {
        if (accountId == null || !accountId.matches("^\\d{12}$")
                || policy.onboardedAccounts() == null || !policy.onboardedAccounts().contains(accountId)) {
            throw ApiException.unprocessable("ACCOUNT_NOT_ONBOARDED",
                    "target account " + accountId + " is not onboarded", "target_account_id");
        }
        if (region == null || policy.allowedRegions() == null || !policy.allowedRegions().contains(region)) {
            throw ApiException.unprocessable("REGION_NOT_ALLOWED", "region " + region + " is not allowed", "region");
        }
    }

    private boolean ipAllowed(String ip) {
        if (policy.allowedCidrs() == null) {
            return false;
        }
        long addr = toLong(ip);
        if (addr < 0) {
            return false;
        }
        for (String cidr : policy.allowedCidrs()) {
            String[] parts = cidr.split("/");
            long net = toLong(parts[0]);
            int bits = parts.length > 1 ? Integer.parseInt(parts[1]) : 32;
            long mask = bits == 0 ? 0 : (0xFFFFFFFFL << (32 - bits)) & 0xFFFFFFFFL;
            if (net >= 0 && (addr & mask) == (net & mask)) {
                return true;
            }
        }
        return false;
    }

    private static long toLong(String ip) {
        var m = IPV4.matcher(ip);
        if (!m.matches()) {
            return -1;
        }
        long v = 0;
        for (int i = 1; i <= 4; i++) {
            int octet = Integer.parseInt(m.group(i));
            if (octet > 255) {
                return -1;
            }
            v = (v << 8) | octet;
        }
        return v;
    }
}
