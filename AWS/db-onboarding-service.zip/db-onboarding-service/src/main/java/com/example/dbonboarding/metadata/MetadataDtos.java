package com.example.dbonboarding.metadata;

import com.example.dbonboarding.common.JsonAttr;
import com.fasterxml.jackson.databind.JsonNode;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Size;
import java.util.List;

/** Request and response bodies for metadata extraction and metadata APIs. */
public final class MetadataDtos {

    private MetadataDtos() {
    }

    public record StartMetadataExtractionRequest(
            @NotBlank String appId,
            @NotBlank String dbId,
            @Pattern(regexp = "^[a-z0-9_]{1,255}$") String catalogDatabase,
            @Size(max = 20) List<@Pattern(regexp = "^[A-Za-z0-9_.%/]{1,255}$") String> includePaths,
            @Size(max = 20) List<@Pattern(regexp = "^[A-Za-z0-9_.*%-]{1,128}$") String> excludePatterns) {
    }

    public record MetadataExtractionResponse(
            String extractionId,
            String appId,
            String dbId,
            String status,
            String catalogDatabase,
            String submittedBy,
            String submittedAt,
            String startedAt,
            String completedAt,
            JsonNode result,
            JsonNode error) {

        public static MetadataExtractionResponse from(MetadataExtractionRecord r, JsonAttr json) {
            return new MetadataExtractionResponse(r.getExtractionId(), r.getAppId(), r.getDbId(), r.getStatus(),
                    r.getCatalogDatabase(), r.getSubmittedBy(), r.getSubmittedAt(), r.getStartedAt(),
                    r.getCompletedAt(), json.read(r.getResultJson()), json.read(r.getErrorJson()));
        }
    }

    public record FetchMetadataResponse(
            String appId,
            String dbId,
            String catalogDatabase,
            String lastExtractionId,
            String extractedAt,
            Integer tableCount,
            List<JsonNode> tables,
            JsonNode relationships,
            String nextToken) {
    }
}
