package com.example.dbonboarding.sync;

import com.example.dbonboarding.common.RunStatus;
import com.example.dbonboarding.extraction.DataExtractionService;
import com.example.dbonboarding.extraction.ExtractionRequestRecord;
import com.example.dbonboarding.load.DataLoadRecord;
import com.example.dbonboarding.load.DataLoadService;
import com.example.dbonboarding.metadata.MetadataExtractionRecord;
import com.example.dbonboarding.metadata.MetadataExtractionService;
import java.util.function.Consumer;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.boot.autoconfigure.condition.ConditionalOnProperty;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.GetItemEnhancedRequest;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.services.dynamodb.model.ConditionalCheckFailedException;

/**
 * Polls Glue for every running metadata extraction, data extraction and data load, and writes
 * the outcome back to DynamoDB. Only items on the sparse active-index are read.
 *
 * <p>Safe with several replicas: every write is version-checked, so if two pods handle the same
 * item, one write wins and the other is skipped.
 */
@Component
@ConditionalOnProperty(prefix = "app.sync", name = "enabled", havingValue = "true", matchIfMissing = true)
public class GlueStatusSync {

    private static final Logger log = LoggerFactory.getLogger(GlueStatusSync.class);

    private final DynamoDbTable<MetadataExtractionRecord> metadataTable;
    private final DynamoDbTable<ExtractionRequestRecord> extractionTable;
    private final DynamoDbTable<DataLoadRecord> loadTable;
    private final MetadataExtractionService metadataExtractions;
    private final DataExtractionService dataExtractions;
    private final DataLoadService dataLoads;

    public GlueStatusSync(DynamoDbTable<MetadataExtractionRecord> metadataTable,
                          DynamoDbTable<ExtractionRequestRecord> extractionTable,
                          DynamoDbTable<DataLoadRecord> loadTable,
                          MetadataExtractionService metadataExtractions,
                          DataExtractionService dataExtractions,
                          DataLoadService dataLoads) {
        this.metadataTable = metadataTable;
        this.extractionTable = extractionTable;
        this.loadTable = loadTable;
        this.metadataExtractions = metadataExtractions;
        this.dataExtractions = dataExtractions;
        this.dataLoads = dataLoads;
    }

    @Scheduled(fixedDelayString = "${app.sync.interval-ms:30000}", initialDelayString = "${app.sync.interval-ms:30000}")
    public void run() {
        syncAll(metadataTable, MetadataExtractionRecord.ACTIVE_INDEX, metadataExtractions::sync, "metadata extraction");
        syncAll(extractionTable, ExtractionRequestRecord.ACTIVE_INDEX, dataExtractions::sync, "data extraction");
        syncAll(loadTable, DataLoadRecord.ACTIVE_INDEX, dataLoads::sync, "data load");
    }

    private <T> void syncAll(DynamoDbTable<T> table, String index, Consumer<T> sync, String kind) {
        QueryConditional active = QueryConditional.keyEqualTo(Key.builder().partitionValue(RunStatus.ACTIVE).build());
        table.index(index).query(r -> r.queryConditional(active)).stream()
                .flatMap(page -> page.items().stream())
                .forEach(stale -> {
                    // The index is eventually consistent; re-read the item before acting on it.
                    T item = table.getItem(GetItemEnhancedRequest.builder()
                            .key(table.keyFrom(stale))
                            .consistentRead(true)
                            .build());
                    if (item == null) {
                        return;
                    }
                    try {
                        sync.accept(item);
                    } catch (ConditionalCheckFailedException e) {
                        log.debug("{} changed concurrently; will check again next round", kind);
                    } catch (RuntimeException e) {
                        log.warn("{} status sync failed: {}", kind, e.getMessage(), e);
                    }
                });
    }
}
