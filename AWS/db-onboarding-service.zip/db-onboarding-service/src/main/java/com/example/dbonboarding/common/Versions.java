package com.example.dbonboarding.common;

/** Parses If-Match / ETag values such as "3", W/"3" or 3. */
public final class Versions {

    private Versions() {
    }

    public static long parseIfMatch(String header) {
        if (header == null) {
            throw new ApiException(org.springframework.http.HttpStatus.PRECONDITION_REQUIRED,
                    "IF_MATCH_REQUIRED", "If-Match header with the current version is required", "If-Match");
        }
        String v = header.trim();
        if (v.startsWith("W/")) {
            v = v.substring(2);
        }
        v = v.replace("\"", "").trim();
        try {
            return Long.parseLong(v);
        } catch (NumberFormatException e) {
            throw ApiException.badRequest("INVALID_SCHEMA", "If-Match must be the numeric version", "If-Match");
        }
    }

    public static String etag(Long version) {
        return "\"" + version + "\"";
    }

    public static void requireMatch(Long current, long expected, String what) {
        if (current == null || current != expected) {
            throw ApiException.versionMismatch(what + " was changed by someone else; fetch it again and retry");
        }
    }
}
