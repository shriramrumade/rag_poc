package com.example.dbonboarding.idempotency;

import com.example.dbonboarding.common.ApiException;
import com.example.dbonboarding.common.JsonAttr;
import java.nio.charset.StandardCharsets;
import java.security.MessageDigest;
import java.time.Instant;
import java.time.temporal.ChronoUnit;
import java.util.HexFormat;
import java.util.Optional;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Expression;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.PutItemEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.model.ConditionalCheckFailedException;

/**
 * Makes POST calls safe to retry. A repeated Idempotency-Key with the same body returns the
 * resource created the first time; the same key with a different body is rejected.
 */
@Service
public class IdempotencyService {

    private final DynamoDbTable<IdempotencyRecord> table;
    private final JsonAttr json;

    public IdempotencyService(DynamoDbTable<IdempotencyRecord> table, JsonAttr json) {
        this.table = table;
        this.json = json;
    }

    /**
     * Returns the resource ID created earlier for this key, if any.
     *
     * @throws ApiException 409 when the key was used with a different request body
     */
    public Optional<String> lookup(String operation, String user, String key, Object requestBody) {
        if (key == null || key.isBlank()) {
            return Optional.empty();
        }
        IdempotencyRecord rec = table.getItem(Key.builder().partitionValue(pk(operation, user, key)).build());
        if (rec == null) {
            return Optional.empty();
        }
        if (!rec.getRequestHash().equals(hash(requestBody))) {
            throw ApiException.conflict("IDEMPOTENCY_KEY_REUSED",
                    "Idempotency-Key was already used with a different request body", "Idempotency-Key");
        }
        return Optional.of(rec.getResourceId());
    }

    /** Records the resource created for this key. Kept for 24 hours. */
    public void remember(String operation, String user, String key, Object requestBody, String resourceId) {
        if (key == null || key.isBlank()) {
            return;
        }
        IdempotencyRecord rec = new IdempotencyRecord();
        rec.setIdemKey(pk(operation, user, key));
        rec.setRequestHash(hash(requestBody));
        rec.setResourceId(resourceId);
        rec.setExpiresAt(Instant.now().plus(24, ChronoUnit.HOURS).getEpochSecond());
        try {
            table.putItem(PutItemEnhancedRequest.builder(IdempotencyRecord.class)
                    .item(rec)
                    .conditionExpression(Expression.builder().expression("attribute_not_exists(idem_key)").build())
                    .build());
        } catch (ConditionalCheckFailedException ignored) {
            // A concurrent retry stored it first; both point at a valid resource.
        }
    }

    private static String pk(String operation, String user, String key) {
        return operation + "#" + user + "#" + key;
    }

    private String hash(Object body) {
        try {
            byte[] digest = MessageDigest.getInstance("SHA-256")
                    .digest(json.write(body).getBytes(StandardCharsets.UTF_8));
            return HexFormat.of().formatHex(digest);
        } catch (Exception e) {
            throw new IllegalStateException(e);
        }
    }
}
