package com.example.dbonboarding.glue;

import com.example.dbonboarding.common.ApiException;
import com.example.dbonboarding.config.AppProperties;
import java.time.Instant;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ConcurrentHashMap;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import software.amazon.awssdk.auth.credentials.AwsCredentialsProvider;
import software.amazon.awssdk.core.sync.RequestBody;
import software.amazon.awssdk.regions.Region;
import software.amazon.awssdk.services.glue.GlueClient;
import software.amazon.awssdk.services.glue.model.BatchStopJobRunRequest;
import software.amazon.awssdk.services.glue.model.ConcurrentRunsExceededException;
import software.amazon.awssdk.services.glue.model.ConnectionInput;
import software.amazon.awssdk.services.glue.model.ConnectionPropertyKey;
import software.amazon.awssdk.services.glue.model.ConnectionType;
import software.amazon.awssdk.services.glue.model.CreateConnectionRequest;
import software.amazon.awssdk.services.glue.model.GetConnectionRequest;
import software.amazon.awssdk.services.glue.model.PhysicalConnectionRequirements;
import software.amazon.awssdk.services.glue.model.UpdateConnectionRequest;
import software.amazon.awssdk.services.glue.model.CrawlerRunningException;
import software.amazon.awssdk.services.glue.model.CrawlerTargets;
import software.amazon.awssdk.services.glue.model.CreateCrawlerRequest;
import software.amazon.awssdk.services.glue.model.Crawler;
import software.amazon.awssdk.services.glue.model.EntityNotFoundException;
import software.amazon.awssdk.services.glue.model.GetCrawlerRequest;
import software.amazon.awssdk.services.glue.model.GetJobRunRequest;
import software.amazon.awssdk.services.glue.model.JdbcTarget;
import software.amazon.awssdk.services.glue.model.JobRun;
import software.amazon.awssdk.services.glue.model.LastCrawlInfo;
import software.amazon.awssdk.services.glue.model.StartCrawlerRequest;
import software.amazon.awssdk.services.glue.model.StartJobRunRequest;
import software.amazon.awssdk.services.glue.model.UpdateCrawlerRequest;
import software.amazon.awssdk.services.s3.S3Client;
import software.amazon.awssdk.services.s3.model.GetObjectRequest;
import software.amazon.awssdk.services.s3.model.NoSuchKeyException;
import software.amazon.awssdk.services.s3.model.PutObjectRequest;
import software.amazon.awssdk.services.sts.StsClient;
import software.amazon.awssdk.services.sts.auth.StsAssumeRoleCredentialsProvider;
import software.amazon.awssdk.services.sts.model.AssumeRoleRequest;

/**
 * All calls into Account B. Assumes {@code GlueInvokerRole} in the target account (credentials
 * are cached and refreshed automatically) and talks to Glue and S3 there.
 */
@Component
public class GlueGateway {

    private static final Logger log = LoggerFactory.getLogger(GlueGateway.class);

    private final AppProperties props;
    private final StsClient sts;
    private final Map<String, AwsCredentialsProvider> credentials = new ConcurrentHashMap<>();
    private final Map<String, GlueClient> glueClients = new ConcurrentHashMap<>();
    private final Map<String, S3Client> s3Clients = new ConcurrentHashMap<>();

    public GlueGateway(AppProperties props, StsClient sts) {
        this.props = props;
        this.sts = sts;
    }

    /** State of one Glue job run. */
    public record JobStatus(String state, String errorMessage) {
        public boolean finished() {
            return switch (state) {
                case "SUCCEEDED", "FAILED", "STOPPED", "TIMEOUT", "ERROR", "EXPIRED" -> true;
                default -> false;
            };
        }
    }

    /** State of a crawler and its most recent crawl. */
    public record CrawlStatus(String state, String lastStatus, Instant lastStartTime, String errorMessage) {
    }

    // ---------------------------------------------------------------- connection

    /**
     * Creates or updates the JDBC Glue connection the crawler uses. It references the secret by
     * name only; Glue reads the username and password from Secrets Manager itself.
     */
    public void ensureJdbcConnection(GlueTarget t, String name, String jdbcUrl, String secretName) {
        AppProperties.Network net = props.glue().networks() == null ? null : props.glue().networks().get(t.accountId());
        if (net == null) {
            throw new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL_ERROR",
                    "no Glue network configured for account " + t.accountId(), null);
        }
        Map<ConnectionPropertyKey, String> properties = Map.of(
                ConnectionPropertyKey.JDBC_CONNECTION_URL, jdbcUrl,
                ConnectionPropertyKey.SECRET_ID, secretName,
                ConnectionPropertyKey.JDBC_ENFORCE_SSL, "true");
        ConnectionInput input = ConnectionInput.builder()
                .name(name)
                .connectionType(ConnectionType.JDBC)
                .connectionProperties(properties)
                .physicalConnectionRequirements(PhysicalConnectionRequirements.builder()
                        .subnetId(net.subnetId())
                        .securityGroupIdList(net.securityGroupIds())
                        .availabilityZone(net.availabilityZone())
                        .build())
                .build();
        GlueClient glue = glue(t);
        try {
            glue.getConnection(GetConnectionRequest.builder().name(name).hidePassword(true).build());
            glue.updateConnection(UpdateConnectionRequest.builder().name(name).connectionInput(input).build());
        } catch (EntityNotFoundException notFound) {
            glue.createConnection(CreateConnectionRequest.builder().connectionInput(input).build());
        }
    }

    // ---------------------------------------------------------------- crawler

    /** Points the crawler at the database (creating it on first use) and starts it. */
    public void startCrawler(GlueTarget t, String name, String catalogDatabase, String connectionName,
                             List<String> includePaths, List<String> exclusions) {
        GlueClient glue = glue(t);
        String role = "arn:aws:iam::" + t.accountId() + ":role/" + props.glue().crawlerRoleName();
        List<JdbcTarget> targets = includePaths.stream()
                .map(path -> JdbcTarget.builder()
                        .connectionName(connectionName)
                        .path(path)
                        .exclusions(exclusions)
                        .build())
                .toList();
        CrawlerTargets crawlerTargets = CrawlerTargets.builder().jdbcTargets(targets).build();
        try {
            glue.updateCrawler(UpdateCrawlerRequest.builder()
                    .name(name).role(role).databaseName(catalogDatabase).targets(crawlerTargets).build());
        } catch (EntityNotFoundException notFound) {
            glue.createCrawler(CreateCrawlerRequest.builder()
                    .name(name).role(role).databaseName(catalogDatabase).targets(crawlerTargets).build());
        } catch (CrawlerRunningException running) {
            throw ApiException.conflict("EXTRACTION_IN_PROGRESS",
                    "crawler '" + name + "' is already running", "db_id");
        }
        try {
            glue.startCrawler(StartCrawlerRequest.builder().name(name).build());
        } catch (CrawlerRunningException running) {
            throw ApiException.conflict("EXTRACTION_IN_PROGRESS",
                    "crawler '" + name + "' is already running", "db_id");
        }
    }

    public CrawlStatus getCrawler(GlueTarget t, String name) {
        Crawler crawler = glue(t).getCrawler(GetCrawlerRequest.builder().name(name).build()).crawler();
        LastCrawlInfo last = crawler.lastCrawl();
        return new CrawlStatus(
                crawler.stateAsString(),
                last == null ? null : last.statusAsString(),
                last == null ? null : last.startTime(),
                last == null ? null : last.errorMessage());
    }

    // ---------------------------------------------------------------- jobs

    /** Starts a Glue job run and returns its run ID. Glue concurrency limits surface as 429. */
    public String startJob(GlueTarget t, String jobName, Map<String, String> args, int workers) {
        try {
            String runId = glue(t).startJobRun(StartJobRunRequest.builder()
                    .jobName(jobName)
                    .arguments(args)
                    .workerType(props.glue().workerType())
                    .numberOfWorkers(workers)
                    .timeout(props.glue().timeoutMinutes())
                    .build()).jobRunId();
            log.info("started glue job {} run {} in {}/{}", jobName, runId, t.accountId(), t.region());
            return runId;
        } catch (ConcurrentRunsExceededException e) {
            throw ApiException.rateLimited("Glue concurrent runs exceeded for " + jobName + "; retry later");
        }
    }

    public JobStatus getJobRun(GlueTarget t, String jobName, String runId) {
        JobRun run = glue(t).getJobRun(GetJobRunRequest.builder().jobName(jobName).runId(runId).build()).jobRun();
        return new JobStatus(run.jobRunStateAsString(), run.errorMessage());
    }

    public void stopJob(GlueTarget t, String jobName, String runId) {
        glue(t).batchStopJobRun(BatchStopJobRunRequest.builder().jobName(jobName).jobRunIds(runId).build());
    }

    // ---------------------------------------------------------------- S3

    /** Bucket used for this target account, from the configured template. */
    public String bucket(GlueTarget t) {
        return props.storage().bucketTemplate()
                .replace("{account_id}", t.accountId())
                .replace("{region}", t.region());
    }

    /** Reads a small text object (manifest, result, metadata). Empty when it does not exist. */
    public Optional<String> readText(GlueTarget t, String s3Uri) {
        S3Location loc = S3Location.parse(s3Uri);
        try {
            return Optional.of(s3(t).getObjectAsBytes(GetObjectRequest.builder()
                    .bucket(loc.bucket()).key(loc.key()).build()).asUtf8String());
        } catch (NoSuchKeyException e) {
            return Optional.empty();
        }
    }

    public void writeText(GlueTarget t, String s3Uri, String body) {
        S3Location loc = S3Location.parse(s3Uri);
        s3(t).putObject(PutObjectRequest.builder()
                        .bucket(loc.bucket()).key(loc.key()).contentType("application/json").build(),
                RequestBody.fromString(body));
    }

    // ---------------------------------------------------------------- clients

    private GlueClient glue(GlueTarget t) {
        return glueClients.computeIfAbsent(t.accountId() + "|" + t.region(), k -> GlueClient.builder()
                .region(Region.of(t.region()))
                .credentialsProvider(credentials(t.accountId()))
                .build());
    }

    private S3Client s3(GlueTarget t) {
        return s3Clients.computeIfAbsent(t.accountId() + "|" + t.region(), k -> S3Client.builder()
                .region(Region.of(t.region()))
                .credentialsProvider(credentials(t.accountId()))
                .build());
    }

    private AwsCredentialsProvider credentials(String accountId) {
        return credentials.computeIfAbsent(accountId, a -> StsAssumeRoleCredentialsProvider.builder()
                .stsClient(sts)
                .refreshRequest(AssumeRoleRequest.builder()
                        .roleArn("arn:aws:iam::" + a + ":role/" + props.glue().invokerRoleName())
                        .roleSessionName("db-onboarding-" + a)
                        .externalId(props.glue().externalId())
                        .durationSeconds(3600)
                        .build())
                .build());
    }

    /** s3://bucket/key */
    record S3Location(String bucket, String key) {
        static S3Location parse(String uri) {
            if (uri == null || !uri.startsWith("s3://")) {
                throw new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL_ERROR", "bad S3 URI: " + uri, null);
            }
            String rest = uri.substring(5);
            int slash = rest.indexOf('/');
            if (slash <= 0) {
                throw new ApiException(HttpStatus.INTERNAL_SERVER_ERROR, "INTERNAL_ERROR", "bad S3 URI: " + uri, null);
            }
            return new S3Location(rest.substring(0, slash), rest.substring(slash + 1));
        }
    }
}
