package com.example.dbonboarding.extraction;

import com.example.dbonboarding.audit.AuditService;
import com.example.dbonboarding.common.ApiException;
import com.example.dbonboarding.common.CorrelationIdFilter;
import com.example.dbonboarding.common.Ids;
import com.example.dbonboarding.common.JsonAttr;
import com.example.dbonboarding.common.ListResponse;
import com.example.dbonboarding.common.PageTokens;
import com.example.dbonboarding.common.RunStatus;
import com.example.dbonboarding.config.AppProperties;
import com.example.dbonboarding.database.DatabaseRecord;
import com.example.dbonboarding.database.DatabaseService;
import com.example.dbonboarding.extraction.ExtractionDtos.CreateDataExtractionRequest;
import com.example.dbonboarding.extraction.ExtractionDtos.DataExtractionResponse;
import com.example.dbonboarding.extraction.ExtractionDtos.ExecuteDataExtractionRequest;
import com.example.dbonboarding.glue.GlueGateway;
import com.example.dbonboarding.glue.GlueGateway.JobStatus;
import com.example.dbonboarding.glue.GlueTarget;
import com.example.dbonboarding.idempotency.IdempotencyService;
import com.example.dbonboarding.metadata.MetadataService;
import com.example.dbonboarding.metadata.TableMetadataRecord;
import com.example.dbonboarding.security.AccessGuard;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Expression;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.Page;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

/** Data extraction requests: APIs 10 to 14 and 20 (execute). */
@Service
public class DataExtractionService {

    private static final Logger log = LoggerFactory.getLogger(DataExtractionService.class);
    private static final Set<String> FORMATS = Set.of("parquet", "csv", "json");

    private final DynamoDbTable<ExtractionRequestRecord> table;
    private final DatabaseService databases;
    private final MetadataService metadata;
    private final GlueGateway glue;
    private final AccessGuard guard;
    private final IdempotencyService idempotency;
    private final AuditService audit;
    private final AppProperties props;
    private final JsonAttr json;

    public DataExtractionService(DynamoDbTable<ExtractionRequestRecord> table, DatabaseService databases,
                                 MetadataService metadata, GlueGateway glue, AccessGuard guard,
                                 IdempotencyService idempotency, AuditService audit, AppProperties props,
                                 JsonAttr json) {
        this.table = table;
        this.databases = databases;
        this.metadata = metadata;
        this.glue = glue;
        this.guard = guard;
        this.idempotency = idempotency;
        this.audit = audit;
        this.props = props;
        this.json = json;
    }

    public String jobName() {
        return props.glue().extractJob();
    }

    // 10. Create
    public ExtractionRequestRecord create(CreateDataExtractionRequest req, String idempotencyKey) {
        guard.requireApp(req.appId());
        String user = guard.userId();
        Optional<String> prior = idempotency.lookup("create-extraction", user, idempotencyKey, req);
        if (prior.isPresent()) {
            return load(prior.get());
        }
        DatabaseRecord db = databases.requireActive(req.appId(), req.dbId());
        Map<String, Set<String>> columns = new LinkedHashMap<>();
        metadata.loadTables(req.appId(), req.dbId()).forEach((key, rec) -> {
            Set<String> names = new HashSet<>();
            metadata.columns(rec).forEach(c -> names.add(c.path("name").asText()));
            columns.put(key, names);
        });
        ExtractionValidator.validate(req, columns);

        ExtractionRequestRecord rec = new ExtractionRequestRecord();
        rec.setRequestId(Ids.newId("dx"));
        rec.setAppId(req.appId());
        rec.setDbId(req.dbId());
        rec.setStatus(RunStatus.SUBMITTED);
        rec.setTablesJson(json.write(req.tables()));
        rec.setRelationshipsJson(json.write(req.relationships()));
        rec.setQuery(req.query() == null || req.query().isBlank() ? null : req.query().trim());
        rec.setParametersJson(json.write(req.parameters()));
        rec.setFiltersJson(json.write(normalizedFilters(req)));
        rec.setTargetAccountId(db.getTargetAccountId());
        rec.setRegion(db.getRegion());
        rec.setSubmittedBy(user);
        rec.setSubmittedAt(Ids.now());
        rec = table.updateItem(rec);
        idempotency.remember("create-extraction", user, idempotencyKey, req, rec.getRequestId());
        audit.record(entity(rec), "CREATE", user, null, null);
        return rec;
    }

    // 11. Status
    public ExtractionRequestRecord get(String requestId) {
        ExtractionRequestRecord rec = load(requestId);
        guard.requireApp(rec.getAppId());
        return rec;
    }

    // 12. Stop
    public ExtractionRequestRecord stop(String requestId, String reason) {
        ExtractionRequestRecord rec = get(requestId);
        String user = guard.userId();
        String now = Ids.now();
        switch (rec.getStatus()) {
            case RunStatus.SUBMITTED -> {
                rec.setStatus(RunStatus.STOPPED);
                rec.setCompletedAt(now);
            }
            case RunStatus.RUNNING -> {
                glue.stopJob(rec.glueTarget(), jobName(), rec.getGlueJobRunId());
                rec.setStatus(RunStatus.STOPPING);
            }
            default -> throw ApiException.conflict("NOT_STOPPABLE",
                    "request is already " + rec.getStatus(), "status");
        }
        rec.setStopRequestedBy(user);
        rec.setStopRequestedAt(now);
        rec.setStopReason(reason);
        rec = table.updateItem(rec);
        audit.record(entity(rec), "STOP", user, reason, null);
        return rec;
    }

    // 13. Retry
    public ExtractionRequestRecord retry(String requestId, String idempotencyKey) {
        ExtractionRequestRecord old = get(requestId);
        String user = guard.userId();
        Optional<String> prior = idempotency.lookup("retry-extraction", user, idempotencyKey, requestId);
        if (prior.isPresent()) {
            return load(prior.get());
        }
        if (!RunStatus.FAILED.equals(old.getStatus()) && !RunStatus.STOPPED.equals(old.getStatus())) {
            throw ApiException.conflict("NOT_RETRYABLE", "only FAILED or STOPPED requests can be retried", "status");
        }
        databases.requireActive(old.getAppId(), old.getDbId());
        ExtractionRequestRecord rec = new ExtractionRequestRecord();
        rec.setRequestId(Ids.newId("dx"));
        rec.setAppId(old.getAppId());
        rec.setDbId(old.getDbId());
        rec.setStatus(RunStatus.SUBMITTED);
        rec.setRetryOf(old.getRequestId());
        rec.setTablesJson(old.getTablesJson());
        rec.setRelationshipsJson(old.getRelationshipsJson());
        rec.setQuery(old.getQuery());
        rec.setParametersJson(old.getParametersJson());
        rec.setFiltersJson(old.getFiltersJson());
        rec.setTargetAccountId(old.getTargetAccountId());
        rec.setRegion(old.getRegion());
        rec.setSubmittedBy(user);
        rec.setSubmittedAt(Ids.now());
        rec = table.updateItem(rec);
        idempotency.remember("retry-extraction", user, idempotencyKey, requestId, rec.getRequestId());
        audit.record(entity(rec), "RETRY", user, null, "retry_of=" + old.getRequestId());
        return rec;
    }

    // 14. List
    public ListResponse<DataExtractionResponse> list(String appId, String dbId, List<String> statuses,
                                                     int limit, String nextToken) {
        guard.requireApp(appId);
        QueryEnhancedRequest.Builder q = QueryEnhancedRequest.builder()
                .queryConditional(QueryConditional.keyEqualTo(Key.builder().partitionValue(appId).build()))
                .scanIndexForward(false)
                .limit(Math.max(1, Math.min(limit, 100)));
        Expression filter = Filters.dbAndStatus(dbId, statuses);
        if (filter != null) {
            q.filterExpression(filter);
        }
        Map<String, AttributeValue> start = PageTokens.decode(nextToken);
        if (start != null) {
            q.exclusiveStartKey(start);
        }
        Page<ExtractionRequestRecord> page = table.index(ExtractionRequestRecord.APP_INDEX)
                .query(q.build()).iterator().next();
        return ListResponse.of(appId, dbId,
                page.items().stream().map(r -> DataExtractionResponse.summary(r, json)).toList(),
                PageTokens.encode(page.lastEvaluatedKey()));
    }

    // 20. Execute
    public ExtractionRequestRecord execute(String requestId, ExecuteDataExtractionRequest req) {
        ExtractionRequestRecord rec = get(requestId);
        if (!rec.getAppId().equals(req.appId()) || !rec.getDbId().equals(req.dbId())) {
            throw ApiException.notFound("REQUEST_NOT_FOUND",
                    "request '" + requestId + "' does not belong to " + req.appId() + "/" + req.dbId(), "request_id");
        }
        if (!RunStatus.SUBMITTED.equals(rec.getStatus())) {
            throw ApiException.conflict("NOT_EXECUTABLE", "request '" + requestId + "' is " + rec.getStatus()
                    + "; only SUBMITTED requests can be executed", "status");
        }
        DatabaseRecord db = databases.requireActive(rec.getAppId(), rec.getDbId());
        GlueTarget target = db.glueTarget();

        String format = req.output() == null || req.output().format() == null ? "parquet" : req.output().format();
        if (!FORMATS.contains(format)) {
            throw ApiException.badRequest("INVALID_SCHEMA", "output.format must be one of " + FORMATS, "output.format");
        }
        String allowedPrefix = "s3://" + glue.bucket(target) + "/" + props.storage().extractsPrefix()
                + "/" + rec.getAppId() + "/";
        String base = req.output() == null || req.output().targetS3Path() == null
                ? allowedPrefix + rec.getDbId() + "/" : req.output().targetS3Path();
        if (!base.startsWith(allowedPrefix) || !base.endsWith("/") || base.contains("..")) {
            throw ApiException.unprocessable("S3_PATH_NOT_ALLOWED",
                    "target_s3_path must be under " + allowedPrefix + " and end with '/'", "output.target_s3_path");
        }
        boolean applyPii = req.applyPiiRules() == null || req.applyPiiRules();
        String user = guard.userId();
        String outputPath = base + rec.getRequestId() + "/";

        ObjectNode spec = json.mapper().createObjectNode();
        spec.set("tables", json.read(rec.getTablesJson()));
        spec.set("relationships", nullToArray(json.read(rec.getRelationshipsJson())));
        if (rec.getQuery() != null) {
            spec.put("query", rec.getQuery());
        }
        spec.set("parameters", nullToObject(json.read(rec.getParametersJson())));
        spec.set("filters", nullToArray(json.read(rec.getFiltersJson())));

        Map<String, String> args = new LinkedHashMap<>();
        args.put("--request_id", rec.getRequestId());
        args.put("--app_id", rec.getAppId());
        args.put("--db_id", rec.getDbId());
        args.put("--engine", db.getEngine());
        args.put("--jdbc_url", db.getJdbcUrl());
        args.put("--auth_type", db.getAuthType());
        if ("secret".equals(db.getAuthType())) {
            args.put("--secret_name", db.getSecretName());
        } else {
            args.put("--db_user", db.getDbUser());
            args.put("--db_host", db.getHost());
            args.put("--db_port", String.valueOf(db.getPort()));
        }
        String specText = json.write(spec);
        if (specText.length() > props.glue().maxInlineSpecBytes()) {
            String specPath = outputPath + "_spec.json";
            glue.writeText(target, specPath, specText);
            args.put("--extraction_spec_path", specPath);
        } else {
            args.put("--extraction_spec", specText);
        }
        args.put("--pii_rules", json.write(applyPii ? piiRules(rec) : json.mapper().createArrayNode()));
        args.put("--output_format", format);
        args.put("--output_path", outputPath);
        args.put("--correlation_id", CorrelationIdFilter.current());

        // A 429 from Glue leaves the request SUBMITTED so it can be executed again later.
        String runId = glue.startJob(target, jobName(), args, props.glue().extractWorkers());

        String now = Ids.now();
        rec.setStatus(RunStatus.RUNNING);
        rec.setActive(RunStatus.ACTIVE);
        rec.setOutputFormat(format);
        rec.setOutputPath(outputPath);
        rec.setApplyPiiRules(applyPii);
        rec.setGlueJobRunId(runId);
        rec.setExecutedBy(user);
        rec.setExecutedAt(now);
        rec.setStartedAt(now);
        rec = table.updateItem(rec);
        audit.record(entity(rec), "EXECUTE", user, null, "glue_job_run_id=" + runId);
        return rec;
    }

    /** Called by the status sync for each active request. */
    public void sync(ExtractionRequestRecord rec) {
        GlueTarget target = rec.glueTarget();
        JobStatus job = glue.getJobRun(target, jobName(), rec.getGlueJobRunId());
        if (!job.finished()) {
            glue.readText(target, rec.getOutputPath() + "_progress.json").ifPresent(p -> {
                if (!p.equals(rec.getProgressJson())) {
                    rec.setProgressJson(p);
                    table.updateItem(rec);
                }
            });
            return;
        }
        rec.setActive(null);
        rec.setCompletedAt(Ids.now());
        switch (job.state()) {
            case "SUCCEEDED" -> {
                ObjectNode output = json.mapper().createObjectNode();
                output.put("s3_path", rec.getOutputPath());
                output.put("format", rec.getOutputFormat());
                glue.readText(target, rec.getOutputPath() + "_manifest.json").ifPresent(m -> {
                    JsonNode manifest = json.read(m);
                    output.set("row_count", manifest.get("row_count"));
                    output.set("file_count", manifest.get("file_count"));
                });
                rec.setStatus(RunStatus.SUCCEEDED);
                rec.setOutputJson(json.write(output));
                rec.setProgressJson(null);
            }
            case "STOPPED" -> rec.setStatus(RunStatus.STOPPED);
            default -> {
                ObjectNode err = json.mapper().createObjectNode();
                err.put("code", "GLUE_JOB_FAILED");
                err.put("message", job.state() + ": " + job.errorMessage());
                rec.setStatus(RunStatus.FAILED);
                rec.setErrorJson(json.write(err));
            }
        }
        table.updateItem(rec);
        log.info("data extraction {} finished: {}", rec.getRequestId(), rec.getStatus());
    }

    /** Lookup used by data loads. */
    public ExtractionRequestRecord find(String requestId) {
        return table.getItem(Key.builder().partitionValue(requestId).build());
    }

    private ArrayNode piiRules(ExtractionRequestRecord rec) {
        ArrayNode rules = json.mapper().createArrayNode();
        Map<String, TableMetadataRecord> tables = metadata.loadTables(rec.getAppId(), rec.getDbId());
        for (JsonNode t : json.read(rec.getTablesJson())) {
            TableMetadataRecord tm = tables.get(t.asText());
            if (tm == null) {
                continue;
            }
            for (JsonNode c : metadata.columns(tm)) {
                JsonNode rule = c.path("pii_rule");
                if (rule.isObject() && !"NONE".equals(rule.path("action").asText())) {
                    ObjectNode r = rules.addObject();
                    r.put("column", t.asText() + "." + c.path("name").asText());
                    r.setAll((ObjectNode) rule.deepCopy());
                }
            }
        }
        return rules;
    }

    private List<Map<String, Object>> normalizedFilters(CreateDataExtractionRequest req) {
        List<Map<String, Object>> out = new ArrayList<>();
        if (req.filters() != null) {
            req.filters().forEach(f -> {
                Map<String, Object> m = new LinkedHashMap<>();
                m.put("column", f.column());
                m.put("operator", f.operator().toUpperCase(java.util.Locale.ROOT));
                m.put("values", f.values() == null ? List.of() : f.values());
                out.add(m);
            });
        }
        return out;
    }

    private JsonNode nullToArray(JsonNode n) {
        return n == null || n.isNull() ? json.mapper().createArrayNode() : n;
    }

    private JsonNode nullToObject(JsonNode n) {
        return n == null || n.isNull() ? json.mapper().createObjectNode() : n;
    }

    private ExtractionRequestRecord load(String requestId) {
        ExtractionRequestRecord rec = find(requestId);
        if (rec == null) {
            throw ApiException.notFound("REQUEST_NOT_FOUND",
                    "request '" + requestId + "' does not exist", "request_id");
        }
        return rec;
    }

    private static String entity(ExtractionRequestRecord rec) {
        return "data_extraction#" + rec.getAppId() + "#" + rec.getRequestId();
    }
}
