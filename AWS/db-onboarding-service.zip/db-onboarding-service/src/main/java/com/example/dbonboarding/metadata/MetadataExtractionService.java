package com.example.dbonboarding.metadata;

import com.example.dbonboarding.common.ApiException;
import com.example.dbonboarding.common.CorrelationIdFilter;
import com.example.dbonboarding.common.Ids;
import com.example.dbonboarding.common.JsonAttr;
import com.example.dbonboarding.common.RunStatus;
import com.example.dbonboarding.config.AppProperties;
import com.example.dbonboarding.database.DatabaseRecord;
import com.example.dbonboarding.database.DatabaseService;
import com.example.dbonboarding.glue.GlueGateway;
import com.example.dbonboarding.glue.GlueGateway.CrawlStatus;
import com.example.dbonboarding.glue.GlueGateway.JobStatus;
import com.example.dbonboarding.glue.GlueTarget;
import com.example.dbonboarding.idempotency.IdempotencyService;
import com.example.dbonboarding.metadata.MetadataDtos.StartMetadataExtractionRequest;
import com.example.dbonboarding.security.AccessGuard;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.time.Instant;
import java.util.LinkedHashMap;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;
import software.amazon.awssdk.enhanced.dynamodb.DynamoDbTable;
import software.amazon.awssdk.enhanced.dynamodb.Expression;
import software.amazon.awssdk.enhanced.dynamodb.Key;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryConditional;
import software.amazon.awssdk.enhanced.dynamodb.model.QueryEnhancedRequest;
import software.amazon.awssdk.services.dynamodb.model.AttributeValue;

/**
 * Metadata extraction runs (APIs 6 and 7). A run starts the crawler (secret auth only, it needs
 * a Glue JDBC connection) and the metadata-enrich job; the status sync completes it.
 */
@Service
public class MetadataExtractionService {

    private static final Logger log = LoggerFactory.getLogger(MetadataExtractionService.class);

    private final DynamoDbTable<MetadataExtractionRecord> table;
    private final DatabaseService databases;
    private final MetadataService metadata;
    private final GlueGateway glue;
    private final AccessGuard guard;
    private final IdempotencyService idempotency;
    private final AppProperties props;
    private final JsonAttr json;

    public MetadataExtractionService(DynamoDbTable<MetadataExtractionRecord> table, DatabaseService databases,
                                     MetadataService metadata, GlueGateway glue, AccessGuard guard,
                                     IdempotencyService idempotency, AppProperties props, JsonAttr json) {
        this.table = table;
        this.databases = databases;
        this.metadata = metadata;
        this.glue = glue;
        this.guard = guard;
        this.idempotency = idempotency;
        this.props = props;
        this.json = json;
    }

    // 6. Start metadata extraction
    public MetadataExtractionRecord start(StartMetadataExtractionRequest req, String idempotencyKey) {
        guard.requireApp(req.appId());
        String user = guard.userId();
        Optional<String> prior = idempotency.lookup("start-metadata", user, idempotencyKey, req);
        if (prior.isPresent()) {
            return load(prior.get());
        }
        DatabaseRecord db = databases.requireActive(req.appId(), req.dbId());
        String appDb = TableMetadataRecord.appDb(req.appId(), req.dbId());
        if (hasActiveRun(appDb)) {
            throw ApiException.conflict("EXTRACTION_IN_PROGRESS",
                    "a metadata extraction for '" + req.dbId() + "' is already running", "db_id");
        }

        List<String> includePaths = req.includePaths() == null || req.includePaths().isEmpty()
                ? List.of(db.getDatabase() + "/%") : req.includePaths();
        for (int i = 0; i < includePaths.size(); i++) {
            if (!includePaths.get(i).startsWith(db.getDatabase() + "/")) {
                throw ApiException.badRequest("INVALID_SCHEMA",
                        "include paths must start with '" + db.getDatabase() + "/'", "include_paths[" + i + "]");
            }
        }
        List<String> excludes = req.excludePatterns() == null ? List.of() : req.excludePatterns();
        String catalogDb = req.catalogDatabase() != null ? req.catalogDatabase() : req.dbId() + "_raw_catalog";

        String id = Ids.newId("mx");
        GlueTarget target = db.glueTarget();
        String now = Ids.now();
        MetadataExtractionRecord rec = new MetadataExtractionRecord();
        rec.setExtractionId(id);
        rec.setAppId(req.appId());
        rec.setDbId(req.dbId());
        rec.setAppDb(appDb);
        rec.setStatus(RunStatus.SUBMITTED);
        rec.setCatalogDatabase(catalogDb);
        rec.setTargetAccountId(target.accountId());
        rec.setRegion(target.region());
        rec.setOutputPath("s3://" + glue.bucket(target) + "/" + props.storage().metadataPrefix()
                + "/" + req.appId() + "/" + req.dbId() + "/" + id + "/");
        rec.setSubmittedBy(user);
        rec.setSubmittedAt(now);
        rec = table.updateItem(rec);
        idempotency.remember("start-metadata", user, idempotencyKey, req, id);

        try {
            if ("secret".equals(db.getAuthType())) {
                // Glue crawlers can't use IAM database auth, so the Data Catalog is filled only for secret auth.
                glue.ensureJdbcConnection(target, db.getGlueConnection(), db.getJdbcUrl(), db.getSecretName());
                String crawler = "metadata-crawler-" + db.getDbId();
                glue.startCrawler(target, crawler, catalogDb, db.getGlueConnection(), includePaths, excludes);
                rec.setCrawlerName(crawler);
                rec.setCrawlerStartedAt(Ids.now());
            }
            Map<String, String> args = new LinkedHashMap<>();
            args.put("--extraction_id", id);
            args.put("--app_id", db.getAppId());
            args.put("--db_id", db.getDbId());
            args.put("--engine", db.getEngine());
            args.put("--jdbc_url", db.getJdbcUrl());
            args.put("--auth_type", db.getAuthType());
            if ("secret".equals(db.getAuthType())) {
                args.put("--secret_name", db.getSecretName());
            } else {
                args.put("--db_user", db.getDbUser());
                args.put("--db_host", db.getHost());
                args.put("--db_port", String.valueOf(db.getPort()));
            }
            args.put("--catalog_database", catalogDb);
            args.put("--include_schemas", String.join(",", schemasOf(includePaths)));
            args.put("--exclude_patterns", String.join(",", excludes));
            args.put("--pii_sample_rows", String.valueOf(props.glue().piiSampleRows()));
            args.put("--output_path", rec.getOutputPath());
            args.put("--correlation_id", CorrelationIdFilter.current());
            String runId = glue.startJob(target, props.glue().metadataJob(), args, props.glue().metadataWorkers());

            rec.setJobRunId(runId);
            rec.setStatus(RunStatus.RUNNING);
            rec.setActive(RunStatus.ACTIVE);
            rec.setStartedAt(Ids.now());
            return table.updateItem(rec);
        } catch (RuntimeException e) {
            markFailed(rec, "GLUE_START_FAILED", e.getMessage());
            throw e;
        }
    }

    // 7. Metadata extraction status
    public MetadataExtractionRecord get(String extractionId) {
        MetadataExtractionRecord rec = load(extractionId);
        guard.requireApp(rec.getAppId());
        return rec;
    }

    /** Called by the status sync for each active run. */
    public void sync(MetadataExtractionRecord rec) {
        GlueTarget target = rec.glueTarget();
        JobStatus job = glue.getJobRun(target, props.glue().metadataJob(), rec.getJobRunId());
        CrawlStatus crawl = rec.getCrawlerName() == null ? null : glue.getCrawler(target, rec.getCrawlerName());
        boolean crawlDone = crawl == null || ("READY".equals(crawl.state()) && crawl.lastStartTime() != null
                && !crawl.lastStartTime().isBefore(Instant.parse(rec.getCrawlerStartedAt()).minusSeconds(120)));
        if (!job.finished() || !crawlDone) {
            return;
        }
        if (!"SUCCEEDED".equals(job.state())) {
            markFailed(rec, "GLUE_JOB_FAILED", job.state() + ": " + job.errorMessage());
            return;
        }
        if (crawl != null && !"SUCCEEDED".equals(crawl.lastStatus())) {
            markFailed(rec, "CRAWLER_FAILED", crawl.lastStatus() + ": " + crawl.errorMessage());
            return;
        }
        Optional<String> output = glue.readText(target, rec.getOutputPath() + "metadata.json");
        if (output.isEmpty()) {
            markFailed(rec, "METADATA_OUTPUT_MISSING", "metadata.json not found at " + rec.getOutputPath());
            return;
        }
        ObjectNode result = metadata.ingest(rec.getAppId(), rec.getDbId(), rec.getExtractionId(),
                rec.getCatalogDatabase(), json.read(output.get()));
        rec.setStatus(RunStatus.SUCCEEDED);
        rec.setActive(null);
        rec.setCompletedAt(Ids.now());
        rec.setResultJson(json.write(result));
        table.updateItem(rec);
        log.info("metadata extraction {} succeeded: {}", rec.getExtractionId(), result);
    }

    private void markFailed(MetadataExtractionRecord rec, String code, String message) {
        ObjectNode err = json.mapper().createObjectNode();
        err.put("code", code);
        err.put("message", message);
        rec.setStatus(RunStatus.FAILED);
        rec.setActive(null);
        rec.setCompletedAt(Ids.now());
        rec.setErrorJson(json.write(err));
        table.updateItem(rec);
        log.warn("metadata extraction {} failed: {} {}", rec.getExtractionId(), code, message);
    }

    private boolean hasActiveRun(String appDb) {
        Expression active = Expression.builder()
                .expression("#st IN (:s1, :s2)")
                .putExpressionName("#st", "status")
                .putExpressionValue(":s1", AttributeValue.builder().s(RunStatus.SUBMITTED).build())
                .putExpressionValue(":s2", AttributeValue.builder().s(RunStatus.RUNNING).build())
                .build();
        return table.index(MetadataExtractionRecord.APP_DB_INDEX)
                .query(QueryEnhancedRequest.builder()
                        .queryConditional(QueryConditional.keyEqualTo(Key.builder().partitionValue(appDb).build()))
                        .filterExpression(active)
                        .build())
                .stream()
                .anyMatch(page -> !page.items().isEmpty());
    }

    private MetadataExtractionRecord load(String extractionId) {
        MetadataExtractionRecord rec = table.getItem(Key.builder().partitionValue(extractionId).build());
        if (rec == null) {
            throw ApiException.notFound("EXTRACTION_NOT_FOUND",
                    "extraction '" + extractionId + "' does not exist", "extraction_id");
        }
        return rec;
    }

    /** "orders/public/%" gives "public"; "orders/%" gives "%" (all schemas). */
    static List<String> schemasOf(List<String> includePaths) {
        Set<String> out = new LinkedHashSet<>();
        for (String p : includePaths) {
            String[] parts = p.split("/");
            out.add(parts.length >= 2 ? parts[1] : "%");
        }
        return List.copyOf(out);
    }
}
