package com.example.dbonboarding.extraction;

import com.example.dbonboarding.glue.GlueTarget;
import software.amazon.awssdk.enhanced.dynamodb.extensions.annotations.DynamoDbVersionAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbAttribute;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbBean;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbIgnore;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondaryPartitionKey;
import software.amazon.awssdk.enhanced.dynamodb.mapper.annotations.DynamoDbSecondarySortKey;

/**
 * Table {@code extraction_requests}: one item per data extraction request.
 * {@code app-index} (app_id, submitted_at) serves the list call; {@code active-index} is sparse
 * and holds only requests Glue is working on.
 */
@DynamoDbBean
public class ExtractionRequestRecord {

    public static final String APP_INDEX = "app-index";
    public static final String ACTIVE_INDEX = "active-index";

    private String requestId;
    private String appId;
    private String dbId;
    private String active;
    private String status;
    private String retryOf;
    private String tablesJson;
    private String relationshipsJson;
    private String query;
    private String parametersJson;
    private String filtersJson;
    private String outputFormat;
    private String outputPath;
    private Boolean applyPiiRules;
    private String glueJobRunId;
    private String targetAccountId;
    private String region;
    private String submittedBy;
    private String submittedAt;
    private String executedBy;
    private String executedAt;
    private String startedAt;
    private String completedAt;
    private String stopRequestedBy;
    private String stopRequestedAt;
    private String stopReason;
    private String progressJson;
    private String outputJson;
    private String errorJson;
    private Long version;

    @DynamoDbIgnore
    public GlueTarget glueTarget() {
        return new GlueTarget(targetAccountId, region);
    }

    @DynamoDbPartitionKey
    @DynamoDbAttribute("request_id")
    public String getRequestId() {
        return requestId;
    }

    public void setRequestId(String requestId) {
        this.requestId = requestId;
    }

    @DynamoDbSecondaryPartitionKey(indexNames = APP_INDEX)
    @DynamoDbAttribute("app_id")
    public String getAppId() {
        return appId;
    }

    public void setAppId(String appId) {
        this.appId = appId;
    }

    @DynamoDbAttribute("db_id")
    public String getDbId() {
        return dbId;
    }

    public void setDbId(String dbId) {
        this.dbId = dbId;
    }

    @DynamoDbSecondaryPartitionKey(indexNames = ACTIVE_INDEX)
    @DynamoDbAttribute("active")
    public String getActive() {
        return active;
    }

    public void setActive(String active) {
        this.active = active;
    }

    @DynamoDbAttribute("status")
    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    @DynamoDbAttribute("retry_of")
    public String getRetryOf() {
        return retryOf;
    }

    public void setRetryOf(String retryOf) {
        this.retryOf = retryOf;
    }

    @DynamoDbAttribute("tables_json")
    public String getTablesJson() {
        return tablesJson;
    }

    public void setTablesJson(String tablesJson) {
        this.tablesJson = tablesJson;
    }

    @DynamoDbAttribute("relationships_json")
    public String getRelationshipsJson() {
        return relationshipsJson;
    }

    public void setRelationshipsJson(String relationshipsJson) {
        this.relationshipsJson = relationshipsJson;
    }

    @DynamoDbAttribute("query")
    public String getQuery() {
        return query;
    }

    public void setQuery(String query) {
        this.query = query;
    }

    @DynamoDbAttribute("parameters_json")
    public String getParametersJson() {
        return parametersJson;
    }

    public void setParametersJson(String parametersJson) {
        this.parametersJson = parametersJson;
    }

    @DynamoDbAttribute("filters_json")
    public String getFiltersJson() {
        return filtersJson;
    }

    public void setFiltersJson(String filtersJson) {
        this.filtersJson = filtersJson;
    }

    @DynamoDbAttribute("output_format")
    public String getOutputFormat() {
        return outputFormat;
    }

    public void setOutputFormat(String outputFormat) {
        this.outputFormat = outputFormat;
    }

    @DynamoDbAttribute("output_path")
    public String getOutputPath() {
        return outputPath;
    }

    public void setOutputPath(String outputPath) {
        this.outputPath = outputPath;
    }

    @DynamoDbAttribute("apply_pii_rules")
    public Boolean getApplyPiiRules() {
        return applyPiiRules;
    }

    public void setApplyPiiRules(Boolean applyPiiRules) {
        this.applyPiiRules = applyPiiRules;
    }

    @DynamoDbAttribute("glue_job_run_id")
    public String getGlueJobRunId() {
        return glueJobRunId;
    }

    public void setGlueJobRunId(String glueJobRunId) {
        this.glueJobRunId = glueJobRunId;
    }

    @DynamoDbAttribute("target_account_id")
    public String getTargetAccountId() {
        return targetAccountId;
    }

    public void setTargetAccountId(String targetAccountId) {
        this.targetAccountId = targetAccountId;
    }

    @DynamoDbAttribute("region")
    public String getRegion() {
        return region;
    }

    public void setRegion(String region) {
        this.region = region;
    }

    @DynamoDbAttribute("submitted_by")
    public String getSubmittedBy() {
        return submittedBy;
    }

    public void setSubmittedBy(String submittedBy) {
        this.submittedBy = submittedBy;
    }

    @DynamoDbSecondarySortKey(indexNames = {APP_INDEX, ACTIVE_INDEX})
    @DynamoDbAttribute("submitted_at")
    public String getSubmittedAt() {
        return submittedAt;
    }

    public void setSubmittedAt(String submittedAt) {
        this.submittedAt = submittedAt;
    }

    @DynamoDbAttribute("executed_by")
    public String getExecutedBy() {
        return executedBy;
    }

    public void setExecutedBy(String executedBy) {
        this.executedBy = executedBy;
    }

    @DynamoDbAttribute("executed_at")
    public String getExecutedAt() {
        return executedAt;
    }

    public void setExecutedAt(String executedAt) {
        this.executedAt = executedAt;
    }

    @DynamoDbAttribute("started_at")
    public String getStartedAt() {
        return startedAt;
    }

    public void setStartedAt(String startedAt) {
        this.startedAt = startedAt;
    }

    @DynamoDbAttribute("completed_at")
    public String getCompletedAt() {
        return completedAt;
    }

    public void setCompletedAt(String completedAt) {
        this.completedAt = completedAt;
    }

    @DynamoDbAttribute("stop_requested_by")
    public String getStopRequestedBy() {
        return stopRequestedBy;
    }

    public void setStopRequestedBy(String stopRequestedBy) {
        this.stopRequestedBy = stopRequestedBy;
    }

    @DynamoDbAttribute("stop_requested_at")
    public String getStopRequestedAt() {
        return stopRequestedAt;
    }

    public void setStopRequestedAt(String stopRequestedAt) {
        this.stopRequestedAt = stopRequestedAt;
    }

    @DynamoDbAttribute("stop_reason")
    public String getStopReason() {
        return stopReason;
    }

    public void setStopReason(String stopReason) {
        this.stopReason = stopReason;
    }

    @DynamoDbAttribute("progress_json")
    public String getProgressJson() {
        return progressJson;
    }

    public void setProgressJson(String progressJson) {
        this.progressJson = progressJson;
    }

    @DynamoDbAttribute("output_json")
    public String getOutputJson() {
        return outputJson;
    }

    public void setOutputJson(String outputJson) {
        this.outputJson = outputJson;
    }

    @DynamoDbAttribute("error_json")
    public String getErrorJson() {
        return errorJson;
    }

    public void setErrorJson(String errorJson) {
        this.errorJson = errorJson;
    }

    @DynamoDbVersionAttribute
    @DynamoDbAttribute("version")
    public Long getVersion() {
        return version;
    }

    public void setVersion(Long version) {
        this.version = version;
    }
}
