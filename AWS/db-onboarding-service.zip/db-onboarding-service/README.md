# db-onboarding-service

Spring Boot 3 service that implements the **AWS Database Onboarding API** (20 endpoints). It runs on EKS in **Account A**, stores state in DynamoDB there, and drives AWS Glue in **Account B** (where the databases live) by assuming `GlueInvokerRole`.

```
On-prem UI ─▶ On-prem API ──mTLS + user token──▶ Internal ALB (Account A)
                                                     │
                                              EKS: db-onboarding-service
                                       ┌─────────────┴──────────────┐
                                  DynamoDB (A)            sts:AssumeRole ─▶ Account B
                                                          Glue crawler / jobs, S3 bucket
```

## What's in the box

| Path | Contents |
| --- | --- |
| `src/main/java/.../database` | APIs 1–5: create, fetch, list, update, soft-delete databases |
| `src/main/java/.../metadata` | APIs 6–9: start metadata extraction, status, fetch metadata, update one table's PII tags |
| `src/main/java/.../extraction` | APIs 10–14 and 20: create, status, stop, retry, list and execute data extractions |
| `src/main/java/.../load` | APIs 15–19: create (and start), status, stop, retry, list data loads |
| `src/main/java/.../glue` | Cross-account Glue and S3 calls (assume role, crawler, jobs, manifests) |
| `src/main/java/.../sync` | Background poller that moves runs from `RUNNING` to `SUCCEEDED` / `FAILED` / `STOPPED` |
| `src/main/java/.../security` | JWT validation and per-app authorization |
| `k8s/` | Namespace, ServiceAccount, ConfigMap, Deployment, Service, internal ALB Ingress with mTLS, HPA, PDB, NetworkPolicy |
| `infra/account-a-service.yaml` | CloudFormation: 8 DynamoDB tables, KMS key, pod IAM role |
| `infra/account-b-glue.yaml` | CloudFormation: S3 bucket, `GlueInvokerRole`, Glue job and crawler roles, network connection, 3 Glue job definitions |

The API contract is the "AWS Database Onboarding API" spec. Wire format is snake_case JSON; errors are always `{"error": {"code", "message", "field"}}`.

## Build and run locally

Requires JDK 21 and Maven 3.9.

```bash
mvn verify                       # compile + unit tests
mvn spring-boot:run              # needs an OIDC issuer and AWS credentials
```

To run against DynamoDB Local, start it on port 8000, create the tables (`aws cloudformation` won't target it, so use `aws dynamodb create-table` with the definitions from `infra/account-a-service.yaml`), and set `DYNAMODB_ENDPOINT=http://localhost:8000`.

## Deploy to EKS

1. **Account A** – deploy `infra/account-a-service.yaml` (parameters: target account IDs, EKS cluster ARN). Note the `ServiceRoleArn` output.
2. **Account B** – deploy `infra/account-b-glue.yaml` with that `ServiceRoleArn`, an external ID, and a subnet / security group / AZ that can reach the databases. Upload the three Glue scripts to `s3://dbreg-data-<account>-<region>/scripts/` (see *Glue job contract*).
3. **Pod Identity** – link the service account to the role:
   ```bash
   aws eks create-pod-identity-association --cluster-name <cluster> \
     --namespace db-onboarding --service-account db-onboarding-service \
     --role-arn <ServiceRoleArn>
   ```
4. **Image** – build and push:
   ```bash
   docker build -t <acct>.dkr.ecr.<region>.amazonaws.com/db-onboarding-service:1.0.0 .
   docker push <acct>.dkr.ecr.<region>.amazonaws.com/db-onboarding-service:1.0.0
   ```
5. **Config** – edit `k8s/configmap.yaml` (issuer, audience, account IDs) and the ACM certificate / ALB trust store ARNs in `k8s/ingress.yaml`. For lists and maps (host allowlist, onboarded accounts, Glue networks), mount your own `application.yml` (see below).
6. **Apply**: `kubectl apply -k k8s/`

The pods need outbound access to DynamoDB, STS, Glue and S3 (VPC endpoints or NAT) and to your OIDC issuer's JWKS URL.

## Configuration

Everything lives under `app.*` in `src/main/resources/application.yml`. Key settings:

| Key | Purpose |
| --- | --- |
| `app.security.issuer-uri`, `audience` | Token validation for the forwarded user token |
| `app.security.app-group-prefix`, `admin-group`, `onboarder-group` | Authorization: `app:APP12345` grants that app; `db-onboarders` may register databases |
| `app.policy.allowed-host-suffixes`, `allowed-cidrs`, `allowed-ports` | Connection allowlists (no raw JDBC URLs are accepted) |
| `app.policy.onboarded-accounts`, `allowed-regions` | Where databases may live |
| `app.glue.networks.<account>` | Subnet, security groups and AZ for the per-database Glue JDBC connection |
| `app.storage.bucket-template` | S3 bucket per target account, e.g. `dbreg-data-{account_id}-{region}` |
| `app.sync.interval-ms` | How often running jobs are polled (default 30 s) |

To override lists/maps in EKS, put a full `application.yml` in a ConfigMap, mount it at `/config/`, and set `SPRING_CONFIG_ADDITIONAL_LOCATION=file:/config/`.

## How the pieces fit

- **Secrets never pass through this service.** A database with `auth_type: secret` uses the Secrets Manager secret `glue-db/{db_id}` in Account B by convention; with `auth_type: iam`, Glue signs an RDS IAM token itself. Only the secret *name* is sent to Glue.
- **Optimistic locking.** Every record has a `version` (DynamoDB enhanced-client version attribute). `If-Match` is checked on update/delete, and concurrent writes fail with `412 VERSION_MISMATCH`.
- **Idempotency.** POST endpoints honour `Idempotency-Key` (24 h, per user), stored in `idempotency_keys`.
- **Status sync.** Running items carry a sparse `active` attribute indexed by `active-index`. Each pod polls it every 30 s; version checks make multiple replicas safe.
- **Audit.** Every create/update/delete/stop/retry/execute writes to `audit_log` (with `change_reason` for metadata edits).
- **Data loads** start their Glue job immediately on create. They run in the account holding the extraction output; targets are registered in `load_targets` (`target_id`, `type`, `account_id`, `region`, `glue_connection`, `secret_name`, `allowed_app_ids`, `status: ACTIVE`).

## Glue job contract

The service passes these arguments and reads these files. Your Glue scripts must honour them.

**metadata-enrich-job** – args `--extraction_id --app_id --db_id --engine --jdbc_url --auth_type --secret_name | --db_user --db_host --db_port --catalog_database --include_schemas --exclude_patterns --pii_sample_rows --output_path --correlation_id`.
Writes `{output_path}metadata.json`:
```json
{
  "tables": [
    {"schema": "public", "table": "orders", "row_count_estimate": 1250000, "primary_key": ["order_id"],
     "columns": [{"name": "order_id", "type": "bigint", "nullable": false, "position": 1,
                  "is_sensitive": false, "pii_type": null, "classification": "INTERNAL",
                  "pii_rule": null, "detection": {"method": "AUTO", "confidence": 0.99}}]}
  ],
  "relationships": [
    {"name": "fk_orders_customer", "type": "MANY_TO_ONE",
     "from": {"schema": "public", "table": "orders", "columns": ["customer_id"]},
     "to": {"schema": "public", "table": "customers", "columns": ["customer_id"]},
     "on_delete": "RESTRICT", "on_update": "CASCADE"}
  ]
}
```

**data-extract-job** – args `--request_id --app_id --db_id --engine --jdbc_url --auth_type --secret_name | --db_user --db_host --db_port --extraction_spec | --extraction_spec_path --pii_rules --output_format --output_path --correlation_id`.
Writes data under `{output_path}`, optionally `{output_path}_progress.json` (`{"rows_extracted": n, "percent": p}`) while running, and `{output_path}_manifest.json` (`{"row_count": n, "file_count": n}`) at the end. It must bind `parameters` through the JDBC driver, never by string concatenation.

**data-load-job** – args `--load_id --request_id --app_id --source_path --source_format --target_type --target_connection --target_secret_name --target_schema --target_table --load_mode --merge_keys --create_table_if_missing --result_path --TempDir --correlation_id`.
Writes `{result_path}` (`{"rows_inserted": n, "rows_updated": n, "rows_rejected": n}`) and optionally `_progress.json` next to it.

## Tests

`mvn verify` runs unit tests for the connection allowlists, JDBC URL building, SQL query validation, extraction request validation and page tokens. There are no integration tests against DynamoDB or Glue yet; DynamoDB Local or LocalStack (Testcontainers) would be the next step.
